#pragma once

#include "include/input.h"

extern struct Candidate;
extern Candidate g_CurrentCandidate;

#define ifl(cond) if ([&](){ bool b = (cond); if (b) LOGI(#cond); return b; }())

extern Point2D lastFailedCuePos;

extern bool IsShotValid();

struct PowerSlider {
    bool Active = false;
    float ElapsedTime = 0.f, Duration = 0.f;
    float HoldTime = 0.f, HoldDuration = 0.f;
    ImVec2 StartPos;
    ImVec2 EndPos; // Max drag position
    ImVec2 TargetPos; // Actual target based on power
    ImVec2 CurrentPos;

    float ShotPower = 666.0f;
    int TouchIndex = 10; // High touch index

    enum State {
        IDLE,
        STARTING,
        // ── NEW: Micro-wobble phase simulating human hand shake ──
        WOBBLE_START,
        MOVING,
        WOBBLE_END,
        ENDING,
        RETURNING,
    } state = IDLE;
    
    // ── Wobble parameters for human-like hand movement ──
    float wobbleAmplitude = 0.0f;
    float wobbleFrequency = 0.0f;
    float wobbleTimer = 0.0f;
    float wobbleDuration = 0.0f;
    float wobbleElapsed = 0.0f;
    float wobbleDecay = 1.0f;
    
    // ── Micro-pause simulation (human finger hesitation) ──
    float microPauseTimer = 0.0f;
    float microPauseDuration = 0.0f;
    bool  inMicroPause = false;

    // RNG for randomization
    static float NextRand() {
        static uint32_t s_rngState = 54321;
        s_rngState ^= s_rngState << 13;
        s_rngState ^= s_rngState >> 17;
        s_rngState ^= s_rngState << 5;
        return (float)(s_rngState & 0xFFFF) / 65535.0f;
    }

    // Ease-in-out cubic for smooth human-like motion
    static float EaseInOutCubic(float t) {
        return t < 0.5f ? 4.0f * t * t * t : 1.0f - powf(-2.0f * t + 2.0f, 3.0f) / 2.0f;
    }
    
    void Start(ImVec2 start, ImVec2 end) {
        this->StartPos = start;
        this->EndPos = end;
        this->CurrentPos = this->StartPos;
        this->ElapsedTime = 0.f;
        this->HoldTime = 0.f;
        this->wobbleTimer = 0.f;
        this->wobbleElapsed = 0.f;
        this->microPauseTimer = 0.f;
        this->inMicroPause = false;

        this->Active = true;
        this->state = STARTING;
    }
    
    void Start(ImVec4 Rect) {
        float center = Rect.x + Rect.z / 2.0f;
        Start(ImVec2(center, Rect.y), ImVec2(center, Rect.y + Rect.w));
    }

    void End() {
        LOGI("ending at power %f", sharedGameManager.mVisualCue().getShotPower(true));
        NativeTouchesEnd(this->TouchIndex, this->CurrentPos.x, this->CurrentPos.y);
        this->Active = false;
        this->state = IDLE;
        g_CurrentCandidate.idx = -1;
    }

    void Cancel() {
        LOGI("Canceling power slider at power %f", sharedGameManager.mVisualCue().getShotPower(true));
        this->EndPos = this->CurrentPos;
        this->TargetPos = this->StartPos;
        this->ElapsedTime = 0.f;
        this->HoldTime = 0.f;
        this->Duration = 0.3f;
        this->state = RETURNING;

        g_CurrentCandidate.idx = -1;
        lastFailedCuePos = { -1000.0, -1000.0 };

    }
    
    // DragTime is time to reach MAX power (666.0f)
    void SimulateDrag(ImVec4 Rect, float ShotPower = 0.f, float DragTime = 2.0f, float HoldTime = 1.0f) {
        if (this->Active) return;
        
        // ضربة قوية جداً كما طلب المستخدم
        this->ShotPower = (ShotPower > 0.f) ? (ShotPower * 1.2f) : 666.0f;
        if (this->ShotPower > 666.0f) this->ShotPower = 666.0f;
        
        float powerRatio = std::min(this->ShotPower / 666.0f, 1.0f);
        
        Start(Rect);
        
        this->TargetPos = ImVec2(
            this->StartPos.x + (this->EndPos.x - this->StartPos.x) * powerRatio,
            this->StartPos.y + (this->EndPos.y - this->StartPos.y) * powerRatio
        );
        
        // سحب تدريجي بطيء مثل البشر
        this->Duration = DragTime * (0.7f + powerRatio * 0.8f);
        this->HoldDuration = HoldTime; // وقت الثبات قبل الضرب
        
        this->wobbleAmplitude = 1.2f + NextRand() * 1.8f;   
        this->wobbleFrequency = 10.0f + NextRand() * 5.0f; 
        this->wobbleDuration = 0.4f + NextRand() * 0.3f;   // ثبات تدريجي ملحوظ قبل الضرب
        this->wobbleElapsed = 0.0f;
        this->wobbleTimer = 0.0f;
        
        // تردد بشري أثناء السحب (تردد الإصبع)
        this->microPauseDuration = 0.2f + NextRand() * 0.2f; 
        this->microPauseTimer = 0.0f;
        this->inMicroPause = false;
    }

    void Update() {
        if (!this->Active) return;
        
        float dt = ImGui::GetIO().DeltaTime;
        
        if (this->state == STARTING) {
            this->HoldTime += dt;
            if (this->HoldTime >= this->HoldDuration * 2.f) {
                NativeTouchesBegin(this->TouchIndex, this->StartPos.x, this->StartPos.y);
                this->state = WOBBLE_START;
                this->HoldTime = 0.f;
                this->wobbleElapsed = 0.f;
                this->wobbleTimer = 0.f;
            }
        }
        
        // ── WOBBLE_START: Initial micro-wobble simulating human finger placement ──
        if (this->state == WOBBLE_START) {
            this->wobbleElapsed += dt;
            this->wobbleTimer += dt * this->wobbleFrequency;
            
            float decay = 1.0f - (this->wobbleElapsed / this->wobbleDuration);
            if (decay < 0) decay = 0;
            
            float wobbleX = sinf(this->wobbleTimer * 1.3f) * this->wobbleAmplitude * decay;
            float wobbleY = cosf(this->wobbleTimer * 0.9f) * this->wobbleAmplitude * 0.5f * decay;
            
            ImVec2 wobblePos = ImVec2(this->StartPos.x + wobbleX, this->StartPos.y + wobbleY);
            NativeTouchesMove(this->TouchIndex, wobblePos.x, wobblePos.y);
            
            if (this->wobbleElapsed >= this->wobbleDuration) {
                this->state = MOVING;
                this->ElapsedTime = 0.f;
                this->microPauseTimer = 0.f;
            }
            
            if (dynamic_bool["DebugTouch"]) {
                ImDrawList* fg = ImGui::GetForegroundDrawList();
                fg->AddCircleFilled(ImVec2(this->StartPos.x + wobbleX, this->StartPos.y + wobbleY), 15.0f, IM_COL32(100, 255, 100, 100));
                fg->AddCircle(ImVec2(this->StartPos.x + wobbleX, this->StartPos.y + wobbleY), 15.0f, IM_COL32(100, 255, 100, 200), 0.0f, 2.0f);
            }
        }
        
        if (this->state == MOVING) {
            this->ElapsedTime += dt;
            
            // ── Micro-pause: simulate human finger hesitation at ~40-60% progress ──
            if (!this->inMicroPause) {
                float progress = this->ElapsedTime / this->Duration;
                if (progress > 0.35f && progress < 0.45f && this->microPauseTimer == 0.f) {
                    this->inMicroPause = true;
                    this->microPauseTimer = 0.f;
                }
            }
            
            if (this->inMicroPause) {
                this->microPauseTimer += dt;
                // Small wobble during pause (human hand instability)
                float pauseWobble = sinf(this->microPauseTimer * 20.0f) * 0.3f;
                NativeTouchesMove(this->TouchIndex, this->CurrentPos.x + pauseWobble, this->CurrentPos.y);
                
                if (this->microPauseTimer >= this->microPauseDuration) {
                    this->inMicroPause = false;
                }
                // Don't advance main timer during micro-pause
            } else {
                if (this->ElapsedTime < this->Duration) {
                    // ── Eased interpolation for smooth human-like motion ──
                    float t = this->ElapsedTime / this->Duration;
                    float eased = EaseInOutCubic(t);
                    
                    this->CurrentPos = ImVec2(
                        this->StartPos.x + (this->TargetPos.x - this->StartPos.x) * eased,
                        this->StartPos.y + (this->TargetPos.y - this->StartPos.y) * eased
                    );

                    // ── Add subtle micro-wobble during drag (human hand shake) ──
                    float handWobble = sinf(this->ElapsedTime * 25.0f) * 0.15f;
                    NativeTouchesMove(this->TouchIndex, this->CurrentPos.x + handWobble, this->CurrentPos.y);
                } else {
                    // Ensure we hit the target exactly
                    this->CurrentPos = this->TargetPos;
                    NativeTouchesMove(this->TouchIndex, this->CurrentPos.x, this->CurrentPos.y);
                    this->ElapsedTime = 0.f;
                    this->state = WOBBLE_END;
                    this->wobbleElapsed = 0.f;
                    this->wobbleTimer = 0.f;
                    // End wobble: shorter than start
                    this->wobbleDuration = 0.06f + NextRand() * 0.08f;
                    this->wobbleAmplitude = 0.5f + NextRand() * 1.0f;
                }
            }

            if (dynamic_bool["DebugTouch"]) {
                ImDrawList* fg = ImGui::GetForegroundDrawList();
                fg->AddCircleFilled(this->CurrentPos, 15.0f, IM_COL32(255, 255, 255, 100));
                fg->AddCircle(this->CurrentPos, 15.0f, IM_COL32(255, 255, 255, 200), 0.0f, 2.0f);
            }
        }
        
        // ── WOBBLE_END: Final micro-wobble at target position before release ──
        if (this->state == WOBBLE_END) {
            this->wobbleElapsed += dt;
            this->wobbleTimer += dt * this->wobbleFrequency;
            
            float decay = 1.0f - (this->wobbleElapsed / this->wobbleDuration);
            if (decay < 0) decay = 0;
            
            float wobbleX = sinf(this->wobbleTimer * 1.1f) * this->wobbleAmplitude * decay;
            float wobbleY = cosf(this->wobbleTimer * 1.4f) * this->wobbleAmplitude * 0.4f * decay;
            
            ImVec2 wobbleEndPos = ImVec2(this->TargetPos.x + wobbleX, this->TargetPos.y + wobbleY);
            NativeTouchesMove(this->TouchIndex, wobbleEndPos.x, wobbleEndPos.y);
            
            if (this->wobbleElapsed >= this->wobbleDuration) {
                // Settle exactly on target
                NativeTouchesMove(this->TouchIndex, this->TargetPos.x, this->TargetPos.y);
                this->CurrentPos = this->TargetPos;
                this->HoldTime = 0.f;
                this->state = ENDING;
            }
            
            if (dynamic_bool["DebugTouch"]) {
                ImDrawList* fg = ImGui::GetForegroundDrawList();
                fg->AddCircleFilled(wobbleEndPos, 15.0f, IM_COL32(255, 200, 100, 100));
                fg->AddCircle(wobbleEndPos, 15.0f, IM_COL32(255, 200, 100, 200), 0.0f, 2.0f);
            }
        }

        if (this->state == ENDING) {
            this->HoldTime += dt;
            if (this->HoldTime >= this->HoldDuration) {
                if (IsShotValid()) {
                    this->End();
                } else {
                    LOGI("Shot invalid before release. Canceling.");
                    this->Cancel();
                }
            }
        }

        if (this->state == RETURNING) {
            this->ElapsedTime += dt;

            if (this->ElapsedTime < this->Duration) {
                float t = this->ElapsedTime / this->Duration;
                float eased = EaseInOutCubic(t);
                this->CurrentPos = ImVec2(
                    this->EndPos.x + (this->TargetPos.x - this->EndPos.x) * eased,
                    this->EndPos.y + (this->TargetPos.y - this->EndPos.y) * eased
                );
                NativeTouchesMove(this->TouchIndex, this->CurrentPos.x, this->CurrentPos.y);
            } else {
                this->CurrentPos = this->TargetPos;
                NativeTouchesMove(this->TouchIndex, this->CurrentPos.x, this->CurrentPos.y);
                End();
            }

            if (dynamic_bool["DebugTouch"]) {
                ImDrawList* fg = ImGui::GetForegroundDrawList();
                fg->AddCircleFilled(this->CurrentPos, 15.0f, IM_COL32(255, 255, 255, 100));
                fg->AddCircle(this->CurrentPos, 15.0f, IM_COL32(255, 255, 255, 200), 0.0f, 2.0f);
            }
        }

    }
};


// Definition moved to main.cpp or a single translation unit
// PowerSlider powerSlider;
