#ifndef KEYLOGIN_H
#define KEYLOGIN_H

#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include <random>
#include <chrono>
#include <ctime>
#include <vector>
#include <algorithm>
#include <curl/curl.h>
#include <map>
#include <mutex>
#include <atomic>
#include <thread>
#include <cstring>


#include "obfuscate.h"

// ============================================
// Server Configuration
// ============================================

const std::string API_BASE_URL = OBFUSCATE("https://eyad.vipx.space/connect");
const std::string API_VALIDATE_URL = OBFUSCATE("https://eyad.vipx.space/validate");
const std::string API_LOG_URL = OBFUSCATE("https://eyad.vipx.space/log_security");
const std::string DEFAULT_GAME = "pubg";

// ============================================
// Global Variables
// ============================================

extern bool bValid;
extern bool logged_in;
extern bool is_logging_in;
extern std::string g_Token;
extern std::string g_Auth;
extern std::string g_ExpTime;
extern std::string ERROR_MESSAGE;
extern int64_t g_server_time_offset;  // offset in seconds: server_time - local_time
extern std::string g_server_exp_raw;  // raw expiry string from server (exact as sent)
extern int64_t g_expiry_timestamp;   // parsed expiry as unix timestamp
extern std::atomic<bool> g_key_revoked; // set to true if server says key is invalid during re-check
extern std::string g_server_time_str; // server time string for display

// Default values
bool bValid = false;
bool logged_in = false;
bool is_logging_in = false;
std::string g_Token = "";
std::string g_Auth = "";
std::string g_ExpTime = "N/A";
std::string ERROR_MESSAGE = "";
int64_t g_server_time_offset = 0;
std::string g_server_exp_raw = "";
int64_t g_expiry_timestamp = 0;
std::atomic<bool> g_key_revoked(false);
std::string g_server_time_str = "";
static std::mutex g_login_mutex;
static std::atomic<bool> g_is_revalidating(false);

// ============================================
// HTTP Functions
// ============================================

size_t WriteCallback(void* contents, size_t size, size_t nmemb, std::string* response) {
    size_t totalSize = size * nmemb;
    response->append((char*)contents, totalSize);
    return totalSize;
}

std::string urlEncode(const std::string& value) {
    CURL* curl = curl_easy_init();
    if (!curl) return value;
    char* encoded = curl_easy_escape(curl, value.c_str(), (int)value.length());
    std::string result(encoded ? encoded : value);
    if (encoded) curl_free(encoded);
    curl_easy_cleanup(curl);
    return result;
}

std::string httpPost(const std::string& url, const std::string& postData, long timeout = 15L) {
    CURL* curl = curl_easy_init();
    std::string response;

    if (!curl) {
        ERROR_MESSAGE = "Failed to initialize HTTP client";
        return "";
    }

    curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
    curl_easy_setopt(curl, CURLOPT_POST, 1L);
    curl_easy_setopt(curl, CURLOPT_POSTFIELDS, postData.c_str());
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);
    curl_easy_setopt(curl, CURLOPT_TIMEOUT, timeout);
    curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT, 10L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);
    curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);

    struct curl_slist* headers = NULL;
    headers = curl_slist_append(headers, "Content-Type: application/x-www-form-urlencoded");
    curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);

    CURLcode res = curl_easy_perform(curl);

    if (res != CURLE_OK) {
        ERROR_MESSAGE = "Connection failed: " + std::string(curl_easy_strerror(res));
    }

    curl_slist_free_all(headers);
    curl_easy_cleanup(curl);

    return response;
}

// ============================================
// JSON Parser (improved, no external libs)
// ============================================

std::string extractJsonString(const std::string& json, const std::string& key) {
    std::string searchKey = "\"" + key + "\"";
    size_t keyPos = json.find(searchKey);
    if (keyPos == std::string::npos) return "";

    size_t colonPos = json.find(':', keyPos + searchKey.length());
    if (colonPos == std::string::npos) return "";

    // Skip whitespace after colon
    size_t valueStart = colonPos + 1;
    while (valueStart < json.length() && (json[valueStart] == ' ' || json[valueStart] == '\t' || json[valueStart] == '\n' || json[valueStart] == '\r')) {
        valueStart++;
    }

    if (valueStart >= json.length()) return "";

    // If value is a string (starts with quote)
    if (json[valueStart] == '"') {
        size_t quote1 = valueStart;
        size_t quote2 = json.find('"', quote1 + 1);
        if (quote2 == std::string::npos) return "";
        return json.substr(quote1 + 1, quote2 - quote1 - 1);
    }

    // If value is not a string (number, bool, etc.) - read until comma or closing brace
    size_t valueEnd = json.find_first_of(",}\n\r", valueStart);
    if (valueEnd == std::string::npos) valueEnd = json.length();
    std::string rawVal = json.substr(valueStart, valueEnd - valueStart);
    // Trim whitespace
    while (!rawVal.empty() && (rawVal.back() == ' ' || rawVal.back() == '\t')) rawVal.pop_back();
    return rawVal;
}

bool extractJsonBool(const std::string& json, const std::string& key) {
    std::string searchKey = "\"" + key + "\"";
    size_t keyPos = json.find(searchKey);
    if (keyPos == std::string::npos) return false;

    size_t colonPos = json.find(':', keyPos + searchKey.length());
    if (colonPos == std::string::npos) return false;

    // Skip whitespace after colon
    size_t valueStart = colonPos + 1;
    while (valueStart < json.length() && (json[valueStart] == ' ' || json[valueStart] == '\t')) {
        valueStart++;
    }

    if (valueStart >= json.length()) return false;

    // Find the end of this value (next comma or closing brace at the same nesting level)
    size_t valueEnd = json.length();
    int braceLevel = 0;
    for (size_t i = valueStart; i < json.length(); i++) {
        char c = json[i];
        if (c == '{' || c == '[') braceLevel++;
        else if (c == '}' || c == ']') {
            if (braceLevel == 0) { valueEnd = i; break; }
            braceLevel--;
        }
        else if (c == ',' && braceLevel == 0) {
            valueEnd = i;
            break;
        }
    }

    std::string value = json.substr(valueStart, valueEnd - valueStart);
    // Trim
    while (!value.empty() && (value.front() == ' ' || value.front() == '\t' || value.front() == '\n' || value.front() == '\r'))
        value = value.substr(1);
    while (!value.empty() && (value.back() == ' ' || value.back() == '\t' || value.back() == '\n' || value.back() == '\r'))
        value.pop_back();

    // Check for "true" (exact match)
    if (value == "true") return true;
    // Check for true without quotes
    if (value.length() >= 4 && value.substr(0, 4) == "true" &&
        (value.length() == 4 || value[4] == ',' || value[4] == ' ' || value[4] == '\n' || value[4] == '\r' || value[4] == '}'))
        return true;

    return false;
}

// Extract a number (int64) from JSON
int64_t extractJsonInt64(const std::string& json, const std::string& key) {
    std::string raw = extractJsonString(json, key);
    if (raw.empty()) return 0;
    try {
        // Remove quotes if present
        if (!raw.empty() && raw.front() == '"' && raw.back() == '"') {
            raw = raw.substr(1, raw.length() - 2);
        }
        return (int64_t)std::stoll(raw);
    } catch (...) {
        return 0;
    }
}

// ============================================
// Server Time Synchronization
// ============================================

// Get current time adjusted by server offset
int64_t getAdjustedTime() {
    return (int64_t)time(nullptr) + g_server_time_offset;
}

// Parse various date/time formats to unix timestamp
int64_t parseDateTimeToTimestamp(const std::string& dateStr) {
    if (dateStr.empty() || dateStr == "N/A") return 0;

    // Try pure unix timestamp number first
    try {
        size_t endPos;
        int64_t ts = std::stoll(dateStr, &endPos);
        // If the entire string is a number, treat as timestamp
        if (endPos == dateStr.length()) return ts;
    } catch (...) {}

    // Try format: YYYY-MM-DD HH:MM:SS
    int y = 0, mo = 0, d = 0, h = 0, mi = 0, s = 0;
    if (sscanf(dateStr.c_str(), "%d-%d-%d %d:%d:%d", &y, &mo, &d, &h, &mi, &s) >= 3) {
        struct tm tmg = {};
        tmg.tm_year = y - 1900;
        tmg.tm_mon  = mo - 1;
        tmg.tm_mday = d;
        tmg.tm_hour = h;
        tmg.tm_min  = mi;
        tmg.tm_sec  = s;
        tmg.tm_isdst = -1;
        return (int64_t)mktime(&tmg);
    }

    // Try format: YYYY/MM/DD HH:MM:SS
    if (sscanf(dateStr.c_str(), "%d/%d/%d %d:%d:%d", &y, &mo, &d, &h, &mi, &s) >= 3) {
        struct tm tmg = {};
        tmg.tm_year = y - 1900;
        tmg.tm_mon  = mo - 1;
        tmg.tm_mday = d;
        tmg.tm_hour = h;
        tmg.tm_min  = mi;
        tmg.tm_sec  = s;
        tmg.tm_isdst = -1;
        return (int64_t)mktime(&tmg);
    }

    // Try format: YYYY-MM-DDTHH:MM:SS (ISO 8601)
    if (sscanf(dateStr.c_str(), "%d-%d-%dT%d:%d:%d", &y, &mo, &d, &h, &mi, &s) >= 3) {
        struct tm tmg = {};
        tmg.tm_year = y - 1900;
        tmg.tm_mon  = mo - 1;
        tmg.tm_mday = d;
        tmg.tm_hour = h;
        tmg.tm_min  = mi;
        tmg.tm_sec  = s;
        tmg.tm_isdst = -1;
        return (int64_t)mktime(&tmg);
    }

    return 0;
}

// ============================================
// HWID
// ============================================

std::string getHWID() {
    std::ifstream hwid_file(".hwid");
    if (hwid_file.is_open()) {
        std::string id;
        std::getline(hwid_file, id);
        hwid_file.close();
        if (!id.empty()) return id;
    }

    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<> dis(0, 15);
    const char* chars = "0123456789ABCDEF";
    std::string hwid;
    for (int i = 0; i < 32; i++) {
        hwid += chars[dis(gen)];
    }

    std::ofstream out_file(".hwid");
    if (out_file.is_open()) {
        out_file << hwid;
        out_file.close();
    }

    return hwid;
}

// ============================================
// Server Verification
// ============================================

/**
 * Verify license key with the server.
 * Returns true ONLY if server responds with "status":true.
 * Extracts: expiry time, server time, token.
 * Computes time offset for local sync.
 */
bool verifyWithYourServer(const std::string& license_key, const std::string& hwid) {
    std::string postData = "game=" + urlEncode(DEFAULT_GAME) +
                           "&user_key=" + urlEncode(license_key) +
                           "&serial=" + urlEncode(hwid);

    // Clear previous error
    ERROR_MESSAGE = "";

    // Record local time before and after request to compute RTT
    int64_t local_before = (int64_t)time(nullptr);

    std::string response = httpPost(API_BASE_URL, postData);

    int64_t local_after = (int64_t)time(nullptr);

    if (response.empty()) {
        ERROR_MESSAGE = "No response from server - check your internet connection";
        return false;
    }

    // Trim response
    while (!response.empty() && (response.front() == ' ' || response.front() == '\n' || response.front() == '\r'))
        response = response.substr(1);
    while (!response.empty() && (response.back() == ' ' || response.back() == '\n' || response.back() == '\r'))
        response.pop_back();

    // Check for valid JSON response
    if (response.empty() || response[0] != '{') {
        ERROR_MESSAGE = "Invalid server response";
        return false;
    }

    // Strict check: "status":true (exact)
    bool statusOk = false;
    if (response.find("\"status\":true") != std::string::npos) statusOk = true;
    else if (response.find("\"status\": true") != std::string::npos) statusOk = true;

    // Advanced Protection: Integrity Check
    if (statusOk) {
        std::string checksum = extractJsonString(response, "hash");
        if (!checksum.empty()) {
            // التحقق من سلامة البيانات المستقبلة (يمكن إضافة منطق تشفير هنا)
        }
    }

    if (!statusOk) {
        // Extract error reason from server
        std::string reason = extractJsonString(response, "reason");
        if (reason.empty()) reason = extractJsonString(response, "message");
        if (reason.empty()) reason = extractJsonString(response, "error");
        if (!reason.empty()) {
            ERROR_MESSAGE = reason;
        } else {
            ERROR_MESSAGE = "Invalid license key";
        }
        return false;
    }

    // === SUCCESS: Extract all data from server response ===

    // Extract expiry time (raw string - preserve exactly as server sent it)
    std::string expiry = extractJsonString(response, "EXP");
    if (expiry.empty()) {
        expiry = extractJsonString(response, "exp");
    }
    if (expiry.empty()) {
        expiry = extractJsonString(response, "expiry");
    }
    if (expiry.empty()) {
        expiry = extractJsonString(response, "expires_at");
    }

    if (!expiry.empty() && expiry != "N/A") {
        g_ExpTime = expiry;            // Keep raw string from server
        g_server_exp_raw = expiry;     // Keep another copy (raw, for display)
        g_expiry_timestamp = parseDateTimeToTimestamp(expiry);
    } else {
        g_ExpTime = "N/A";
        g_server_exp_raw = "";
        g_expiry_timestamp = 0;
    }

    // Extract server time if available (for time sync)
    std::string serverTimeStr = extractJsonString(response, "server_time");
    if (serverTimeStr.empty()) serverTimeStr = extractJsonString(response, "time");
    if (serverTimeStr.empty()) serverTimeStr = extractJsonString(response, "now");

    if (!serverTimeStr.empty()) {
        g_server_time_str = serverTimeStr;
        int64_t server_ts = parseDateTimeToTimestamp(serverTimeStr);
        if (server_ts > 0) {
            // Use midpoint of request time as best estimate of local time during server processing
            int64_t local_mid = local_before + (local_after - local_before) / 2;
            g_server_time_offset = server_ts - local_mid;
        }
    } else {
        // If server doesn't provide time, assume no offset
        g_server_time_offset = 0;
        g_server_time_str = "";
    }

    // Extract token if available
    std::string token = extractJsonString(response, "token");
    if (!token.empty()) {
        g_Token = token;
        g_Auth = token;
    }

    // Check if already expired on server
    if (g_expiry_timestamp > 0) {
        int64_t adjustedNow = getAdjustedTime();
        if (adjustedNow >= g_expiry_timestamp) {
            ERROR_MESSAGE = "License key has expired";
            return false;
        }
    }

    return true;
}

// ============================================
// Periodic Re-validation
// ============================================

/**
 * Re-validate the current key with the server.
 * Called periodically in background to check if key is still valid.
 */
void revalidateKeyPeriodic(const std::string& license_key, const std::string& hwid) {
    if (g_is_revalidating.load()) return;
    g_is_revalidating.store(true);

    std::string postData = "game=" + urlEncode(DEFAULT_GAME) +
                           "&user_key=" + urlEncode(license_key) +
                           "&serial=" + urlEncode(hwid);

    std::string response = httpPost(API_BASE_URL, postData);

    g_is_revalidating.store(false);

    if (response.empty()) {
        // Network error - don't revoke, just skip this check
        // The key remains valid until we get a definitive "invalid" from server
        return;
    }

    // Trim response
    while (!response.empty() && (response.front() == ' ' || response.front() == '\n' || response.front() == '\r'))
        response = response.substr(1);
    while (!response.empty() && (response.back() == ' ' || response.back() == '\n' || response.back() == '\r'))
        response.pop_back();

    if (response.empty() || response[0] != '{') return;

    bool statusOk = false;
    if (response.find("\"status\":true") != std::string::npos) statusOk = true;
    else if (response.find("\"status\": true") != std::string::npos) statusOk = true;

    if (!statusOk) {
        // Server says key is no longer valid - revoke immediately
        g_key_revoked.store(true);
        logged_in = false;
        bValid = false;
        g_Token = "";
        g_Auth = "";
        g_ExpTime = "N/A";
        g_server_exp_raw = "";
        g_expiry_timestamp = 0;

        std::string reason = extractJsonString(response, "reason");
        if (reason.empty()) reason = extractJsonString(response, "message");
        if (reason.empty()) reason = extractJsonString(response, "error");
        if (!reason.empty()) {
            ERROR_MESSAGE = reason;
        } else {
            ERROR_MESSAGE = "License key has been disabled";
        }
        return;
    }

    // Key is still valid - update expiry from server
    std::string expiry = extractJsonString(response, "EXP");
    if (expiry.empty()) expiry = extractJsonString(response, "exp");
    if (expiry.empty()) expiry = extractJsonString(response, "expiry");
    if (expiry.empty()) expiry = extractJsonString(response, "expires_at");

    if (!expiry.empty() && expiry != "N/A") {
        g_ExpTime = expiry;
        g_server_exp_raw = expiry;
        g_expiry_timestamp = parseDateTimeToTimestamp(expiry);
    }

    // Update server time sync
    std::string serverTimeStr = extractJsonString(response, "server_time");
    if (serverTimeStr.empty()) serverTimeStr = extractJsonString(response, "time");
    if (serverTimeStr.empty()) serverTimeStr = extractJsonString(response, "now");
    if (!serverTimeStr.empty()) {
        g_server_time_str = serverTimeStr;
        int64_t server_ts = parseDateTimeToTimestamp(serverTimeStr);
        if (server_ts > 0) {
            g_server_time_offset = server_ts - (int64_t)time(nullptr);
        }
    }
}

/**
 * Check if key should be re-validated and spawn thread if needed.
 * Call this periodically (e.g., every Draw frame).
 */
static std::chrono::steady_clock::time_point g_last_revalidate_time;
static bool g_revalidate_initialized = false;

void maybeRevalidateKey(const std::string& license_key, const std::string& hwid) {
    if (!logged_in || license_key.empty()) return;

    if (!g_revalidate_initialized) {
        g_last_revalidate_time = std::chrono::steady_clock::now();
        g_revalidate_initialized = true;
        return;
    }

    auto now = std::chrono::steady_clock::now();
    auto elapsed = std::chrono::duration_cast<std::chrono::seconds>(now - g_last_revalidate_time).count();

    // Re-validate every 60 seconds
    if (elapsed >= 60) {
        g_last_revalidate_time = now;
        std::string key_copy = license_key;
        std::string hwid_copy = hwid;
        std::thread([key_copy, hwid_copy]() {
            revalidateKeyPeriodic(key_copy, hwid_copy);
        }).detach();
    }
}

// ============================================
// Check Expiry (real-time, using server-adjusted time)
// ============================================

bool isKeyExpired() {
    if (g_key_revoked.load()) return true;
    if (g_expiry_timestamp <= 0) return false;  // No expiry set

    int64_t adjustedNow = getAdjustedTime();
    return adjustedNow >= g_expiry_timestamp;
}

// ============================================
// Main Login Function
// ============================================

bool Login(std::string androidID, std::string key) {
    std::lock_guard<std::mutex> lock(g_login_mutex);

    is_logging_in = true;
    ERROR_MESSAGE = "";

    if (androidID.empty()) {
        ERROR_MESSAGE = "Cannot get device ID";
        is_logging_in = false;
        return false;
    }

    if (key.empty()) {
        ERROR_MESSAGE = "License key is empty";
        is_logging_in = false;
        return false;
    }

    // Trim whitespace from key
    while (!key.empty() && (key.front() == ' ' || key.front() == '\n' || key.front() == '\r' || key.front() == '\t'))
        key = key.substr(1);
    while (!key.empty() && (key.back() == ' ' || key.back() == '\n' || key.back() == '\r' || key.back() == '\t'))
        key.pop_back();

    if (key.empty()) {
        ERROR_MESSAGE = "License key is empty";
        is_logging_in = false;
        return false;
    }

    // Verify with server - this is the ONLY way to log in
    if (verifyWithYourServer(key, androidID)) {
        logged_in = true;
        g_Token = key;
        g_Auth = key;
        bValid = true;
        g_key_revoked.store(false);
        is_logging_in = false;

        // Reset revalidate timer
        g_revalidate_initialized = false;
        g_last_revalidate_time = std::chrono::steady_clock::now();

        return true;
    }

    // Verification failed
    logged_in = false;
    g_Token = "";
    g_Auth = "";
    bValid = false;
    g_key_revoked.store(false);
    is_logging_in = false;

    return false;
}

/**
 * Login using saved key - re-verifies with server.
 * Used for session restore.
 */
bool LoginWithSavedKey(const std::string& saved_key) {
    if (saved_key.empty()) return false;

    // Must get Android ID and verify with server
    JNIEnv* env = nullptr;
    jint getEnvResult = VM->GetEnv((void**)&env, JNI_VERSION_1_6);
    if (getEnvResult == JNI_EDETACHED) {
        if (VM->AttachCurrentThread(&env, nullptr) != 0) return false;
    } else if (getEnvResult != JNI_OK) {
        return false;
    }

    std::string androidId = "";
    if (env) {
        androidId = getAndroidID(env);
    }

    if (androidId.empty()) return false;

    return Login(androidId, saved_key);
}

#endif // KEYLOGIN_H