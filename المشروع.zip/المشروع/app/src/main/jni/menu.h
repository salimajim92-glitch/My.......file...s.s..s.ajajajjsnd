#pragma once

#include <Vector/Vectors.h>
#include <imgui/imgui.h>

#include "icons/icons.h"

using namespace ImGui;
using namespace std;

#include "include/includes.h"

#include "game.h"
#include "game/Ruleset.h"
#include "imgui/inc/8bp.h"
#include "mod/keylogin.h"
#include "oxorany/oxorany.h"

#include <EGL/egl.h>
#include <EGL/eglext.h>
#include <GLES3/gl3.h>
#include <sys/system_properties.h>
#include <ctime>
#include "font_arial.h"

struct MenuState {
    bool isOpen = false;
    float menuWidth = 750.0f;
    float animProgress = 0.0f;
    float menuAlpha = 0.0f;
    float menuScale = 0.9f;
    ImVec4 accentColor = ImVec4(0.83f, 0.69f, 0.22f, 1.0f);
};
static MenuState g_menu;

// EXPIRY_TS removed — expiry date now comes from server (livai.online) via g_ExpTime
// DEBUG_BYPASS_LOGIN removed for security — all auth goes through server only

// ─── Design tokens ────────────────────────────────────────────────────────────
// Obsidian & Neon Cyan VIP palette — Modern Tech Style
#define CLR_BG_DEEP         IM_COL32(  2,   4,   8, 255)
#define CLR_BG_PANEL        IM_COL32(  8,  12,  24, 255)
#define CLR_BG_CARD         IM_COL32( 12,  18,  36, 255)
#define CLR_BG_HOVER        IM_COL32( 20,  40,  80, 200)
#define CLR_ACCENT_BLUE_VIP    IM_COL32(  0, 255, 255, 255) // Neon Cyan
#define CLR_ACCENT_BLUE_MID    IM_COL32(  0, 200, 255, 255)
#define CLR_ACCENT_BLUE_DIM    IM_COL32(  0, 100, 150, 180)
#define CLR_ACCENT_PURPLE      IM_COL32(124,  58, 237, 255)
#define CLR_ACCENT_PURPLE_MID  IM_COL32(139,  92, 246, 255)
#define CLR_ACCENT_PURPLE_DIM  IM_COL32( 79,  52, 186, 180)
#define CLR_CYAN_BRIGHT     IM_COL32(  0, 255, 255, 255) 
#define CLR_CYAN_MID        IM_COL32(  0, 220, 255, 255)
#define CLR_CYAN_DIM        IM_COL32(  0, 150, 180, 140)
#define CLR_CORAL           IM_COL32(255,  80,  80, 255)
#define CLR_CORAL_MID       IM_COL32(240,  60,  60, 255)
#define CLR_CORAL_DIM       IM_COL32(200,  40,  40, 140)
#define CLR_GOLD            IM_COL32(  0, 255, 255, 255) // Redirected to Cyan
#define CLR_GOLD_MID        IM_COL32(  0, 200, 255, 255)
#define CLR_GOLD_DIM        IM_COL32(  0, 140, 180, 140)
#define CLR_NEON_PURPLE     IM_COL32(160,  80, 255, 255)
#define CLR_NEON_PURPLE_MID IM_COL32(140,  60, 220, 220)
#define CLR_NEON_PURPLE_DIM IM_COL32(100,  40, 160, 140)
#define CLR_EMERALD         IM_COL32(  0, 255, 180, 255)
#define CLR_AMBER           IM_COL32(255, 191,   0, 255)
#define CLR_DIVIDER         IM_COL32( 40,  80, 150, 255)
#define CLR_TEXT_PRIMARY    IM_COL32(240, 245, 255, 255)
#define CLR_TEXT_MUTED      IM_COL32(150, 170, 200, 255)
#define CLR_TEXT_LABEL      IM_COL32(  0, 220, 255, 255)
#define CLR_SELECTED_BG     IM_COL32( 20,  40, 100, 255)
#define CLR_SIDEBAR_BG      IM_COL32(  4,   6,  12, 255)
#define CLR_CLOSE_BASE      IM_COL32( 40,  40,  60, 220)
#define CLR_CLOSE_HOV       IM_COL32(255,  60,  60, 255)
#define CLR_ACCENT_RED_VIP  CLR_ACCENT_BLUE_VIP
// Aliases for backward compatibility
#define CLR_ACCENT_GREEN      CLR_ACCENT_PURPLE
#define CLR_ACCENT_GREEN_MID  CLR_ACCENT_PURPLE_MID
#define CLR_ACCENT_GREEN_DIM  CLR_ACCENT_PURPLE_DIM
#define CLR_INDIGO_BRIGHT     CLR_CYAN_BRIGHT
#define CLR_INDIGO_MID        CLR_CYAN_MID
#define CLR_INDIGO_DIM        CLR_CYAN_DIM
#define CLR_NEON_GREEN        CLR_NEON_PURPLE
#define CLR_NEON_GREEN_MID    CLR_NEON_PURPLE_MID
#define CLR_NEON_GREEN_DIM    CLR_NEON_PURPLE_DIM

// ─── Login Panel VIP Colors — Obsidian + Tech Blue + Neon Cyan ──
#define LOGIN_BG_DEEP         IM_COL32(  2,   4,   8, 255)
#define LOGIN_BG_CARD         IM_COL32(  6,  10,  20, 245)
#define LOGIN_BG_GLASS_TOP    IM_COL32( 10,  20,  45, 180)
#define LOGIN_BG_GLASS_BOT    IM_COL32(  4,   8,  15, 250)
#define LOGIN_BG_INPUT        IM_COL32(  4,   8,  18, 255)
#define LOGIN_BG_INPUT_HL     IM_COL32(  0, 255, 255,  40)
#define LOGIN_CYAN_NEON       IM_COL32(  0, 255, 255, 255)
#define LOGIN_CYAN_MID        IM_COL32(  0, 200, 255, 220)
#define LOGIN_CYAN_DIM        IM_COL32(  0, 120, 180, 150)
#define LOGIN_ELECTRIC_BLUE   IM_COL32(  0, 150, 255, 255)
#define LOGIN_ELECTRIC_MID    IM_COL32(  0, 120, 220, 220)
#define LOGIN_PURPLE          IM_COL32(160,  80, 255, 255)
#define LOGIN_PURPLE_MID      IM_COL32(140,  60, 220, 220)
#define LOGIN_PURPLE_LIGHT    IM_COL32(180, 120, 255, 255)
#define LOGIN_TEXT            IM_COL32(240, 248, 255, 255)
#define LOGIN_TEXT_MUTED      IM_COL32(130, 150, 180, 255)
#define LOGIN_TEXT_LABEL      IM_COL32(  0, 200, 255, 255)
#define LOGIN_TEXT_PLACEHOLDER IM_COL32( 40,  80, 120, 180)

static float EaseOutBack(float x) {
    const float c1 = 1.70158f;
    const float c3 = c1 + 1.0f;
    return 1.0f + c3 * powf(x - 1.0f, 3.0f) + c1 * powf(x - 1.0f, 2.0f);
}

static float EaseOutQuart(float x) {
    return 1.0f - powf(1.0f - x, 4.0f);
}

static void DrawGradientRect(ImDrawList* dl, ImVec2 p1, ImVec2 p2, ImU32 col1, ImU32 col2, bool horizontal = true) {
    if (horizontal) {
        dl->AddRectFilledMultiColor(p1, p2, col1, col2, col2, col1);
    } else {
        dl->AddRectFilledMultiColor(p1, p2, col1, col1, col2, col2);
    }
}

// ─── Violet glowing separator line ────────────────────────────────────────────
static void DrawLightning(ImDrawList* dl, ImVec2 p1, ImVec2 p2, ImU32 col, float thickness) {
    ImVec2 mid = ImVec2((p1.x + p2.x) * 0.5f, (p1.y + p2.y) * 0.5f);
    float dx = p2.x - p1.x;
    float dy = p2.y - p1.y;
    float len = sqrtf(dx*dx + dy*dy);
    ImVec2 normal = ImVec2(-dy/len, dx/len);
    
    static float time = 0.0f;
    time += ImGui::GetIO().DeltaTime;
    
    float offset = sinf(time * 20.0f) * 5.0f;
    ImVec2 pMid = ImVec2(mid.x + normal.x * offset, mid.y + normal.y * offset);
    
    dl->AddLine(p1, pMid, col, thickness);
    dl->AddLine(pMid, p2, col, thickness);
}

static void DrawSeparator(ImDrawList* dl, float x0, float x1, float y, float alpha = 1.0f) {
    int a = (int)(alpha * 255);
    // Outer red glow layers
    dl->AddLine(ImVec2(x0, y - 2), ImVec2(x1, y - 2), IM_COL32(220, 20, 60, (int)(a * 0.12f)), 4.0f);
    dl->AddLine(ImVec2(x0, y + 2), ImVec2(x1, y + 2), IM_COL32(220, 20, 60, (int)(a * 0.12f)), 4.0f);
    dl->AddLine(ImVec2(x0, y - 1), ImVec2(x1, y - 1), IM_COL32(255, 50, 50, (int)(a * 0.22f)), 2.5f);
    dl->AddLine(ImVec2(x0, y + 1), ImVec2(x1, y + 1), IM_COL32(255, 50, 50, (int)(a * 0.22f)), 2.5f);
    // Bright red center line
    float mid = (x0 + x1) * 0.5f;
    dl->AddLine(ImVec2(x0,  y), ImVec2(mid, y), IM_COL32(255, 200, 200, (int)(a * 0.65f)), 1.0f);
    dl->AddLine(ImVec2(mid, y), ImVec2(x1,  y), IM_COL32(255, 230, 230, (int)(a * 0.75f)), 1.0f);
}

// ─── Large interactive toggle switch — Luxurious Gold Redesign ──────────────────
static bool ToggleSwitch(const char* label, bool* v) {
    ImGuiWindow* window = GetCurrentWindow();
    if (window->SkipItems) return false;

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;
    const ImGuiID id = window->GetID(label);

    float height = 28.0f; // تقليل ارتفاع المفاتيح
    float width  = 50.0f; // تقليل عرض المفاتيح
    float radius = height * 0.5f;

    SetWindowFontScale(0.9f); // تصغير الخط قليلاً
    ImVec2 textSize = CalcTextSize(label);
    ImVec2 pos  = window->DC.CursorPos;
    ImVec2 size = ImVec2(GetContentRegionAvail().x,
                         ImMax(height, textSize.y) + style.FramePadding.y * 2 + 6.0f); // تقليل الحشو الرأسي لضغط القائمة

    const ImRect bb(pos, pos + size);
    ItemSize(size, style.FramePadding.y);
    if (!ItemAdd(bb, id)) return false;

    bool hovered, held;
    bool pressed = ButtonBehavior(bb, id, &hovered, &held);
    if (pressed) *v = !*v;

    static std::map<ImGuiID, float> switchAnim;
    float& animT  = switchAnim[id];
    float  targetT = *v ? 1.0f : 0.0f;
    animT += (targetT - animT) * g.IO.DeltaTime * 14.0f;

    ImDrawList* dl = window->DrawList;

    // ── Animated flowing gradient background behind button ──
    {
        static float g_bgFlowTime = 0.0f;
        g_bgFlowTime += g.IO.DeltaTime;
        float flowPhase = g_bgFlowTime * 1.8f;
        float waveAlpha = 0.15f + 0.08f * sinf(flowPhase + (float)id * 0.15f);

        // Animated gradient sweep across the row
        float sweepX = bb.Min.x + (bb.Max.x - bb.Min.x) * (0.5f + 0.5f * sinf(flowPhase * 0.8f + (float)id * 0.4f));
        float sweepW = 100.0f + 40.0f * sinf(flowPhase * 1.5f);
        ImVec2 sweepMin(sweepX - sweepW * 0.5f, bb.Min.y);
        ImVec2 sweepMax(sweepX + sweepW * 0.5f, bb.Max.y);

        // Clip to row bounds
        dl->PushClipRect(bb.Min, bb.Max, true);
        dl->AddRectFilled(bb.Min, bb.Max, IM_COL32(10, 15, 30, 220), 14.0f);
        // Flowing cyan gradient sweep
        dl->AddRectFilledMultiColor(
            sweepMin, sweepMax,
            IM_COL32(0, 255, 255, (int)(waveAlpha * 255)),
            IM_COL32(0, 150, 255, (int)(waveAlpha * 200)),
            IM_COL32(0, 150, 255, (int)(waveAlpha * 200)),
            IM_COL32(0, 255, 255, (int)(waveAlpha * 255))
        );
        dl->PopClipRect();

        // Subtle border around the entire row
        dl->AddRect(bb.Min, bb.Max, IM_COL32(0, 200, 255, 80), 14.0f, 0, 1.2f);
    }

    // Row hover overlay — luxurious gold highlight
    if (hovered) {
        dl->AddRectFilled(bb.Min, bb.Max, IM_COL32(55, 45, 110, 180), 12.0f);
        // Left accent bar — violet
        dl->AddRectFilled(bb.Min, ImVec2(bb.Min.x + 3.0f, bb.Max.y), IM_COL32(167, 139, 250, 180), 12.0f);
    }

    // Row bottom divider
    dl->AddLine(
        ImVec2(bb.Min.x + 6.0f,  bb.Max.y - 1.0f),
        ImVec2(bb.Max.x - 6.0f,  bb.Max.y - 1.0f),
        IM_COL32(70, 60, 100, 200), 1.0f
    );

    // Switch track
    ImVec2 togglePos = ImVec2(bb.Max.x - width - 16.0f, bb.Min.y + (size.y - height) * 0.5f);
    ImVec2 toggleEnd = ImVec2(togglePos.x + width, togglePos.y + height);

    // Track fill: dark obsidian off → vibrant cyan on
    ImVec4 offColor = ImVec4(0.05f, 0.08f, 0.15f, 1.0f);
    ImVec4 onColor  = ImVec4(0.00f, 0.80f, 1.00f, 1.0f);
    ImVec4 bgColorV = ImLerp(offColor, onColor, animT);
    dl->AddRectFilled(togglePos, toggleEnd, ImColor(bgColorV), radius);

    // ON gradient overlay: cyan → electric blue neon
    if (animT > 0.05f) {
        dl->AddRectFilledMultiColor(
            togglePos, toggleEnd,
            IM_COL32(0, 255, 255, (int)(animT * 220)),
            IM_COL32(0, 150, 255, (int)(animT * 220)),
            IM_COL32(0, 150, 255, (int)(animT * 220)),
            IM_COL32(0, 255, 255, (int)(animT * 220))
        );
    }

    // OFF border
    if (animT < 0.5f) {
        dl->AddRect(togglePos, toggleEnd, IM_COL32(40, 80, 120, 140), radius, 0, 1.5f);
    }

    // ON glow rings
    if (animT > 0.3f) {
        dl->AddRect(togglePos, toggleEnd, IM_COL32(0, 180, 255, (int)(animT * 60)), radius + 3.0f, 0, 3.0f);
        dl->AddRect(togglePos, toggleEnd, IM_COL32(0, 255, 255, (int)(animT * 40)), radius + 2.0f, 0, 2.0f);
    }

    // Knob
    float knobX = togglePos.x + radius + (width - height) * animT;
    float knobY  = togglePos.y + radius;
    float knobR  = radius - 4.0f;

    // Shadow
    dl->AddCircleFilled(ImVec2(knobX, knobY + 2.0f), knobR + 1.0f, IM_COL32(0, 0, 0, 80));
    // Glow when on — Cyan/Electric glow
    if (animT > 0.3f) {
        dl->AddCircleFilled(ImVec2(knobX, knobY), knobR + 4.0f, IM_COL32(0, 180, 255, (int)(animT * 80)));
        dl->AddCircleFilled(ImVec2(knobX, knobY), knobR + 6.0f, IM_COL32(0, 255, 255, (int)(animT * 40)));
    }
    // Knob face: Modern Circular/Diamond design
    if (animT > 0.5f) {
        dl->AddCircleFilled(ImVec2(knobX, knobY), knobR, IM_COL32(255, 255, 255, 255));
        // Draw checkmark
        dl->AddLine(ImVec2(knobX - knobR*0.5f, knobY), ImVec2(knobX - knobR*0.1f, knobY + knobR*0.4f), IM_COL32(0, 180, 255, 255), 2.5f);
        dl->AddLine(ImVec2(knobX - knobR*0.1f, knobY + knobR*0.4f), ImVec2(knobX + knobR*0.5f, knobY - knobR*0.4f), IM_COL32(0, 180, 255, 255), 2.5f);
    } else {
        dl->AddCircleFilled(ImVec2(knobX, knobY), knobR, IM_COL32(100, 120, 150, 255));
        // Draw X mark
        dl->AddLine(ImVec2(knobX - knobR*0.4f, knobY - knobR*0.4f), ImVec2(knobX + knobR*0.4f, knobY + knobR*0.4f), IM_COL32(255, 255, 255, 150), 2.0f);
        dl->AddLine(ImVec2(knobX + knobR*0.4f, knobY - knobR*0.4f), ImVec2(knobX - knobR*0.4f, knobY + knobR*0.4f), IM_COL32(255, 255, 255, 150), 2.0f);
    }

    // Label
    SetWindowFontScale(1.02f);
    ImU32 labelCol = animT > 0.5f ? CLR_ACCENT_RED_VIP : CLR_TEXT_LABEL;
    dl->AddText(ImVec2(bb.Min.x + 16.0f, bb.Min.y + (size.y - textSize.y) * 0.5f), labelCol, label);
    SetWindowFontScale(1.0f);

    return pressed;
}

// File-scope so DrawToggleButton cancel can also reset countdown
static bool g_aqCounting = false;
static std::chrono::steady_clock::time_point g_aqLastCall;
static std::chrono::steady_clock::time_point g_aqCountdownStart;


static bool IsExpired() {
    // Check if key was revoked by server during re-validation
    if (g_key_revoked.load()) return true;

    // Check if expiry timestamp from server has passed (using server-adjusted time)
    if (g_expiry_timestamp > 0) {
        int64_t adjustedNow = getAdjustedTime();
        if (adjustedNow >= g_expiry_timestamp) return true;
    }

    return false;
}

// Parse server expiry date string to unix timestamp
static int64_t ParseExpiryToTimestamp(const std::string& dateStr) {
    return parseDateTimeToTimestamp(dateStr);
}

INLINE void DrawExpired(ImGuiIO& io) {
    float winW = g_menu.menuWidth;

    SetNextWindowPos(ImVec2(io.DisplaySize.x * 0.5f, io.DisplaySize.y * 0.5f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));
    SetNextWindowSize(ImVec2(winW, 0), ImGuiCond_Always);
    PushStyleColor(ImGuiCol_WindowBg, IM_COL32(10, 10, 22, 255));
    PushStyleColor(ImGuiCol_Border,   IM_COL32(139, 92, 246, 180));
    PushStyleVar(ImGuiStyleVar_WindowRounding,  20.0f);
    PushStyleVar(ImGuiStyleVar_WindowPadding,   ImVec2(30.0f, 30.0f));
    PushStyleVar(ImGuiStyleVar_WindowBorderSize, 2.0f);

    if (Begin(O("##ExpiredWin"), nullptr,
              ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove |
              ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoSavedSettings |
              ImGuiWindowFlags_AlwaysAutoResize)) {

        ImDrawList* dl = GetWindowDrawList();
        ImVec2 wp = GetWindowPos();
        ImVec2 ws = GetWindowSize();

        // Ambient glow border layers — violet premium
        dl->AddRect(wp, ImVec2(wp.x + ws.x, wp.y + ws.y), IM_COL32(139, 92, 246, 40), 22.0f, 0, 7.0f);
        dl->AddRect(wp, ImVec2(wp.x + ws.x, wp.y + ws.y), IM_COL32(167, 139, 250, 30), 24.0f, 0, 9.0f);

        SetWindowFontScale(1.6f);
        ImVec2 titleSz = CalcTextSize(O("FAN GAMAL"));
        SetCursorPosX((winW - 60.0f - titleSz.x) * 0.5f);
        TextColored(ImVec4(0.65f, 0.55f, 0.97f, 1.0f), "%s", O("FAN GAMAL"));
        SetWindowFontScale(1.0f);

        Dummy(ImVec2(0, 16));

        PushTextWrapPos(GetCursorPosX() + winW - 60.0f);
        TextColored(ImVec4(0.90f, 0.87f, 0.80f, 1.0f), "%s",
            g_key_revoked.load()
                ? O("License key has been disabled. Contact @FG_4Q on Telegram")
                : O("License key has expired. Contact @FG_4Q on Telegram"));
        PopTextWrapPos();

        Dummy(ImVec2(0, 10));
    }
    End();
    PopStyleVar(3);
    PopStyleColor(2);
}

INLINE void DrawAutoQueue() {
    if (!g_Token.empty() && !g_Auth.empty() && g_Token == g_Auth) {
        auto now = std::chrono::steady_clock::now();

        if (std::chrono::duration_cast<std::chrono::milliseconds>(now - g_aqLastCall).count() > 500)
            g_aqCounting = false;
        g_aqLastCall = now;

        if (!g_aqCounting) {
            g_aqCounting = true;
            g_aqCountdownStart = now;
        }

        auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(now - g_aqCountdownStart).count();
        int remaining_ms = 3000 - (int)elapsed; // وقت

        if (remaining_ms <= 0) {
            if (sharedMenuManager.getMenuStateId() == 13) PopMenuState(13);
            StartLastMatch();
            g_aqCounting = false;
            return;
        }

        std::string count_str = std::to_string((remaining_ms / 1000) + 1);

        SetNextWindowPos(ImVec2(Width * 0.5f, Height * 0.5f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));
        PushStyleColor(ImGuiCol_WindowBg, ImVec4(0, 0, 0, 1.f));
        PushStyleVar(ImGuiStyleVar_WindowPadding,  ImVec2(36.0f, 22.0f));
        PushStyleVar(ImGuiStyleVar_WindowRounding, 22.0f);

        if (Begin(O("##AutoQueueCD"), nullptr,
                  ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove |
                  ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoSavedSettings |
                  ImGuiWindowFlags_AlwaysAutoResize)) {
            ImDrawList* dl = GetWindowDrawList();
            ImVec2 wp = GetWindowPos();
            ImVec2 ws = GetWindowSize();
            dl->AddRectFilled(wp, ImVec2(wp.x + ws.x, wp.y + ws.y), CLR_BG_DEEP, 22.0f);

            // Violet glow ring
            dl->AddRect(wp, ImVec2(wp.x + ws.x, wp.y + ws.y), IM_COL32(139, 92, 246, 60), 24.0f, 0, 4.0f);
            dl->AddRect(wp, ImVec2(wp.x + ws.x, wp.y + ws.y), IM_COL32(167, 139, 250, 45), 26.0f, 0, 6.0f);

            SetWindowFontScale(3.5f);
            TextColored(ImVec4(0.65f, 0.55f, 0.97f, 1.0f), "%s", count_str.c_str());
            SetWindowFontScale(1.0f);
        }
        End();
        PopStyleVar(2);
        PopStyleColor();
    }
}

#include "mod/ButtonClicker.h"

static void DrawToggleButton(bool cancelMode); // forward declaration

INLINE void DrawESP(ImDrawList* draw) {
    if (!g_Token.empty() && !g_Auth.empty() && g_Token == g_Auth) {
        if (!sharedGameManager) return;

        UpdateScreenTable();

        sharedDirector = F(ptr, libmain + O(0x4f06288));
        if (!sharedDirector) return;

        sharedUserInfo = F(ptr, libmain + O(0x4e9feb8));
        if (!sharedUserInfo) return;

        F(bool, sharedUserInfo + 0x340) = true;

        sharedMainManager = F(ptr, libmain + O(0x4dde3e0));
        if (!sharedMainManager) return;

        sharedMenuManager = F(ptr, libmain + O(0x4dfe838));
        if (!sharedMenuManager) return;

        MainStateManager mainStateManager = sharedMainManager.mStateManager;
        if (!mainStateManager) return;
        if (!mainStateManager.isInGame()) {
            if (persistent_bool[O("bAutoQueue")]) {
                if (!sharedMenuManager.isInQueue()) DrawAutoQueue();
                DrawToggleButton(true);
            } return;
        }

        auto visualCue = sharedGameManager.mVisualCue();
        Ball::Classification myclass = sharedGameManager.getPlayerClassification();
        Table table = sharedGameManager.mTable;
        if (!table) return;

        auto tableProperties = table.mTableProperties();
        if (!tableProperties) return;

        auto& pockets = tableProperties.mPockets();
        GameStateManager gameStateManager = sharedGameManager.mStateManager;
        if (!gameStateManager) return;

        if (persistent_bool[O("bAutoPlay")]) {
            DrawToggleButton(false);
            
            // تحديث حالة الحساب لإظهار مؤشر "Thinking" للمستخدم (احترافي)
            extern bool g_autoPlayCalculating;
            g_autoPlayCalculating = (AutoPlay::state == AutoPlay::SCANNING);
            
            AutoPlay::Update();
        }

        auto stateId = gameStateManager.getCurrentStateId();
        if (stateId == 4) gPrediction->determineShotResult(false);
        if (stateId == 6 || stateId == 7 || stateId == 8) return;

        if (persistent_bool[O("bESP_DrawPocketsShotState")]) {
            // ── Determine ball state for pocket indicator color (instant update) ──
            // GREEN = correct ball selected / pocketed
            // RED   = wrong ball (cue ball or 8-ball before its proper turn)
            bool pocketColorCorrect = false;
            bool pocketColorWrong   = false;

            if (g_CurrentCandidate.idx != -1 && g_CurrentCandidate.idx < gPrediction->guiData.ballsCount) {
                auto& targetBall = gPrediction->guiData.balls[g_CurrentCandidate.idx];
                Ball::Classification mc = sharedGameManager.getPlayerClassification();

                if (targetBall.classification == Ball::Classification::CUE_BALL) {
                    pocketColorWrong = true;
                } else if (targetBall.classification == Ball::Classification::EIGHT_BALL) {
                    if (mc == Ball::Classification::EIGHT_BALL && AllGroupBallsPocketed()) {
                        pocketColorCorrect = true;
                    } else {
                        pocketColorWrong = true;
                    }
                } else if (mc == Ball::Classification::ANY ||
                           mc == Ball::Classification::NINE_BALL_RULE ||
                           targetBall.classification == mc) {
                    pocketColorCorrect = true;
                } else {
                    pocketColorWrong = true;
                }
            }

            static float g_pocketAnimTime = 0.0f;
            g_pocketAnimTime += GetIO().DeltaTime;

                        for (int i = 0; i < 6; i++) {
                if (Prediction::pocketStatus[i]) {
                    auto screenPos = WorldToScreen(pockets[i]);
                    float px = screenPos.x;
                    float py = screenPos.y;

                    ImU32 innerColor, outerColor, glowColor1, glowColor2, starColor;

                    if (Prediction::pocketStatus[i]) {
                        bool isEightBallPotted = false;
                        bool isCueBallPotted = !gPrediction->guiData.balls[0].onTable;
                        
                        for (int b = 1; b < gPrediction->guiData.ballsCount; b++) {
                            auto& ball = gPrediction->guiData.balls[b];
                            if (!ball.onTable && ball.pocketIndex == i) {
                                if (ball.classification == Ball::Classification::EIGHT_BALL) {
                                    isEightBallPotted = true;
                                }
                            }
                        }

                        if (isCueBallPotted && gPrediction->guiData.balls[0].pocketIndex == i) {
                            // الكرة البيضاء حمراء
                            innerColor = IM_COL32(255, 0, 0, 255);
                            outerColor = IM_COL32(200, 0, 0, 180);
                            glowColor1 = IM_COL32(255, 50, 50, 80);
                            glowColor2 = IM_COL32(200, 20, 20, 140);
                            starColor  = IM_COL32(255, 100, 100, 255);
                        } else if (isEightBallPotted) {
                            // كرة رقم 8 في غير هدفها خضراء (تعديل بطلب المستخدم)
                            innerColor = IM_COL32(0, 255, 0, 255);
                            outerColor = IM_COL32(0, 200, 0, 180);
                            glowColor1 = IM_COL32(50, 255, 50, 80);
                            glowColor2 = IM_COL32(20, 200, 20, 140);
                            starColor  = IM_COL32(100, 255, 100, 255);
                        } else {
                            // كره صحيحه اخضر
                            innerColor = IM_COL32(0, 255, 0, 255);
                            outerColor = IM_COL32(0, 200, 0, 180);
                            glowColor1 = IM_COL32(50, 255, 50, 80);
                            glowColor2 = IM_COL32(20, 200, 20, 140);
                            starColor  = IM_COL32(100, 255, 100, 255);
                        }
                    } else {
                        innerColor = IM_COL32(0, 255, 0, 255);
                        outerColor = IM_COL32(0, 200, 0, 180);
                        glowColor1 = IM_COL32(50, 255, 50, 80);
                        glowColor2 = IM_COL32(20, 200, 20, 140);
                        starColor  = IM_COL32(100, 255, 100, 255);
                    }

                    float pulse = 0.6f + 0.4f * sinf(g_pocketAnimTime * 5.0f + i * 1.2f);
                    float pulse2 = 0.5f + 0.5f * sinf(g_pocketAnimTime * 3.5f + i * 0.8f + 1.0f);

                    // ── Outer glow rings (pulsing) ──
                    draw->AddCircle(ImVec2(px, py), 62 + 10.0f * pulse, glowColor2, 0, 2.5f);
                    draw->AddCircle(ImVec2(px, py), 55 + 6.0f * pulse2, glowColor1, 0, 3.5f);

                    // ── Main pocket circle ──
                    draw->AddCircle(ImVec2(px, py), 44, outerColor, 0, 5.5f);
                    draw->AddCircle(ImVec2(px, py), 39, innerColor, 0, 3.5f);

                    // ── Inner bright core with white flash ──
                    draw->AddCircleFilled(ImVec2(px, py), 14, IM_COL32(255, 255, 255, (int)(90 * pulse)));
                    draw->AddCircleFilled(ImVec2(px, py), 7, IM_COL32(255, 255, 255, (int)(160 * pulse)));

                    // ── Enhanced star burst particles (12 stars radiating outward) ──
                    for (int s = 0; s < 12; s++) {
                        float starAngle = (float)s * (PI * 2.0f / 12.0f) + g_pocketAnimTime * 1.8f + i * 0.5f;
                        float starDist = 30.0f + 14.0f * sinf(g_pocketAnimTime * 4.5f + s * 0.9f + i);
                        float starSize = 3.0f + 2.0f * sinf(g_pocketAnimTime * 6.5f + s * 1.3f);
                        float starAlpha = 0.5f + 0.5f * sinf(g_pocketAnimTime * 5.5f + s * 0.7f + i * 1.1f);

                        float sx = px + cosf(starAngle) * starDist;
                        float sy = py + sinf(starAngle) * starDist;

                        // 4-pointed star shape
                        ImU32 sCol = IM_COL32(
                            (starColor >> 0) & 0xFF,
                            (starColor >> 8) & 0xFF,
                            (starColor >> 16) & 0xFF,
                            (int)(starAlpha * 255)
                        );

                        // Draw a small diamond/star shape
                        ImVec2 starPts[4];
                        float sr = starSize;
                        starPts[0] = ImVec2(sx, sy - sr * 1.8f);        // top
                        starPts[1] = ImVec2(sx + sr, sy);               // right
                        starPts[2] = ImVec2(sx, sy + sr * 1.8f);        // bottom
                        starPts[3] = ImVec2(sx - sr, sy);               // left
                        draw->AddConvexPolyFilled(starPts, 4, sCol);

                        // Tiny glow behind each star
                        draw->AddCircleFilled(ImVec2(sx, sy), starSize + 4.0f,
                            IM_COL32(
                                (starColor >> 0) & 0xFF,
                                (starColor >> 8) & 0xFF,
                                (starColor >> 16) & 0xFF,
                                (int)(starAlpha * 50)
                            ));

                        // Extra tiny white sparkle at star center
                        draw->AddCircleFilled(ImVec2(sx, sy), 1.2f,
                            IM_COL32(255, 255, 255, (int)(starAlpha * 220)));
                    }

                    // ── Extra tiny sparkle dots (16 dots orbiting) ──
                    for (int d = 0; d < 16; d++) {
                        float dotAngle = (float)d * (PI * 2.0f / 16.0f) - g_pocketAnimTime * 2.5f + i * 0.3f;
                        float dotDist = 50.0f + 6.0f * sinf(g_pocketAnimTime * 3.5f + d * 0.5f);
                        float dotAlpha = 0.3f + 0.7f * (0.5f + 0.5f * sinf(g_pocketAnimTime * 7.5f + d * 1.1f + i));
                        float dx2 = px + cosf(dotAngle) * dotDist;
                        float dy2 = py + sinf(dotAngle) * dotDist;
                        float dotSize = 1.2f + 1.2f * dotAlpha;

                        draw->AddCircleFilled(ImVec2(dx2, dy2), dotSize,
                            IM_COL32(255, 255, 255, (int)(dotAlpha * 220)));
                    }

                    // ── Extra ring of 6 tiny colored orbs ──
                    for (int o = 0; o < 6; o++) {
                        float orbAngle = (float)o * (PI * 2.0f / 6.0f) + g_pocketAnimTime * 1.2f + i * 0.8f;
                        float orbDist = 35.0f + 8.0f * sinf(g_pocketAnimTime * 2.0f + o * 1.5f + i);
                        float orbAlpha = 0.4f + 0.6f * (0.5f + 0.5f * sinf(g_pocketAnimTime * 4.0f + o * 2.0f + i * 0.6f));
                        float ox = px + cosf(orbAngle) * orbDist;
                        float oy = py + sinf(orbAngle) * orbDist;

                        // Orb glow
                        draw->AddCircleFilled(ImVec2(ox, oy), 5.0f,
                            IM_COL32(
                                (innerColor >> 0) & 0xFF,
                                (innerColor >> 8) & 0xFF,
                                (innerColor >> 16) & 0xFF,
                                (int)(orbAlpha * 60)
                            ));
                        // Orb core
                        draw->AddCircleFilled(ImVec2(ox, oy), 2.0f,
                            IM_COL32(
                                (innerColor >> 0) & 0xFF,
                                (innerColor >> 8) & 0xFF,
                                (innerColor >> 16) & 0xFF,
                            (int)(orbAlpha * 200)
                            ));
                    }
                }
            }
        }

        if (persistent_bool[O("bESP_DrawPredictionLine")]) {
            for (int i = 0; i < gPrediction->guiData.ballsCount; i++) {
                auto& ball = gPrediction->guiData.balls[i];

                if (ball.initialPosition != ball.predictedPosition) {
                    float lineThick = (float)persistent_int[O("iLineThickness")];
                    if (lineThick < 1.f) lineThick = 1.f;

                    // ── Striped balls (index 9–15) → dashed aim line ──
                    bool isStripe = (ball.classification == Ball::Classification::STRIPE);

                    ImU32 lineColor = colors[i];
                    if (i == 0 && !ball.onTable) lineColor = IM_COL32(255, 255, 255, 255); // White for Cue Ball
                    if (ball.classification == Ball::Classification::EIGHT_BALL && !ball.onTable) lineColor = IM_COL32(0, 0, 0, 255); // Black for 8 Ball

                    if (isStripe) {
                        constexpr float DASH_LEN = 12.0f;
                        constexpr float GAP_LEN  =  7.0f;
                        ImVec2 lastPos{};
                        float accumulated = 0.0f;
                        bool inDash = true;
                        ImVec2 dashStart{};
                        bool hasDashStart = false;

                        for (int j = 1; j < (int)ball.positions.size(); j++) {
                            ImVec2 cur = WorldToScreen(ball.positions[j]);
                            if (!lastPos.x && !lastPos.y) { lastPos = cur; continue; }
                            float dx = cur.x - lastPos.x;
                            float dy = cur.y - lastPos.y;
                            float segLen = sqrtf(dx * dx + dy * dy);
                            if (segLen < 0.001f) { lastPos = cur; continue; }
                            float nx = dx / segLen;
                            float ny = dy / segLen;
                            float walked = 0.0f;
                            while (walked < segLen) {
                                float remaining = inDash ? (DASH_LEN - accumulated) : (GAP_LEN - accumulated);
                                float step = fminf(remaining, segLen - walked);
                                ImVec2 stepEnd = ImVec2(lastPos.x + nx * (walked + step), lastPos.y + ny * (walked + step));
                                if (inDash) {
                                    if (!hasDashStart) { dashStart = ImVec2(lastPos.x + nx * walked, lastPos.y + ny * walked); hasDashStart = true; }
                                    if (accumulated + step >= DASH_LEN) {
                                        draw->AddLine(dashStart, stepEnd, lineColor, lineThick);
                                        hasDashStart = false;
                                    }
                                }
                                accumulated += step;
                                walked += step;
                                if (accumulated >= (inDash ? DASH_LEN : GAP_LEN)) {
                                    if (inDash && hasDashStart) {
                                        draw->AddLine(dashStart, stepEnd, lineColor, lineThick);
                                        hasDashStart = false;
                                    }
                                    accumulated = 0.0f;
                                    inDash = !inDash;
                                    if (inDash) dashStart = stepEnd;
                                }
                            }
                            lastPos = cur;
                        }
                        if (inDash && hasDashStart) {
                            draw->AddLine(dashStart, lastPos, lineColor, lineThick);
                        }
                    } else {
                        ImVec2 lastPos{};
                        for (int j = 1; j < (int)ball.positions.size(); j++) {
                            auto point = WorldToScreen(ball.positions[j]);
                            if (lastPos.x || lastPos.y) draw->AddLine(lastPos, point, lineColor, lineThick);
                            lastPos = point;
                        }
                    }
                }
            }
        }

        if (persistent_bool[O("bESP_DrawPredictionLine")]) {
            for (int i = 0; i < gPrediction->guiData.ballsCount; i++) {
                auto& ball = gPrediction->guiData.balls[i];

                if (ball.initialPosition != ball.predictedPosition) {
                    float circleR = (float)persistent_int[O("iLineThickness")] + 1.f;
                    if (circleR < 2.f) circleR = 2.f;
                    
                    ImU32 ballColor = colors[i];
                    if (i == 0 && !ball.onTable) ballColor = IM_COL32(255, 255, 255, 255); // White for Cue Ball
                    if (ball.classification == Ball::Classification::EIGHT_BALL && !ball.onTable) ballColor = IM_COL32(0, 0, 0, 255); // Black for 8 Ball

                    draw->AddCircleFilled(WorldToScreen(ball.initialPosition), circleR, ballColor);
                    draw->AddCircleFilled(WorldToScreen(ball.predictedPosition), 23, ballColor);
                }
            }
        }

        // ── Enemy Lines: luxurious electric purple/cyan gradient with diamond particles ──
        if (persistent_bool[O("bESP_DrawEnemyLines")]) {
            static float g_enemyAnimTime = 0.0f;
            g_enemyAnimTime += GetIO().DeltaTime;

            ImU32 enemyLineColor  = IM_COL32(180, 100, 255, 240);   // Rich purple
            ImU32 enemyDashColor  = IM_COL32(0,   220, 255, 220);   // Electric cyan
            ImU32 enemyGlowColor  = IM_COL32(140,  60, 255,  55);   // Soft purple glow
            ImU32 enemyGlowColor2 = IM_COL32(  0, 180, 255,  40);   // Cyan glow
            ImU32 enemyCoreColor  = IM_COL32(220, 180, 255, 255);   // Lavender core
            ImU32 enemySparkColor = IM_COL32(255, 255, 255, 200);   // White sparkles
            float enemyThick = (float)persistent_int[O("iLineThickness")] * 0.8f;
            if (enemyThick < 1.f) enemyThick = 1.f;
            float glowThick = enemyThick + 5.0f;

            for (int i = 0; i < gPrediction->guiData.ballsCount; i++) {
                auto& ball = gPrediction->guiData.balls[i];

                if (ball.classification != Ball::Classification::CUE_BALL &&
                    ball.classification != myclass &&
                    ball.initialPosition != ball.predictedPosition) {

                    bool isStripe = (ball.classification == Ball::Classification::STRIPE);
                    ImU32 lineCol = isStripe ? enemyDashColor : enemyLineColor;
                    ImU32 glowCol = isStripe ? enemyGlowColor2 : enemyGlowColor;

                    if (isStripe) {
                        constexpr float DASH_LEN = 10.0f;
                        constexpr float GAP_LEN  =  6.0f;
                        ImVec2 lastPos{};
                        float accumulated = 0.0f;
                        bool inDash = true;
                        ImVec2 dashStart{};
                        bool hasDashStart = false;

                        for (int j = 1; j < (int)ball.positions.size(); j++) {
                            ImVec2 cur = WorldToScreen(ball.positions[j]);
                            if (!lastPos.x && !lastPos.y) { lastPos = cur; continue; }
                            float dx = cur.x - lastPos.x;
                            float dy = cur.y - lastPos.y;
                            float segLen = sqrtf(dx * dx + dy * dy);
                            if (segLen < 0.001f) { lastPos = cur; continue; }
                            float nx = dx / segLen;
                            float ny = dy / segLen;
                            float walked = 0.0f;
                            while (walked < segLen) {
                                float remaining = inDash ? (DASH_LEN - accumulated) : (GAP_LEN - accumulated);
                                float step = fminf(remaining, segLen - walked);
                                ImVec2 stepEnd = ImVec2(lastPos.x + nx * (walked + step), lastPos.y + ny * (walked + step));
                                if (inDash) {
                                    if (!hasDashStart) { dashStart = ImVec2(lastPos.x + nx * walked, lastPos.y + ny * walked); hasDashStart = true; }
                                    if (accumulated + step >= DASH_LEN) {
                                        draw->AddLine(dashStart, stepEnd, glowCol, glowThick);
                                        draw->AddLine(dashStart, stepEnd, lineCol, enemyThick);
                                        hasDashStart = false;
                                    }
                                }
                                accumulated += step;
                                walked += step;
                                if (accumulated >= (inDash ? DASH_LEN : GAP_LEN)) {
                                    if (inDash && hasDashStart) {
                                        draw->AddLine(dashStart, stepEnd, glowCol, glowThick);
                                        draw->AddLine(dashStart, stepEnd, lineCol, enemyThick);
                                        hasDashStart = false;
                                    }
                                    accumulated = 0.0f;
                                    inDash = !inDash;
                                    if (inDash) dashStart = stepEnd;
                                }
                            }
                            lastPos = cur;
                        }
                        if (inDash && hasDashStart) {
                            draw->AddLine(dashStart, lastPos, glowCol, glowThick);
                            draw->AddLine(dashStart, lastPos, lineCol, enemyThick);
                        }
                    } else {
                        ImVec2 lastPos{};
                        for (int j = 1; j < (int)ball.positions.size(); j++) {
                            auto point = WorldToScreen(ball.positions[j]);
                            if (lastPos.x || lastPos.y) {
                                draw->AddLine(lastPos, point, glowCol, glowThick);
                                draw->AddLine(lastPos, point, lineCol, enemyThick);
                            }
                            lastPos = point;
                        }
                    }

                    // ── Enemy ball position markers: luxurious diamond/purple style ──
                    float circleR = enemyThick + 1.f;
                    if (circleR < 2.f) circleR = 2.f;
                    ImVec2 initPos = WorldToScreen(ball.initialPosition);
                    ImVec2 predPos = WorldToScreen(ball.predictedPosition);

                    // Outer purple glow rings
                    float pulse = 0.6f + 0.4f * sinf(g_enemyAnimTime * 4.0f + i);
                    draw->AddCircleFilled(initPos, circleR + 7.0f, IM_COL32(140,  60, 255, (int)(25 * pulse)));
                    draw->AddCircleFilled(initPos, circleR + 4.0f, IM_COL32(180, 100, 255, (int)(45 * pulse)));
                    draw->AddCircleFilled(initPos, circleR, enemyLineColor);
                    // Inner bright lavender core
                    draw->AddCircleFilled(initPos, circleR * 0.45f, enemyCoreColor);

                    // Predicted position — rotating diamond marker with cyan/purple pulse
                    float pulse2 = 0.5f + 0.5f * sinf(g_enemyAnimTime * 5.0f + i * 0.7f);
                    draw->AddCircleFilled(predPos, 20 + 5.0f * pulse2, IM_COL32(0, 180, 255, (int)(35 * pulse2)));
                    draw->AddCircleFilled(predPos, 18, enemyDashColor);
                    // Rotating diamond inside
                    float rotAngle = g_enemyAnimTime * 2.5f + i * 1.2f;
                    float dSize = 9.0f + 2.0f * pulse2;
                    ImVec2 dPts[4];
                    for (int d = 0; d < 4; d++) {
                        float a = rotAngle + d * (PI * 0.5f);
                        dPts[d] = ImVec2(predPos.x + cosf(a) * dSize, predPos.y + sinf(a) * dSize);
                    }
                    draw->AddConvexPolyFilled(dPts, 4, IM_COL32(220, 180, 255, (int)(180 * pulse2)));
                    draw->AddConvexPolyFilled(dPts, 4, IM_COL32(255, 255, 255, (int)(60 * pulse2)));
                    // White center spark
                    draw->AddCircleFilled(predPos, 3.0f, enemySparkColor);
                }
            }
        }
    }
}

// Reads an IL2CPP/Unity NSString (UTF-16 internal buffer at offset 0x14, length at 0x10)
static std::string ReadNSString(ptr str) {
    if (!str) return "null";
    int32_t len = F(int32_t, str + 0x10);
    if (len <= 0 || len > 512) return "?";
    std::string result;
    result.reserve(len);
    for (int32_t i = 0; i < len; i++) {
        uint16_t ch = F(uint16_t, str + 0x14 + i * 2);
        result += (ch > 0 && ch < 128) ? (char)ch : '?';
    }
    return result;
}

static float g_sideBtnsY      = 0.0f;
static float g_sideBtnsX      = 0.0f;
static float g_toggleRotAngle = 0.0f;
static bool  g_autoPlayCalculating = false;

// ── svConfig ──────────────────────────────────────────────────────────────────
static void svConfig_Save() {
    std::string path = O("/data/user/0/") + PACKAGE_NAME + O("/files/svConfig.txt");
    FILE* f = fopen(path.c_str(), O("w"));
    if (!f) return;
    fprintf(f, O("iLineThickness=%d\n"),  persistent_int[O("iLineThickness")]);
    fprintf(f, O("iMenuSizeOffset=%d\n"), persistent_int[O("iMenuSizeOffset")]);
    fprintf(f, O("g_sideBtnsX=%.1f\n"), g_sideBtnsX);
    fprintf(f, O("g_sideBtnsY=%.1f\n"), g_sideBtnsY);
    fclose(f);
}
static void svConfig_Load() {
    std::string path = O("/data/user/0/") + PACKAGE_NAME + O("/files/svConfig.txt");
    FILE* f = fopen(path.c_str(), O("r"));
    if (!f) return;
    char line[64];
    while (fgets(line, sizeof(line), f)) {
        int v = 0;
        if (sscanf(line, O("iLineThickness=%d"),  &v) == 1) { persistent_int[O("iLineThickness")]  = v; continue; }
        if (sscanf(line, O("iMenuSizeOffset=%d"), &v) == 1) { persistent_int[O("iMenuSizeOffset")] = v; }
        { float fv = 0; if (sscanf(line, O("g_sideBtnsX=%f"), &fv) == 1) { g_sideBtnsX = fv; continue; } }
        { float fv = 0; if (sscanf(line, O("g_sideBtnsY=%f"), &fv) == 1) { g_sideBtnsY = fv; continue; } }
    }
    fclose(f);
}

// ── CALCULATING overlay ───────────────────────────────────────────────────────
static void DrawCalculating(ImGuiIO& io) {
    SetNextWindowPos(ImVec2(Width * 0.5f, Height * 0.5f),
                     ImGuiCond_Always, ImVec2(0.5f, 0.5f));

    PushStyleColor(ImGuiCol_WindowBg, IM_COL32(20, 22, 30, 245));
    PushStyleColor(ImGuiCol_Border,   IM_COL32(0, 200, 255, 170));

    PushStyleVar(ImGuiStyleVar_WindowRounding, 16.0f);
    PushStyleVar(ImGuiStyleVar_WindowBorderSize, 1.5f);

    if (Begin(O("##CalcOverlay"), nullptr,
        ImGuiWindowFlags_NoTitleBar |
        ImGuiWindowFlags_NoResize |
        ImGuiWindowFlags_NoMove |
        ImGuiWindowFlags_NoScrollbar |
        ImGuiWindowFlags_AlwaysAutoResize |
        ImGuiWindowFlags_NoInputs))
    {
        ImDrawList* dl = GetWindowDrawList();

        ImVec2 p = GetWindowPos();
        ImVec2 s = GetWindowSize();

        dl->AddRectFilled(
            p,
            ImVec2(p.x + s.x, p.y + s.y),
            IM_COL32(18, 20, 28, 245),
            16.0f);

        dl->AddRect(
            p,
            ImVec2(p.x + s.x, p.y + s.y),
            IM_COL32(0, 200, 255, 150),
            16.0f,
            0,
            2.0f);

        static float t = 0.0f;
        t += io.DeltaTime * 3.0f;

        int dots = ((int)t % 4);

        char txt[64];
        sprintf(txt, "CALCULATING%.*s", dots, "...");

        SetWindowFontScale(1.15f);
        TextColored(ImVec4(0.92f, 0.96f, 1.0f, 1.0f), txt);
        SetWindowFontScale(1.0f);
    }

    End();

    PopStyleVar(2);
    PopStyleColor(2);
}

// ─── Hexagonal (6-sided) button shape helper ────────────────────────────
static void DrawHexagon(ImDrawList* dl, ImVec2 center, float radius, ImU32 color, float thickness = 1.0f, float angle_offset = 0.0f) {
    ImVec2 pts[6];
    for (int i = 0; i < 6; i++) {
        float angle = angle_offset + (float)PI * 2.0f * (float)i / 6.0f - (float)PI / 6.0f;
        pts[i] = ImVec2(center.x + cosf(angle) * radius, center.y + sinf(angle) * radius);
    }
    for (int i = 0; i < 6; i++) {
        dl->AddLine(pts[i], pts[(i + 1) % 6], color, thickness);
    }
}

static void DrawHexagonFilled(ImDrawList* dl, ImVec2 center, float radius, ImU32 color, float angle_offset = 0.0f) {
    ImVec2 pts[6];
    for (int i = 0; i < 6; i++) {
        float angle = angle_offset + (float)PI * 2.0f * (float)i / 6.0f - (float)PI / 6.0f;
        pts[i] = ImVec2(center.x + cosf(angle) * radius, center.y + sinf(angle) * radius);
    }
    dl->AddConvexPolyFilled(pts, 6, color);
}

// ─── Helper: draw an info card with accent stripe ────────────────────────────

// ─── Animated traveling glow border for VIP digit boxes ───────────────────────
static void DrawTravelingGlowBorder(ImDrawList* dl, ImVec2 pMin, ImVec2 pMax,
                                     float cr, float cg, float cb, float time,
                                     float speed, float rounding) {
    float w = pMax.x - pMin.x;
    float h = pMax.y - pMin.y;
    float perim = 2.0f * (w + h);
    if (perim < 1.0f) return;
    
    // Luxury Red Override
    cr = 1.0f; cg = 0.1f; cb = 0.1f;

    // Base dim border
    dl->AddRect(pMin, pMax, IM_COL32(150, 20, 20, 100), rounding, 0, 1.0f);

    // Traveling glow head position along perimeter
    float headPos = fmodf(time * speed, perim);
    float trailLen = perim * 0.28f;
    int numSegs = 22;

    for (int i = 0; i < numSegs; i++) {
        float frac = (float)i / numSegs;
        float nextFrac = (float)(i + 1) / numSegs;

        float d0 = fmodf(headPos - trailLen * frac + perim * 4.0f, perim);
        float d1 = fmodf(headPos - trailLen * nextFrac + perim * 4.0f, perim);

        float alpha = (1.0f - frac);
        alpha = alpha * alpha;

        float dd0 = fmodf(d0, perim);
        float ax, ay, bx, by;

        if (dd0 < w) { ax = pMin.x + dd0; ay = pMin.y; }
        else if (dd0 < w + h) { ax = pMax.x; ay = pMin.y + (dd0 - w); }
        else if (dd0 < 2.0f * w + h) { ax = pMax.x - (dd0 - w - h); ay = pMax.y; }
        else { ax = pMin.x; ay = pMax.y - (dd0 - 2.0f * w - h); }

        float dd1 = fmodf(d1, perim);
        if (dd1 < w) { bx = pMin.x + dd1; by = pMin.y; }
        else if (dd1 < w + h) { bx = pMax.x; by = pMin.y + (dd1 - w); }
        else if (dd1 < 2.0f * w + h) { bx = pMax.x - (dd1 - w - h); by = pMax.y; }
        else { bx = pMin.x; by = pMax.y - (dd1 - 2.0f * w - h); }

        dl->AddLine(ImVec2(ax, ay), ImVec2(bx, by), IM_COL32(0, 191, 255, (int)(alpha * 50)), 6.0f);
        dl->AddLine(ImVec2(ax, ay), ImVec2(bx, by), IM_COL32(0, 255, 255, (int)(alpha * 200)), 2.0f);
    }

    // Bright head glow dot
    float hdd = fmodf(headPos, perim);
    float hx, hy;
    if (hdd < w) { hx = pMin.x + hdd; hy = pMin.y; }
    else if (hdd < w + h) { hx = pMax.x; hy = pMin.y + (hdd - w); }
    else if (hdd < 2.0f * w + h) { hx = pMax.x - (hdd - w - h); hy = pMax.y; }
    else { hx = pMin.x; hy = pMax.y - (hdd - 2.0f * w - h); }

    dl->AddCircleFilled(ImVec2(hx, hy), 3.0f, IM_COL32(255, 255, 255, 230));
    dl->AddCircleFilled(ImVec2(hx, hy), 6.0f, IM_COL32(0, 191, 255, 80));
    dl->AddCircleFilled(ImVec2(hx, hy), 9.0f, IM_COL32(0, 191, 255, 30));
    
    if (fmodf(time, 2.0f) < 0.1f) {
        DrawLightning(dl, ImVec2(hx, hy), ImVec2(hx + 15, hy + 15), IM_COL32(255, 255, 255, 200), 1.0f);
    }
}

static void DrawCardBegin(ImDrawList* dl, ImVec2 cardPos, float cardW, float cardH, float rounding = 10.0f) {
    dl->AddRectFilled(cardPos, ImVec2(cardPos.x + cardW, cardPos.y + cardH), CLR_BG_CARD, rounding);
    dl->AddRect(cardPos, ImVec2(cardPos.x + cardW, cardPos.y + cardH), IM_COL32(0, 191, 255, 180), rounding, 0, 1.0f);
    float stripeH = 3.0f;
    dl->AddRectFilledMultiColor(
        cardPos, ImVec2(cardPos.x + cardW, cardPos.y + stripeH),
        IM_COL32(0, 191, 255, 230), IM_COL32(0, 255, 255, 230),
        IM_COL32(0, 255, 255, 230), IM_COL32(0, 191, 255, 230)
    );
}

// ─── Content area — two-column unified layout ────────────────────────────────
static void DrawContentArea(float winW, float winH) {
    bool need_save = false;
    static float g_elecTime = 0.0f;
    g_elecTime += GetIO().DeltaTime;

    ImDrawList* dl  = GetWindowDrawList();
    ImVec2      wp  = GetWindowPos();
    float startY = GetCursorPosY();
    float padX    = 12.0f;

    // ── COMPACT MODERN LAYOUT ──
    float titleBarH = 40.0f; // تقليل ارتفاع شريط العنوان
    float headerH = titleBarH + 5.0f;
    float colGap = 10.0f;
    float topSectionH = winH - startY - headerH - 15.0f; // ضبط المساحة المتاحة
    float availW = winW - padX * 2 - colGap;
    float leftColW  = availW * 0.48f; // توازن أفضل بين العمودين
    float rightColW = availW - leftColW;

    // Background with Electricity in Corners
    dl->AddRectFilled(wp, ImVec2(wp.x + winW, wp.y + winH), CLR_BG_PANEL, 15.0f);
    
    // Electricity Effects in Corners
    float elecLen = 60.0f;
    ImU32 elecCol = IM_COL32(0, 191, 255, (int)(150 + 100 * sinf(g_elecTime * 10.0f)));
    DrawLightning(dl, wp, ImVec2(wp.x + elecLen, wp.y), elecCol, 2.0f);
    DrawLightning(dl, wp, ImVec2(wp.x, wp.y + elecLen), elecCol, 2.0f);
    DrawLightning(dl, ImVec2(wp.x + winW, wp.y), ImVec2(wp.x + winW - elecLen, wp.y), elecCol, 2.0f);
    DrawLightning(dl, ImVec2(wp.x + winW, wp.y), ImVec2(wp.x + winW, wp.y + elecLen), elecCol, 2.0f);
    DrawLightning(dl, ImVec2(wp.x, wp.y + winH), ImVec2(wp.x + elecLen, wp.y + winH), elecCol, 2.0f);
    DrawLightning(dl, ImVec2(wp.x, wp.y + winH), ImVec2(wp.x, wp.y + winH - elecLen), elecCol, 2.0f);
    DrawLightning(dl, ImVec2(wp.x + winW, wp.y + winH), ImVec2(wp.x + winW - elecLen, wp.y + winH), elecCol, 2.0f);
    DrawLightning(dl, ImVec2(wp.x + winW, wp.y + winH), ImVec2(wp.x + winW, wp.y + winH - elecLen), elecCol, 2.0f);

    // Title bar
    dl->AddRectFilled(ImVec2(wp.x, wp.y + startY), ImVec2(wp.x + winW, wp.y + startY + titleBarH), CLR_BG_CARD, 15.0f);
    SetWindowFontScale(1.1f);
    ImVec2 ts = CalcTextSize(O("FAN GAMAL V11 56.26.2 | @FAN_GAMAL  !"));
    SetCursorPos(ImVec2(padX + 10.0f, startY + (titleBarH - ts.y) * 0.5f));
    TextColored(ImVec4(0.0f, 0.75f, 1.0f, 1.0f), "%s", O("FAN GAMAL V11 56.26.2 | @FAN_GAMAL  !"));
    SetWindowFontScale(1.0f);

    // Close button
    {
        ImGuiWindow* win = GetCurrentWindow();
        ImGuiID closeId  = win->GetID(O("##CloseMenu"));
        float closeSide  = 32.0f;
        float closeX     = wp.x + winW - closeSide - 15.0f;
        float closeY     = wp.y + startY + (titleBarH - closeSide) * 0.5f;
        ImRect closeBb(ImVec2(closeX, closeY), ImVec2(closeX + closeSide, closeY + closeSide));
        SetCursorPos(ImVec2(closeX - wp.x, closeY - wp.y));
        ItemSize(ImVec2(closeSide, closeSide));
        ItemAdd(closeBb, closeId);
        bool closeHovered, closeHeld;
        if (ButtonBehavior(closeBb, closeId, &closeHovered, &closeHeld)) g_menu.isOpen = false;
        DrawHexagonFilled(dl, ImVec2(closeX + closeSide*0.5f, closeY + closeSide*0.5f), closeSide*0.5f, closeHovered ? CLR_CLOSE_HOV : CLR_CLOSE_BASE, g_elecTime*0.5f);
    }

    SetCursorPos(ImVec2(padX, startY + headerH));
    PushStyleColor(ImGuiCol_ChildBg, ImVec4(0, 0, 0, 0));

    // ── LEFT SECTION: VIP CONTROLS ──
    {
        ImVec2 childPos = GetCursorScreenPos();
        // توهج فخم جداً باللون الذهبي والبنفسجي
        DrawTravelingGlowBorder(dl, childPos, ImVec2(childPos.x + leftColW, childPos.y + topSectionH), 0.85f, 0.75f, 0.25f, g_elecTime, 150.0f, 20.0f);
        dl->AddRectFilled(childPos, ImVec2(childPos.x + leftColW, childPos.y + topSectionH), IM_COL32(10, 10, 25, 240), 20.0f);

        BeginChild(O("##LeftCol"), ImVec2(leftColW, topSectionH), false, ImGuiWindowFlags_NoScrollbar);
        SetCursorPos(ImVec2(20, 20));
        SetWindowFontScale(1.2f);
        TextColored(ImVec4(0.85f, 0.75f, 0.25f, 1.0f), O("PREMIUM CONTROLS"));
        SetWindowFontScale(1.0f);
        Dummy(ImVec2(0, 10));
        
        need_save |= ToggleSwitch(O("Lines"), &persistent_bool[O("bESP_DrawPredictionLine")]);
        need_save |= ToggleSwitch(O("Pockets"), &persistent_bool[O("bESP_DrawPocketsShotState")]);
        need_save |= ToggleSwitch(O("AutoPlay"), &persistent_bool[O("bAutoPlay")]);
        need_save |= ToggleSwitch(O("AutoQueue"), &persistent_bool[O("bAutoQueue")]);
        
        // ── Separator between AutoQueue and Thickness ──
        Dummy(ImVec2(0, 8));
        {
            ImDrawList* ldl = GetWindowDrawList();
            ImVec2 sp = GetCursorScreenPos();
            float sepX0 = sp.x + 10.0f;
            float sepX1 = sp.x + GetContentRegionAvail().x - 10.0f;
            float sepY = sp.y + 4.0f;
            if (sepX1 > sepX0) {
                float t = g_elecTime;
                float flowPos = 0.5f + 0.5f * sinf(t * 3.0f);
                float flowX = sepX0 + (sepX1 - sepX0) * flowPos;
                float flowW = 50.0f + 15.0f * sinf(t * 2.3f);
                ldl->AddLine(ImVec2(sepX0, sepY), ImVec2(sepX1, sepY), IM_COL32(139, 92, 246, 30), 5.0f);
                ldl->AddLine(ImVec2(sepX0, sepY), ImVec2(sepX1, sepY), IM_COL32(139, 92, 246, 55), 1.0f);
                ldl->AddLine(ImVec2(fmaxf(sepX0, flowX - flowW * 0.5f), sepY), ImVec2(fminf(sepX1, flowX + flowW * 0.5f), sepY), IM_COL32(167, 139, 250, 120), 2.0f);
                ldl->AddLine(ImVec2(fmaxf(sepX0, flowX - 8.0f), sepY), ImVec2(fminf(sepX1, flowX + 8.0f), sepY), IM_COL32(230, 225, 255, 200), 2.5f);
                ldl->AddCircleFilled(ImVec2(sepX0, sepY), 2.0f, IM_COL32(139, 92, 246, 80));
                ldl->AddCircleFilled(ImVec2(sepX1, sepY), 2.0f, IM_COL32(167, 139, 250, 80));
            }
        }
        Dummy(ImVec2(0, 6));

        // ── Line Thickness Control ──
        SetCursorPosX(15);
        SetWindowFontScale(0.75f);
        TextColored(ImVec4(0.0f, 0.75f, 1.0f, 1.0f), O("LINE THICKNESS"));
        SetWindowFontScale(1.0f);
        Dummy(ImVec2(0, 10));

        {
            ImDrawList* ldl = GetWindowDrawList();
            ImVec2 sliderPos = GetCursorScreenPos();
            float sliderW = GetContentRegionAvail().x - 20.0f;
            float sliderH = 30.0f; // تقليل ارتفاع السلايدر
            SetCursorPosX(10);
            
            ldl->AddRectFilled(sliderPos, ImVec2(sliderPos.x + sliderW, sliderPos.y + sliderH), IM_COL32(10, 10, 30, 255), 15.0f);
            ldl->AddRect(sliderPos, ImVec2(sliderPos.x + sliderW, sliderPos.y + sliderH), IM_COL32(0, 191, 255, 100), 15.0f, 0, 1.0f);
            
            int& currentThick = persistent_int[O("iLineThickness")];
            // تحسين التحكم ليعمل من 1 إلى 10 بدقة متناهية
            float t = (float)(currentThick - 1) / (10 - 1);
            if (t < 0) t = 0; if (t > 1) t = 1;
            
            float knobX = sliderPos.x + 20.0f + t * (sliderW - 40.0f);
            float knobY = sliderPos.y + sliderH * 0.5f;
            
            // خلفية فخمة للشريط مع توهج ذهبي
            ldl->AddRectFilled(sliderPos, ImVec2(sliderPos.x + sliderW, sliderPos.y + sliderH), IM_COL32(20, 10, 35, 255), 20.0f);
            ldl->AddRectFilledMultiColor(sliderPos, ImVec2(knobX, sliderPos.y + sliderH), 
                IM_COL32(139, 92, 246, 180), IM_COL32(167, 139, 250, 220), 
                IM_COL32(167, 139, 250, 220), IM_COL32(139, 92, 246, 180));
            
            ImGuiID sliderId = GetCurrentWindow()->GetID(O("##ThickSlider"));
            ImRect sliderBb(sliderPos, ImVec2(sliderPos.x + sliderW, sliderPos.y + sliderH));
            ItemSize(ImVec2(sliderW, sliderH));
            ItemAdd(sliderBb, sliderId);
            
            bool hov, held;
            if (ButtonBehavior(sliderBb, sliderId, &hov, &held) || (hov && ImGui::IsMouseDown(0))) {
                float mouseX = ImGui::GetIO().MousePos.x;
                float newT = (mouseX - (sliderPos.x + 20.0f)) / (sliderW - 40.0f);
                if (newT < 0) newT = 0; if (newT > 1) newT = 1;
                // حساب الحجم الجديد من 1 إلى 10 بدقة
                int newVal = (int)(1 + newT * 9 + 0.5f);
                if (newVal != currentThick) {
                    currentThick = newVal;
                    need_save = true;
                }
            }
            
            DrawLightning(ldl, ImVec2(knobX, sliderPos.y), ImVec2(knobX, sliderPos.y + sliderH), IM_COL32(255, 255, 255, 255), 2.0f);
            ldl->AddCircleFilled(ImVec2(knobX, knobY), 12.0f, IM_COL32(255, 255, 255, 255));
            ldl->AddCircle(ImVec2(knobX, knobY), 14.0f, IM_COL32(0, 191, 255, 200), 0, 2.0f);
            
            char valStr[16]; snprintf(valStr, sizeof(valStr), "SIZE: %d", currentThick);
            ImVec2 valSz = CalcTextSize(valStr);
            ldl->AddText(ImVec2(sliderPos.x + (sliderW - valSz.x) * 0.5f, knobY - valSz.y * 0.5f), IM_COL32(255, 255, 255, 200), valStr);
            
            Dummy(ImVec2(0, 20));
        }

        EndChild();
    }

    SameLine(0, colGap);

        // ── RIGHT SECTION: SYSTEM STATUS ──
    {
        ImVec2 childPos = GetCursorScreenPos();
        DrawTravelingGlowBorder(dl, childPos, ImVec2(childPos.x + rightColW, childPos.y + topSectionH), 0.25f, 0.85f, 0.95f, g_elecTime, 150.0f, 20.0f);
        dl->AddRectFilled(childPos, ImVec2(childPos.x + rightColW, childPos.y + topSectionH), IM_COL32(10, 10, 25, 240), 20.0f);

        BeginChild(O("##RightCol"), ImVec2(rightColW, topSectionH), false, ImGuiWindowFlags_NoScrollbar);
        ImDrawList* rdl = GetWindowDrawList();
        SetCursorPos(ImVec2(20, 20));
        SetWindowFontScale(1.2f);
        TextColored(ImVec4(0.25f, 0.85f, 0.95f, 1.0f), O("SYSTEM STATUS"));
        SetWindowFontScale(1.0f);
        Dummy(ImVec2(0, 12));

        // Animated separator under title
        {
            ImVec2 sp = GetCursorScreenPos();
            float sepX0 = sp.x + 10.0f;
            float sepX1 = sp.x + GetContentRegionAvail().x - 10.0f;
            float sepY = sp.y + 4.0f;
            if (sepX1 > sepX0) {
                float t = g_elecTime;
                float flowPos = 0.5f + 0.5f * sinf(t * 2.5f);
                float flowX = sepX0 + (sepX1 - sepX0) * flowPos;
                float flowW = 40.0f + 10.0f * sinf(t * 2.0f);
                rdl->AddLine(ImVec2(sepX0, sepY), ImVec2(sepX1, sepY), IM_COL32(22, 210, 237, 25), 4.0f);
                rdl->AddLine(ImVec2(sepX0, sepY), ImVec2(sepX1, sepY), IM_COL32(22, 210, 237, 45), 1.0f);
                rdl->AddLine(ImVec2(fmaxf(sepX0, flowX - flowW * 0.5f), sepY), ImVec2(fminf(sepX1, flowX + flowW * 0.5f), sepY), IM_COL32(33, 211, 238, 100), 1.5f);
                rdl->AddCircleFilled(ImVec2(sepX0, sepY), 2.0f, IM_COL32(22, 210, 237, 60));
                rdl->AddCircleFilled(ImVec2(sepX1, sepY), 2.0f, IM_COL32(33, 211, 238, 60));
            }
        }
        Dummy(ImVec2(0, 8));

        // Device info with row backgrounds
        static char s_manufacturer[PROP_VALUE_MAX] = {};
        static char s_model_name[PROP_VALUE_MAX] = {};
        static char s_abi[PROP_VALUE_MAX] = {};
        static char s_android_ver[PROP_VALUE_MAX] = {};
        static bool s_dev_props_loaded = false;
        if (!s_dev_props_loaded) {
            __system_property_get("ro.product.manufacturer", s_manufacturer);
            __system_property_get("ro.product.model", s_model_name);
            __system_property_get("ro.product.cpu.abi", s_abi);
            __system_property_get("ro.build.version.release", s_android_ver);
            s_dev_props_loaded = true;
        }

        auto DrawDeviceInfoRow = [&](const char* key, const char* val, ImU32 valColor) {
            SetCursorPosX(8);
            ImVec2 rowPos = GetCursorScreenPos();
            float rowW = GetContentRegionAvail().x - 16.0f;
            float rowH = 26.0f; // تقليل ارتفاع الصفوف
            
            rdl->AddRectFilled(rowPos, ImVec2(rowPos.x + rowW, rowPos.y + rowH), IM_COL32(10, 10, 40, 140), 4.0f);
            rdl->AddRect(rowPos, ImVec2(rowPos.x + rowW, rowPos.y + rowH), IM_COL32(0, 191, 255, 40), 4.0f, 0, 1.0f);
            
            float currentY = GetCursorPosY();
            SetCursorPosY(currentY + (rowH - GetTextLineHeight()) * 0.5f);
            SetCursorPosX(15);
            SetWindowFontScale(0.8f); // خط أصغر للمعلومات
            TextColored(ImVec4(0.7f, 0.7f, 1.0f, 1.0f), "%s", key);
            SameLine();
            
            float valWidth = CalcTextSize(val).x;
            SetCursorPosX(rowW - valWidth - 5.0f);
            TextColored(ImColor(valColor), "%s", val);
            
            SetWindowFontScale(1.0f);
            SetCursorPosY(currentY + rowH + 2.0f); // تقليل المسافة بين الصفوف
        };

        // Improved device info display with corrected values and better layout
        DrawDeviceInfoRow(O("Brand:"), s_manufacturer, IM_COL32(255, 220, 120, 255));
        DrawDeviceInfoRow(O("Device:"), s_model_name, IM_COL32(255, 220, 120, 255));
        DrawDeviceInfoRow(O("Android:"), s_android_ver, IM_COL32(103, 232, 249, 255));
        DrawDeviceInfoRow(O("Arch:"), s_abi, IM_COL32(103, 232, 249, 255));
        DrawDeviceInfoRow(O("Version:"), O("V11 / 56.26.2"), IM_COL32(167, 139, 250, 255));
        
        string shortId = g_Token.length() > 12 ? g_Token.substr(0, 12) + "..." : g_Token;
        DrawDeviceInfoRow(O(""), shortId.c_str(), IM_COL32(255, 255, 255, 255));

        // ── Separator before Contact Info ──
        Dummy(ImVec2(0, 4));
        {
            ImVec2 sp = GetCursorScreenPos();
            float sepX0 = sp.x + 10.0f;
            float sepX1 = sp.x + GetContentRegionAvail().x - 10.0f;
            float sepY = sp.y + 4.0f;
            if (sepX1 > sepX0) {
                rdl->AddLine(ImVec2(sepX0, sepY), ImVec2(sepX1, sepY), IM_COL32(192, 132, 252, 30), 4.0f);
                rdl->AddLine(ImVec2(sepX0, sepY), ImVec2(sepX1, sepY), IM_COL32(192, 132, 252, 50), 1.0f);
                rdl->AddCircleFilled(ImVec2(sepX0, sepY), 2.0f, IM_COL32(192, 132, 252, 60));
                rdl->AddCircleFilled(ImVec2(sepX1, sepY), 2.0f, IM_COL32(192, 132, 252, 60));
            }
        }
        Dummy(ImVec2(0, 8));

        // ── DM / TG Contact Info with Animated Glow Box ──
        {
            ImVec2 contactStart = GetCursorScreenPos();
            float contactPadX = 12.0f;
            float contactW = GetContentRegionAvail().x - contactPadX * 2.0f;
            float contactH = 58.0f;
            ImVec2 boxMin = ImVec2(contactStart.x + contactPadX, contactStart.y);
            ImVec2 boxMax = ImVec2(boxMin.x + contactW, boxMin.y + contactH);

            // Animated traveling glow border around contact box
            DrawTravelingGlowBorder(rdl, boxMin, boxMax, 0.75f, 0.55f, 0.99f, g_elecTime, 90.0f, 10.0f);
            rdl->AddRectFilled(boxMin, boxMax, IM_COL32(18, 14, 35, 230), 10.0f);

            // DM label
            float textY1 = boxMin.y + 10.0f;
            SetWindowFontScale(0.82f);

            // DM icon dot
            ImVec2 dmIconPos = ImVec2(boxMin.x + 14.0f, textY1 + GetTextLineHeight() * 0.5f);
            rdl->AddCircleFilled(dmIconPos, 3.5f, IM_COL32(239, 68, 68, 200));
            rdl->AddCircleFilled(dmIconPos, 6.0f, IM_COL32(239, 68, 68, 50));
            SetCursorPos(ImVec2(boxMin.x - GetWindowPos().x + 26.0f, textY1 - GetWindowPos().y));
            TextColored(ImVec4(0.94f, 0.75f, 0.85f, 1.0f), O("TG:- @FAN_GAMAL"));

            // TG label
            float textY2 = boxMin.y + 33.0f;
            ImVec2 tgIconPos = ImVec2(boxMin.x + 14.0f, textY2 + GetTextLineHeight() * 0.5f);
            rdl->AddCircleFilled(tgIconPos, 3.5f, IM_COL32(34, 211, 238, 200));
            rdl->AddCircleFilled(tgIconPos, 6.0f, IM_COL32(34, 211, 238, 50));
            SetCursorPos(ImVec2(boxMin.x - GetWindowPos().x + 26.0f, textY2 - GetWindowPos().y));
            TextColored(ImVec4(0.65f, 0.85f, 0.95f, 1.0f), O(""));

            SetWindowFontScale(1.0f);
            SetCursorPosY(boxMax.y - GetWindowPos().y + 12.0f);
        }

        // ── LICENSE DURATION (Moved to Right Column) ──
        {
            Dummy(ImVec2(0, 5));
            SetCursorPosX(15);
            TextColored(ImVec4(0.94f, 0.35f, 0.45f, 1.0f), O("KEY DURATION"));
            Dummy(ImVec2(0, 8));

            int64_t diff = g_expiry_timestamp - getAdjustedTime();
            int days = 0, hours = 0, mins = 0;
            if (diff > 0) {
                days = (int)(diff / 86400); hours = (int)((diff % 86400) / 3600); mins = (int)((diff % 3600) / 60);
            }

            ImVec2 childPos = GetCursorScreenPos();
            float availWidth = GetContentRegionAvail().x - 20.0f;
            float boxW = (availWidth - 20.0f) / 3.0f;
            float boxH = 75.0f;
            
            const char* labels[] = { O("DAYS"), O("HRS"), O("MIN") };
            int vals[] = { days, hours, mins };
            ImU32 colors[] = { IM_COL32(248, 113, 113, 255), IM_COL32(103, 232, 249, 255), IM_COL32(192, 132, 252, 255) };

            for (int i = 0; i < 3; i++) {
                ImVec2 bPos = ImVec2(childPos.x + 10.0f + i * (boxW + 10.0f), childPos.y);
                rdl->AddRectFilled(bPos, ImVec2(bPos.x + boxW, bPos.y + boxH), IM_COL32(30, 30, 45, 180), 8.0f);
                rdl->AddRect(bPos, ImVec2(bPos.x + boxW, bPos.y + boxH), IM_COL32(220, 20, 60, 40), 8.0f, 0, 1.0f);
                
                char valStr[16]; sprintf(valStr, "%02d", vals[i]);
                
                // Value
                SetWindowFontScale(1.4f);
                ImVec2 vSz = CalcTextSize(valStr);
                rdl->AddText(ImVec2(bPos.x + (boxW - vSz.x) * 0.5f, bPos.y + 8.0f), colors[i], valStr);
                
                // Label
                SetWindowFontScale(0.7f);
                ImVec2 lSz = CalcTextSize(labels[i]);
                rdl->AddText(ImVec2(bPos.x + (boxW - lSz.x) * 0.5f, bPos.y + 45.0f), IM_COL32(200, 200, 200, 200), labels[i]);
            }
            SetWindowFontScale(1.0f);
            Dummy(ImVec2(0, boxH + 10.0f));
        }

        EndChild();
    }

    // تم إزالة الفاصل والقسم السفلي القديم هنا لتوفير المساحة
    Dummy(ImVec2(0, 5));

    PopStyleColor();
    if (need_save) { save_persistence(); svConfig_Save(); }
}

// ─── Original Content (Kept for reference but bypassed) ───
static void DrawContentArea_Deprecated(float winW, float winH) {
    bool need_save = false;
    static float g_elecTime = 0.0f;
    g_elecTime += GetIO().DeltaTime;
    ImDrawList* dl  = GetWindowDrawList();
    ImVec2      wp  = GetWindowPos();
    float startY = GetCursorPosY();
    float padX    = 12.0f;
    if (false) {

    // Full content bg
    dl->AddRectFilled(
        ImVec2(wp.x, wp.y),
        ImVec2(wp.x + winW, wp.y + winH),
        CLR_BG_PANEL, 0.0f
    );

    // ── Title bar ──
    float titleBarH = 46.0f;
    float titleBarY = wp.y + startY;

    // Title bar background
    dl->AddRectFilled(
        ImVec2(wp.x, titleBarY),
        ImVec2(wp.x + winW, titleBarY + titleBarH),
        CLR_BG_CARD, 0.0f
    );

    // Violet neon accent stripe at very top
    dl->AddRectFilledMultiColor(
        ImVec2(wp.x, titleBarY),
        ImVec2(wp.x + winW, titleBarY + 2.5f),
        IM_COL32(139, 92, 246, 240), IM_COL32(167, 139, 250, 240),
        IM_COL32(167, 139, 250, 240), IM_COL32(139, 92, 246, 240)
    );

    // Title text
    SetWindowFontScale(1.05f);
    ImVec2 ts = CalcTextSize(O(""));
    float titleX = padX + 14.0f;
    float titleY = startY + (titleBarH - ts.y) * 0.5f;
    SetCursorPos(ImVec2(titleX, titleY));
    TextColored(ImVec4(0.75f, 0.65f, 1.0f, 1.0f), "%s", O(""));
    SetWindowFontScale(1.0f);

    // Close button in top-right corner
    {
        ImGuiWindow* win = GetCurrentWindow();
        ImGuiID closeId  = win->GetID(O("##CloseMenu"));
        float closeSide  = 32.0f;
        float closeX     = wp.x + winW - closeSide - 10.0f;
        float closeY     = titleBarY + (titleBarH - closeSide) * 0.5f;
        ImVec2 closePos  = ImVec2(closeX, closeY);
        ImRect closeBb(closePos, closePos + ImVec2(closeSide, closeSide));
        SetCursorPos(ImVec2(closePos.x - wp.x, closePos.y - wp.y));
        ItemSize(ImVec2(closeSide, closeSide), GImGui->Style.FramePadding.y);
        ItemAdd(closeBb, closeId);
        bool closeHovered = false, closeHeld = false;
        bool closePressed = ButtonBehavior(closeBb, closeId, &closeHovered, &closeHeld);
        if (closePressed) g_menu.isOpen = false;

        ImU32 closeBg = closeHovered ? CLR_CLOSE_HOV : CLR_CLOSE_BASE;
        ImVec2 hexCenter(closeX + closeSide * 0.5f, closeY + closeSide * 0.5f);
        float hexR = closeSide * 0.52f;
        // Glow layers
        dl->AddCircleFilled(hexCenter, hexR + 6.0f, IM_COL32(139, 92, 246, closeHovered ? 35 : 12));
        dl->AddCircleFilled(hexCenter, hexR + 3.0f, IM_COL32(167, 139, 250, closeHovered ? 55 : 22));
        // Hexagon filled
        DrawHexagonFilled(dl, hexCenter, hexR, closeBg, g_elecTime * 0.3f);
        // Hexagon border with gold glow
        DrawHexagon(dl, hexCenter, hexR, IM_COL32(139, 92, 246, closeHovered ? 230 : 110), closeHovered ? 2.5f : 1.5f, g_elecTime * 0.3f);

        float cx = closeX + closeSide * 0.5f;
        float cy = closeY + closeSide * 0.5f;
        float xH = closeSide * 0.22f;
        ImU32 xCol = IM_COL32(230, 225, 255, 255);
        dl->AddLine(ImVec2(cx - xH, cy - xH), ImVec2(cx + xH, cy + xH), xCol, 2.5f);
        dl->AddLine(ImVec2(cx + xH, cy - xH), ImVec2(cx - xH, cy + xH), xCol, 2.5f);
    }

    // Separator below title
    DrawSeparator(dl, wp.x + padX, wp.x + winW - padX, titleBarY + titleBarH);

    float headerH = titleBarH + 4.0f;

    // Two-column layout
    float colGap = 10.0f;
    float availW = winW - padX * 2 - colGap;
    float leftColW  = availW * 0.55f;
    float rightColW = availW - leftColW;
    float childH   = winH - startY - headerH - 12.0f;

    SetCursorPos(ImVec2(padX, startY + headerH));

    PushStyleColor(ImGuiCol_ChildBg, ImVec4(0, 0, 0, 0));

    // ── LEFT COLUMN: Settings & Controls (Card UI) ──
    BeginChild(O("##LeftCol"), ImVec2(leftColW, childH), false, ImGuiWindowFlags_NoScrollbar);
    {
        ImDrawList* ldl = GetWindowDrawList();

        // ── Animated glowing separator line helper ──
        auto DrawAnimatedSep = [&](float padL = 16.0f, float padR = 16.0f) {
            ImVec2 sp = GetCursorScreenPos();
            float sepY = sp.y + 1.0f;
            float x0 = sp.x + padL;
            float x1 = sp.x + GetContentRegionAvail().x - padR;
            if (x1 <= x0) return;
            float t = g_elecTime;
            // Animated flow: moving bright point along the line
            float flowPos = 0.5f + 0.5f * sinf(t * 3.0f);
            float flowX = x0 + (x1 - x0) * flowPos;
            float flowW = 60.0f + 20.0f * sinf(t * 2.3f);
            // Outer soft glow
            ldl->AddLine(ImVec2(x0, sepY), ImVec2(x1, sepY), IM_COL32(139, 92, 246, 30), 5.0f);
            // Base dim line
            ldl->AddLine(ImVec2(x0, sepY), ImVec2(x1, sepY), IM_COL32(139, 92, 246, 55), 1.0f);
            // Flowing bright sweep
            ldl->AddLine(ImVec2(fmaxf(x0, flowX - flowW * 0.5f), sepY), ImVec2(fminf(x1, flowX + flowW * 0.5f), sepY), IM_COL32(167, 139, 250, 120), 2.0f);
            // Center bright point
            ldl->AddLine(ImVec2(fmaxf(x0, flowX - 8.0f), sepY), ImVec2(fminf(x1, flowX + 8.0f), sepY), IM_COL32(230, 225, 255, 200), 2.5f);
            // Tiny edge glow dots
            ldl->AddCircleFilled(ImVec2(x0, sepY), 2.0f, IM_COL32(139, 92, 246, 80));
            ldl->AddCircleFilled(ImVec2(x1, sepY), 2.0f, IM_COL32(167, 139, 250, 80));
            Dummy(ImVec2(0, 4));
        };

        // ── Draw Lines ──
        {
            Dummy(ImVec2(0, 4));
            SetCursorPos(ImVec2(GetCursorPosX() + 4.0f, GetCursorPosY()));
            need_save |= ToggleSwitch(O("Lines"), &persistent_bool[O("bESP_DrawPredictionLine")]);
            SetCursorPosY(GetCursorPosY() + 2.0f);
        }
        DrawAnimatedSep();

        {
            SetCursorPos(ImVec2(GetCursorPosX() + 4.0f, GetCursorPosY()));
            need_save |= ToggleSwitch(O("Pockets"), &persistent_bool[O("bESP_DrawPocketsShotState")]);
            SetCursorPosY(GetCursorPosY() + 2.0f);
        }
        DrawAnimatedSep();

        // ── Enable AutoPlay ──
        {
            SetCursorPos(ImVec2(GetCursorPosX() + 4.0f, GetCursorPosY()));
            need_save |= ToggleSwitch(O("AutoPlay"), &persistent_bool[O("bAutoPlay")]);
            SetCursorPosY(GetCursorPosY() + 2.0f);
        }
        DrawAnimatedSep();

        // ── Enable AutoQueue ──
        {
            SetCursorPos(ImVec2(GetCursorPosX() + 4.0f, GetCursorPosY()));
            need_save |= ToggleSwitch(O("AutoQueue"), &persistent_bool[O("bAutoQueue")]);
            SetCursorPosY(GetCursorPosY() + 2.0f);
        }
        DrawAnimatedSep();
        
        Dummy(ImVec2(0, 10)); // مسافة بسيطة
        {
            Dummy(ImVec2(0, 10));
            SetCursorPos(ImVec2(GetCursorPosX() + 4.0f, GetCursorPosY() + 4.0f));
            TextColored(ImVec4(0.75f, 0.65f, 1.0f, 0.9f), O("TG:-@FAN_GAMAL"));
            SetCursorPos(ImVec2(GetCursorPosX(), GetCursorPosY() + 2.0f));
            TextColored(ImVec4(0.75f, 0.65f, 1.0f, 0.9f), O(""));
            SetCursorPosY(GetCursorPosY() + 6.0f);
        }

        Dummy(ImVec2(0, 6));

        // Auto-save indicator (replaces Save Config button)
        {
            ImVec2 indPos = GetCursorScreenPos();
            float indW = GetContentRegionAvail().x;
            float indH = 28.0f;
            ldl->AddRectFilled(indPos, ImVec2(indPos.x + indW, indPos.y + indH), CLR_BG_CARD, 8.0f);
            ldl->AddRect(indPos, ImVec2(indPos.x + indW, indPos.y + indH), IM_COL32(139, 92, 246, 40), 8.0f, 0, 1.0f);
            SetCursorPos(ImVec2(GetCursorPosX() + 12.0f, GetCursorPosY() + 5.0f));
            TextColored(ImVec4(0.75f, 0.65f, 1.0f, 0.7f), O(""));
            SameLine();
            // Animated dot indicator
            static float g_autoSavePulse = 0.0f;
            g_autoSavePulse += GImGui->IO.DeltaTime * 3.0f;
            float pulse = 0.4f + 0.6f * (0.5f + 0.5f * sinf(g_autoSavePulse));
            float dotR = 4.0f;
            ImVec2 dotCenter = ImVec2(GetCursorScreenPos().x + 8.0f, indPos.y + indH * 0.5f);
            ldl->AddCircleFilled(dotCenter, dotR + 2.0f, IM_COL32(139, 92, 246, (int)(pulse * 60)));
            ldl->AddCircleFilled(dotCenter, dotR, IM_COL32(167, 139, 250, (int)(pulse * 255)));
            SetCursorPosY(GetCursorPosY() + 4.0f);
        }
    }
    EndChild();

    // Two distinct gold/amber separator lines between left and right columns
    {
        float sepX = padX + leftColW + colGap * 0.5f;
        float sepY0 = wp.y + startY + headerH + 8.0f;
        float sepY1 = wp.y + winH - 10.0f;
        // Line 1 (left)
        dl->AddLine(ImVec2(sepX - 3, sepY0), ImVec2(sepX - 3, sepY1), IM_COL32(139, 92, 246, (int)(0.40f * 255)), 1.5f);
        // Line 2 (right)
        dl->AddLine(ImVec2(sepX + 3, sepY0), ImVec2(sepX + 3, sepY1), IM_COL32(167, 139, 250, (int)(0.30f * 255)), 1.0f);
    }

    SameLine(0, colGap);

    // ── RIGHT COLUMN: License & Device Info ──
    BeginChild(O("##RightCol"), ImVec2(rightColW, childH), false, ImGuiWindowFlags_NoScrollbar);
    {
        ImDrawList* rdl = GetWindowDrawList();

        Dummy(ImVec2(0, 8));

        // ── VIP LICENSE card ──
        {
            float cardW = GetContentRegionAvail().x;
            float cardH = 265.0f;
            ImVec2 cardPos = GetCursorScreenPos();
            DrawCardBegin(rdl, cardPos, cardW, cardH);

            // Title — crimson accent
            SetCursorPos(ImVec2(GetCursorPosX() + 14.0f, GetCursorPosY() + 12.0f));
            SetWindowFontScale(0.88f);
            TextColored(ImVec4(0.94f, 0.35f, 0.45f, 1.0f), "%s", O("Kay Duration"));
            SetWindowFontScale(1.0f);
            Dummy(ImVec2(0, 4));

            // Show raw expiry date/time exactly as received from server
            if (!g_server_exp_raw.empty() && g_server_exp_raw != "N/A") {
                SetCursorPos(ImVec2(GetCursorPosX() + 14.0f, GetCursorPosY()));
                SetWindowFontScale(0.65f);
                TextColored(ImVec4(0.55f, 0.75f, 0.95f, 0.9f), "%s", ("Expires: " + g_server_exp_raw).c_str());
                SetWindowFontScale(1.0f);
                Dummy(ImVec2(0, 4));
            }

            Dummy(ImVec2(0, 4));

            // Calculate expiry time using server-adjusted time
            int64_t now_ts = getAdjustedTime();
            int64_t expiry_ts = g_expiry_timestamp;
            int64_t diff = expiry_ts - now_ts;
            int days = 0, hours = 0, mins = 0;
            if (diff > 0) {
                int64_t totalSecs = diff;
                days  = (int)(totalSecs / 86400);
                hours = (int)((totalSecs % 86400) / 3600);
                mins  = (int)((totalSecs % 3600)  / 60);
            }

            // ── LUXURY Digit Boxes ──
            {
                ImVec2 boxAreaStart = GetCursorScreenPos();
                float padX = 14.0f;
                float boxGap = 10.0f;
                float boxW = (cardW - padX * 2.0f - boxGap * 2.0f) / 3.0f;
                float boxH = 90.0f;
                float boxY = boxAreaStart.y + padX;

                const char* boxLabels[3] = { O("DAYS"), O("HOURS"), O("MINUTES") };
                int values[3] = { days, hours, mins };
                ImU32 colors[3] = { IM_COL32(255, 50, 50, 255), IM_COL32(220, 20, 60, 255), IM_COL32(180, 10, 30, 255) };

                for (int b = 0; b < 3; b++) {
                    float bx = boxAreaStart.x + padX + b * (boxW + boxGap);
                    ImVec2 bPos = ImVec2(bx, boxY);
                    ImVec2 bEnd = ImVec2(bPos.x + boxW, bPos.y + boxH);

                    rdl->AddRectFilledMultiColor(bPos, bEnd, 
                        IM_COL32(60, 10, 10, 255), IM_COL32(20, 5, 5, 255),
                        IM_COL32(20, 5, 5, 255), IM_COL32(60, 10, 10, 255));
                    rdl->AddRect(bPos, bEnd, colors[b], 10.0f, 0, 1.5f);
                    
                    if (diff > 0 && fmodf(g_elecTime, 2.0f) < 0.1f) {
                        DrawLightning(rdl, bPos, ImVec2(bPos.x + boxW, bPos.y), IM_COL32(255, 255, 255, 100), 1.0f);
                    }

                    char vBuf[16]; snprintf(vBuf, sizeof(vBuf), "%02d", diff > 0 ? values[b] : 0);
                    SetWindowFontScale(1.8f);
                    ImVec2 vSz = CalcTextSize(vBuf);
                    rdl->AddText(ImVec2(bPos.x + (boxW - vSz.x) * 0.5f, bPos.y + 10.0f), IM_COL32(255, 255, 255, 255), vBuf);
                    
                    SetWindowFontScale(0.7f);
                    ImVec2 lSz = CalcTextSize(boxLabels[b]);
                    rdl->AddText(ImVec2(bPos.x + (boxW - lSz.x) * 0.5f, bEnd.y - lSz.y - 10.0f), colors[b], boxLabels[b]);
                    SetWindowFontScale(1.0f);
                }
                SetCursorPosY(GetCursorPosY() + padX + boxH + 8.0f);
            }

            // Separator
            {
                ImVec2 sp = GetCursorScreenPos();
                DrawSeparator(rdl, sp.x + 14.0f, sp.x + cardW - 14.0f, sp.y + 4.0f, 0.5f);
            }
            Dummy(ImVec2(0, 6));

            // ── Time Unit Selector — Total Days / Total Hours / Total Minutes ──
            {
                ImVec2 selStart = GetCursorScreenPos();
                float sPad = 14.0f;
                float sGap = 8.0f;
                float sBtnW = (cardW - sPad * 2.0f - sGap * 2.0f) / 3.0f;
                float sBtnH = 30.0f;

                float sR[3] = { 0.94f, 0.13f, 0.75f };
                float sG[3] = { 0.27f, 0.83f, 0.55f };
                float sB[3] = { 0.35f, 0.93f, 0.99f };

                const char* sLabels[3] = { O("Days"), O("Hours"), O("Minutes") };
                int sVals[3] = { days, days * 24 + hours, days * 1440 + hours * 60 + mins };

                static int selectedUnit = 0;

                for (int s = 0; s < 3; s++) {
                    float sBtnX = selStart.x + sPad + s * (sBtnW + sGap);
                    float sBtnY = selStart.y;
                    ImVec2 sP0 = ImVec2(sBtnX, sBtnY);
                    ImVec2 sP1 = ImVec2(sP0.x + sBtnW, sP0.y + sBtnH);
                    bool isSel = (selectedUnit == s);

                    ImGuiWindow* sWin = GetCurrentWindow();
                    char sId[32];
                    snprintf(sId, sizeof(sId), "vip_sel_%d", s);
                    ImGuiID sBtnId = sWin->GetID(sId);
                    ImRect sBb(sP0, sP1);
                    SetCursorPos(ImVec2(sP0.x - GetWindowPos().x, sP0.y - GetWindowPos().y));
                    ItemSize(ImVec2(sBtnW, sBtnH), 0);
                    ItemAdd(sBb, sBtnId);

                    bool sHov = false, sHeld = false;
                    bool sPress = ButtonBehavior(sBb, sBtnId, &sHov, &sHeld);
                    if (sPress) selectedUnit = s;

                    // Button background
                    int sBgR = (int)(sR[s] * (isSel ? 35 : 15)) + 10;
                    int sBgG = (int)(sG[s] * (isSel ? 28 : 10)) + 8;
                    int sBgB = (int)(sB[s] * (isSel ? 45 : 18)) + 12;
                    rdl->AddRectFilled(sP0, sP1, IM_COL32(sBgR, sBgG, sBgB, 255), 8.0f);

                    // Hover overlay
                    if (sHov && !isSel) {
                        rdl->AddRectFilled(sP0, sP1, IM_COL32(40, 35, 60, 120), 8.0f);
                    }

                    // Button border
                    float sBdrA = isSel ? 230 : 55;
                    rdl->AddRect(sP0, sP1,
                        IM_COL32((int)(sR[s]*255), (int)(sG[s]*255), (int)(sB[s]*255), (int)sBdrA),
                        8.0f, 0, isSel ? 1.5f : 1.0f);

                    // Outer glow on selected
                    if (isSel) {
                        rdl->AddRect(ImVec2(sP0.x-2, sP0.y-2), ImVec2(sP1.x+2, sP1.y+2),
                            IM_COL32((int)(sR[s]*255), (int)(sG[s]*255), (int)(sB[s]*255), 45),
                            10.0f, 0, 3.0f);
                    }

                    // Button text
                    char sTxt[48];
                    snprintf(sTxt, sizeof(sTxt), "%s: %d", sLabels[s], diff > 0 ? sVals[s] : 0);
                    SetWindowFontScale(0.7f);
                    ImVec2 sTSz = CalcTextSize(sTxt);
                    rdl->AddText(ImVec2(sP0.x + (sBtnW - sTSz.x) * 0.5f, sP0.y + (sBtnH - sTSz.y) * 0.5f),
                        isSel ? IM_COL32(241, 245, 249, 255) : CLR_TEXT_MUTED, sTxt);
                    SetWindowFontScale(1.0f);
                }

                SetCursorPosY(GetCursorPosY() + sBtnH + 8.0f);
            }

            // Separator
            {
                ImVec2 sp = GetCursorScreenPos();
                DrawSeparator(rdl, sp.x + 14.0f, sp.x + cardW - 14.0f, sp.y + 4.0f, 0.5f);
            }
            Dummy(ImVec2(0, 6));

            // ── Line Thickness Circles — VIP color theme ──
            {
                ImVec2 circScreenStart = GetCursorScreenPos();
                float innerPadX = 14.0f;
                float circleR   = 20.0f;
                float circGap     = 24.0f;
                float sqPad       = 6.0f;
                float sqSize      = (circleR + sqPad) * 2.0f;
                float totalCircW = sqSize * 3.0f + circGap * 2.0f;
                float startScreenX = circScreenStart.x + innerPadX + (cardW - innerPadX * 2.0f - totalCircW) * 0.5f;
                float circleScreenY = circScreenStart.y + sqPad + 2.0f;

                ImVec2 childWp = GetWindowPos();

                int thicknessValues[3] = { 3, 7, 10 };
                const char* thicknessLabels[5] = { O("3"), O("7"), O("10") };
                ImU32 glowColors[3] = {
                    IM_COL32(239, 68, 68, 80),     // Red glow
                    IM_COL32(34, 211, 238, 80),     // Cyan glow
                    IM_COL32(192, 132, 252, 80)     // Violet glow
                };
                ImU32 borderColors[3] = {
                    IM_COL32(239, 68, 68, 180),     // Red border
                    IM_COL32(34, 211, 238, 180),    // Cyan border
                    IM_COL32(192, 132, 252, 180)    // Violet border
                };
                int currentThick = persistent_int[O("iLineThickness")];

                for (int c = 0; c < 3; c++) {
                    float sqX = startScreenX + c * (sqSize + circGap);
                    float sqY = circleScreenY;
                    float cx = sqX + sqSize * 0.5f;
                    float cy = sqY + sqSize * 0.5f;
                    bool isSelected = (currentThick == thicknessValues[c]);

                    ImGuiWindow* win = GetCurrentWindow();
                    char circId[32];
                    snprintf(circId, sizeof(circId), "%d", c);
                    ImGuiID circBtnId = win->GetID(circId);

                    ImVec2 circMin(cx - circleR, cy - circleR);
                    ImVec2 circMax(cx + circleR, cy + circleR);
                    ImRect circBb(circMin, circMax);

                    SetCursorPos(ImVec2(circMin.x - childWp.x, circMin.y - childWp.y));
                    ItemSize(ImVec2(circleR * 2.0f, circleR * 2.0f), 0);
                    ItemAdd(circBb, circBtnId);

                    bool circHovered = false, circHeld = false;
                    bool circPressed = ButtonBehavior(circBb, circBtnId, &circHovered, &circHeld);
                    if (circPressed) {
                        persistent_int[O("iLineThickness")] = thicknessValues[c];
                        need_save = true;
                    }

                    ImVec2 sqMin(sqX, sqY);
                    ImVec2 sqMax(sqX + sqSize, sqY + sqSize);

                    // Outer glow layers on selected
                    if (isSelected) {
                        rdl->AddRect(ImVec2(sqMin.x - 4, sqMin.y - 4), ImVec2(sqMax.x + 4, sqMax.y + 4), glowColors[c], 14.0f, 0, 4.0f);
                        rdl->AddRect(ImVec2(sqMin.x - 2, sqMin.y - 2), ImVec2(sqMax.x + 2, sqMax.y + 2), glowColors[c], 13.0f, 0, 3.0f);
                    }

                    // Square frame background
                    ImU32 sqBg = isSelected ? IM_COL32(40, 30, 50, 255) : IM_COL32(18, 16, 30, 255);
                    rdl->AddRectFilled(sqMin, sqMax, sqBg, 10.0f);
                    // Square frame border
                    float bdrAlpha = isSelected ? 220 : 70;
                    rdl->AddRect(sqMin, sqMax, borderColors[c], 10.0f, 0, isSelected ? 2.0f : 1.0f);

                    // Circle fill (inside square)
                    ImU32 circBg = isSelected ? IM_COL32(35, 25, 50, 255) : IM_COL32(24, 22, 40, 255);
                    ImU32 circBorder = isSelected ? borderColors[c] : IM_COL32(70, 60, 100, 255);
                    rdl->AddCircleFilled(ImVec2(cx, cy), circleR, circBg, 32);
                    rdl->AddCircle(ImVec2(cx, cy), circleR, circBorder, 32, isSelected ? 2.5f : 1.5f);

                    // Value text inside circle
                    char valStr[8];
                    snprintf(valStr, sizeof(valStr), "%d", thicknessValues[c]);
                    ImVec2 valSz = CalcTextSize(valStr);
                    rdl->AddText(ImVec2(cx - valSz.x * 0.5f, cy - valSz.y * 0.5f),
                                 isSelected ? IM_COL32(255, 255, 255, 255) : CLR_TEXT_PRIMARY, valStr);

                    // Label text below the square frame
                    ImVec2 lblSz = CalcTextSize(thicknessLabels[c]);
                    float lblX = cx - lblSz.x * 0.5f;
                    float lblY = sqMax.y + 3.0f;
                    rdl->AddText(ImVec2(lblX, lblY), isSelected ? borderColors[c] : CLR_TEXT_MUTED, thicknessLabels[c]);
                }

                SetCursorPosY(GetCursorPosY() + sqSize + 18.0f);
            }

            // Bottom separator
            Dummy(ImVec2(0, 4));
            {
                ImVec2 sp = GetCursorScreenPos();
                DrawSeparator(rdl, sp.x + 14.0f, sp.x + cardW - 14.0f, sp.y + 4.0f, 0.5f);
            }
            Dummy(ImVec2(0, 6));

            Dummy(ImVec2(0, cardH - GetCursorPosY() + cardPos.y));
        }

        // ── Separate DEVICE INFO card ──
        {
            Dummy(ImVec2(0, 8));

            float devCardW = GetContentRegionAvail().x;
            float devCardH = 170.0f;// تطلع
            ImVec2 devCardPos = GetCursorScreenPos();
            DrawCardBegin(rdl, devCardPos, devCardW, devCardH);

            // Title
            SetCursorPos(ImVec2(GetCursorPosX() + 12.0f, GetCursorPosY() + 10.0f));
            SetWindowFontScale(0.82f);
            TextColored(ImVec4(0.83f, 0.69f, 0.22f, 1.0f), "%s", O("DEVICE INFO"));
            SetWindowFontScale(1.0f);

            Dummy(ImVec2(0, 6));

            // Separator under title
            {
                ImVec2 sp = GetCursorScreenPos();
                DrawSeparator(rdl, sp.x + 10.0f, sp.x + devCardW - 10.0f, sp.y + 4.0f, 0.4f);
            }

            Dummy(ImVec2(0, 6));

            static char s_manufacturer[PROP_VALUE_MAX] = {};
            static char s_model[PROP_VALUE_MAX]        = {};
            static char s_abi[PROP_VALUE_MAX]          = {};
            static char s_android[PROP_VALUE_MAX]      = {};
            static bool s_props_loaded = false;
            if (!s_props_loaded) {
                __system_property_get("ro.product.manufacturer", s_manufacturer);
                __system_property_get("ro.product.model",        s_model);
                __system_property_get("ro.product.cpu.abi",      s_abi);
                __system_property_get("ro.build.version.release", s_android);
                s_props_loaded = true;
            }

            auto DrawInfoRow = [&](const char* key, const char* val) {
                SetCursorPosX(GetCursorPosX() + 12.0f);

                // Row background for better readability
                ImVec2 rowPos = GetCursorScreenPos();
                float rowH = GetTextLineHeight() + 4.0f;
                rdl->AddRectFilled(rowPos, ImVec2(rowPos.x + devCardW - 24.0f, rowPos.y + rowH), IM_COL32(30, 26, 18, 180), 6.0f);

                TextColored(ImVec4(0.75f, 0.65f, 0.35f, 1.0f), "%s", key);
                SameLine();
                TextColored(ImVec4(0.95f, 0.92f, 0.85f, 1.0f), "%s", val);
                Dummy(ImVec2(0, 4));
            };

            DrawInfoRow(O("Mfg:  "), s_manufacturer);
            DrawInfoRow(O("Model:"), s_model);
            DrawInfoRow(O("ABI:  "), s_abi);
            DrawInfoRow(O("Android:   "), s_android);

            Dummy(ImVec2(0, devCardH - GetCursorPosY() + devCardPos.y));
        }
    }
    EndChild();

    PopStyleColor();

    if (need_save) {
        save_persistence();
        svConfig_Save();
    }
}
}


// ─── Main menu window ─────────────────────────────────────────────────────────
INLINE void DrawMenu(ImGuiIO& io) {
    if (!g_Token.empty() && !g_Auth.empty() && g_Token == g_Auth) {
        if (is_segv_handler_active()) {
            jump_buffer_active = 1;
            if (!sigsetjmp(jump_buffer, 1)) DrawESP(GetBackgroundDrawList());
            jump_buffer_active = 0;
        }

        if (g_menu.isOpen) {
            g_menu.menuAlpha += (1.0f - g_menu.menuAlpha) * io.DeltaTime * 12.0f;
        } else {
            g_menu.menuAlpha = 0.0f;
        }

        if (g_menu.menuAlpha > 0.01f) {
            float sizeScale = 1.0f + (float)persistent_int[O("iMenuSizeOffset")] * 0.03f;
            if (sizeScale < 0.3f) sizeScale = 0.3f;
            float winW = g_menu.menuWidth * sizeScale;
            float winH = 550.0f * sizeScale; // تقليل الارتفاع بشكل كبير لجعل القائمة مدمجة ومريحة

            SetNextWindowSize(ImVec2(winW, winH), ImGuiCond_Always);
            SetNextWindowPos(ImVec2(Width / 2.0f, Height / 2.0f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));

            PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.0f, 0.0f, 0.0f, 0.0f));
            PushStyleVar(ImGuiStyleVar_WindowRounding,  20.0f);
            PushStyleVar(ImGuiStyleVar_WindowPadding,   ImVec2(0, 0));
            PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);
            PushStyleVar(ImGuiStyleVar_Alpha, g_menu.menuAlpha);

            ImGuiWindowFlags winFlags =
                ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar |
                ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse |
                ImGuiWindowFlags_NoResize    | ImGuiWindowFlags_NoMove;

            if (Begin(O("##MainMenu"), &g_menu.isOpen, winFlags)) {
                ImDrawList* dl  = GetWindowDrawList();
                ImVec2 mwp = GetWindowPos();
                ImVec2 mws = GetWindowSize();

                // ── Window shell: full background fill ──
                dl->AddRectFilled(mwp, ImVec2(mwp.x + mws.x, mwp.y + mws.y),
                                  CLR_BG_DEEP, 20.0f);

                // ── Animated electric background ──
                {
                    static float g_elecTime = 0.0f;
                    g_elecTime += io.DeltaTime;

                    dl->PushClipRect(mwp, ImVec2(mwp.x + mws.x, mwp.y + mws.y), true);

                    // Horizontal electric arcs
                    for (int arc = 0; arc < 4; arc++) {
                        float baseY = mwp.y + mws.y * (0.15f + arc * 0.25f);
                        float phaseOff = arc * 1.7f;
                        float speed = 2.5f + arc * 0.8f;
                        float alphaBase = 18.0f + arc * 5.0f;

                        ImVec2 prevPt;
                        for (int seg = 0; seg <= 12; seg++) {
                            float t = (float)seg / 12.0f;
                            float x = mwp.x + 15.0f + t * (mws.x - 30.0f);
                            float wave1 = sinf(g_elecTime * speed + t * 8.0f + phaseOff) * 6.0f;
                            float wave2 = sinf(g_elecTime * speed * 1.3f + t * 12.0f + phaseOff + 2.0f) * 3.0f;
                            float y = baseY + wave1 + wave2;
                            ImVec2 pt(x, y);

                            if (seg > 0) {
                                float segAlpha = alphaBase * (0.5f + 0.5f * sinf(g_elecTime * 3.0f + seg * 0.5f + arc));
                                ImU32 arcCol;
                                if (arc % 2 == 0)
                                    arcCol = IM_COL32(139, 92, 246, (int)segAlpha);
                                else
                                    arcCol = IM_COL32(167, 139, 250, (int)segAlpha);
                                dl->AddLine(prevPt, pt, arcCol, 1.0f);
                            }
                            prevPt = pt;
                        }
                    }

                    // Vertical subtle arcs
                    for (int varc = 0; varc < 3; varc++) {
                        float baseX = mwp.x + mws.x * (0.2f + varc * 0.3f);
                        float phaseOff = varc * 2.3f;

                        ImVec2 prevPt;
                        for (int seg = 0; seg <= 8; seg++) {
                            float t = (float)seg / 8.0f;
                            float y = mwp.y + 15.0f + t * (mws.y - 30.0f);
                            float wave = sinf(g_elecTime * 1.8f + t * 6.0f + phaseOff) * 4.0f;
                            ImVec2 pt(baseX + wave, y);

                            if (seg > 0) {
                                float segAlpha = 12.0f + 8.0f * sinf(g_elecTime * 2.5f + varc + seg);
                                dl->AddLine(prevPt, pt, IM_COL32(139, 92, 246, (int)segAlpha), 0.8f);
                            }
                            prevPt = pt;
                        }
                    }

                    // Flickering nodes
                    for (int nd = 0; nd < 6; nd++) {
                        float nx = mwp.x + mws.x * (0.15f + nd * 0.14f);
                        float ny = mwp.y + mws.y * (0.3f + (nd % 3) * 0.2f);
                        float flicker = 0.5f + 0.5f * sinf(g_elecTime * (4.0f + nd * 0.7f) + nd * 1.1f);
                        float nodeAlpha = flicker * 22.0f;
                        ImU32 nodeCol = (nd % 2 == 0) ? IM_COL32(139, 92, 246, (int)nodeAlpha) : IM_COL32(167, 139, 250, (int)nodeAlpha);
                        dl->AddCircleFilled(ImVec2(nx, ny), 3.0f + flicker * 2.0f, nodeCol);
                    }

                    dl->PopClipRect();
                }

                // ── Outer border ring: violet ──
                dl->AddRect(mwp, ImVec2(mwp.x + mws.x, mwp.y + mws.y),
                            IM_COL32(139, 92, 246, 65), 20.0f, 0, 1.5f);

                // ── Bright lavender border effect around entire menu ──
                dl->AddRect(mwp, ImVec2(mwp.x + mws.x, mwp.y + mws.y),
                            IM_COL32(237, 233, 254, 30), 20.0f, 0, 3.0f);
                dl->AddRect(mwp, ImVec2(mwp.x + mws.x, mwp.y + mws.y),
                            IM_COL32(167, 139, 250, 50), 22.0f, 0, 5.0f);
                dl->AddRect(mwp, ImVec2(mwp.x + mws.x, mwp.y + mws.y),
                            IM_COL32(237, 233, 254, 15), 24.0f, 0, 7.0f);
                dl->AddRect(mwp, ImVec2(mwp.x + mws.x, mwp.y + mws.y),
                            IM_COL32(196, 181, 253, 25), 26.0f, 0, 9.0f);

                // Ambient corner glows — violet/cyan
                dl->AddCircleFilled(ImVec2(mwp.x + mws.x * 0.25f, mwp.y),
                                    55.0f, IM_COL32(139, 92, 246, 15));
                dl->AddCircleFilled(ImVec2(mwp.x + mws.x * 0.75f, mwp.y + mws.y),
                                    55.0f, IM_COL32(103, 232, 249, 12));

                // ── Top accent stripe: violet gradient ──
                dl->AddRectFilledMultiColor(
                    mwp, ImVec2(mwp.x + mws.x, mwp.y + 2.5f),
                    IM_COL32(139, 92, 246, 240), IM_COL32(167, 139, 250, 240),
                    IM_COL32(167, 139, 250, 240), IM_COL32(139, 92, 246, 240)
                );

                // Bright lavender glow at top edge
                dl->AddRect(mwp, ImVec2(mwp.x + mws.x, mwp.y + 1.0f),
                            IM_COL32(216, 210, 255, 90), 0.0f);

                DrawContentArea(winW, winH);
            }
            End();

            PopStyleVar(4);
            PopStyleColor();
        }
    }
}

static void DrawToggleButton(bool cancelMode) {
    if (g_menu.isOpen) return;

    ImGuiIO& io = GetIO();
    static GLuint play_on_tex      = LoadTextureFromMemory(play_on_png,  play_on_png_len);
    static GLuint play_off_tex     = LoadTextureFromMemory(play_off_png, play_off_png_len);
    static GLuint queue_cancel_tex = LoadTextureFromMemory(play_on_png,  play_on_png_len);

    float button_size  = 130.f;
    float windowWidth  = button_size + GetStyle().WindowPadding.x * 2.0f;
    float windowHeight = button_size + GetStyle().WindowPadding.y * 2.0f;
    const float rightMargin = 100.0f;

    float fixedX = io.DisplaySize.x - rightMargin - windowWidth;
    float fixedY = io.DisplaySize.y - 150.0f;

    SetNextWindowSize(ImVec2(windowWidth, windowHeight), ImGuiCond_Always);
    SetNextWindowPos(ImVec2(fixedX, fixedY), ImGuiCond_Always);

    PushStyleColor(ImGuiCol_WindowBg, IM_COL32(0, 0, 0, 0));
    PushStyleColor(ImGuiCol_Border,   IM_COL32(0, 0, 0, 0));
    PushStyleVar(ImGuiStyleVar_WindowRounding, 99.0f);

    if (Begin(O("##ToggleBtn"), nullptr,
              ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
              ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoMove)) {

        ImVec2 pos = GetCursorScreenPos();
        ImVec2 size(button_size, button_size);
        ImVec2 center(pos.x + size.x * 0.5f, pos.y + size.y * 0.5f);

        if (InvisibleButton(O("##TglBtnHit"), size)) {
            if (cancelMode) {
                persistent_bool[O("bAutoQueue")] = false;
                g_aqCounting = false;
            } else {
                AutoPlay::bAutoPlaying = !AutoPlay::bAutoPlaying;
                if (AutoPlay::bAutoPlaying) AutoPlay::ClearState();
            }
        }

        GLuint tex;
        if (cancelMode) tex = queue_cancel_tex;
        else tex = AutoPlay::bAutoPlaying ? play_on_tex : play_off_tex;

        float r = size.x * 0.5f;
        ImDrawList* dl = GetWindowDrawList();
        dl->AddImage((void*)(intptr_t)tex, ImVec2(center.x - r, center.y - r), ImVec2(center.x + r, center.y + r));
    }
    End();
    PopStyleVar();
    PopStyleColor(2);
}

// ─── Floating toggle button ───────────────────────────────────────────────────
static void DrawFloatingButton(ImGuiIO& io) {
    static GLuint logo_tex   = LoadTextureFromMemory(logo_png, logo_png_len);
    static bool   isDragging = false;
    static float  dragVelocityX = 0.0f;
    static float  dragVelocityY = 0.0f;
    static float  lastDragX = 0.0f;
    static float  lastDragY = 0.0f;

    float buttonRadius = 70.0f;
    float buttonSize   = buttonRadius * 2.0f;
    float winSize      = buttonSize + 10.0f;
    float margin       = 8.0f;

    float toggleWinH = GetFrameHeight() * 1.7f + GetStyle().WindowPadding.y * 2.0f;
    const float edgeMargin = 10.0f;
    float toggleWinW = GetFrameHeight() * 1.7f + GetStyle().WindowPadding.x * 2.0f;
    float maxWinW    = ImMax(winSize, toggleWinW);

    if (g_sideBtnsY == 0.0f)
        g_sideBtnsY = io.DisplaySize.y - 80.0f - toggleWinH;
    if (g_sideBtnsX == 0.0f)
        g_sideBtnsX = io.DisplaySize.x - edgeMargin - maxWinW;

    float posY = g_sideBtnsY - winSize - margin;
    float posX = g_sideBtnsX;

    // Smooth velocity-based momentum after release
    if (!isDragging && (ImFabs(dragVelocityX) > 0.5f || ImFabs(dragVelocityY) > 0.5f)) {
        g_sideBtnsX += dragVelocityX * io.DeltaTime * 8.0f;
        g_sideBtnsY += dragVelocityY * io.DeltaTime * 8.0f;
        dragVelocityX *= 0.88f;
        dragVelocityY *= 0.88f;
        g_sideBtnsX = ImClamp(g_sideBtnsX, edgeMargin, io.DisplaySize.x - edgeMargin - maxWinW);
        g_sideBtnsY = ImClamp(g_sideBtnsY, winSize + margin, io.DisplaySize.y - edgeMargin - toggleWinH);
        // Save position after momentum settles
        if (ImFabs(dragVelocityX) < 1.0f && ImFabs(dragVelocityY) < 1.0f) {
            svConfig_Save();
        }
    }

    SetNextWindowPos(ImVec2(posX, posY), ImGuiCond_Always);
    SetNextWindowSize(ImVec2(winSize, winSize), ImGuiCond_Always);
    PushStyleColor(ImGuiCol_WindowBg, ImVec4(0, 0, 0, 0));
    PushStyleVar(ImGuiStyleVar_WindowPadding,   ImVec2(0, 0));
    PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);

    if (Begin(O("##FloatBtn"), nullptr,
              ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar |
              ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings)) {

        ImDrawList* dl     = GetWindowDrawList();
        ImVec2      center = ImVec2(posX + buttonRadius + 5, posY + buttonRadius + 5);

        SetCursorPos(ImVec2(0, 0));
        InvisibleButton(O("##FloatBtnHit"), ImVec2(winSize, winSize));

        dl->AddImage((void*)(intptr_t)logo_tex,
                     ImVec2(center.x - buttonRadius, center.y - buttonRadius),
                     ImVec2(center.x + buttonRadius, center.y + buttonRadius));

        if (IsItemActive() && IsMouseDragging(0)) {
            if (!isDragging) {
                isDragging = true;
                lastDragX = io.MouseDelta.x;
                lastDragY = io.MouseDelta.y;
                dragVelocityX = 0.0f;
                dragVelocityY = 0.0f;
            }
            // Smooth drag with velocity tracking
            float smoothing = 0.6f;
            g_sideBtnsX += io.MouseDelta.x * smoothing + (io.MouseDelta.x - lastDragX) * 0.4f;
            g_sideBtnsY += io.MouseDelta.y * smoothing + (io.MouseDelta.y - lastDragY) * 0.4f;
            dragVelocityX = io.MouseDelta.x / ImMax(io.DeltaTime, 0.001f);
            dragVelocityY = io.MouseDelta.y / ImMax(io.DeltaTime, 0.001f);
            lastDragX = io.MouseDelta.x;
            lastDragY = io.MouseDelta.y;
            g_sideBtnsX = ImClamp(g_sideBtnsX, edgeMargin, io.DisplaySize.x - edgeMargin - maxWinW);
            g_sideBtnsY = ImClamp(g_sideBtnsY, winSize + margin, io.DisplaySize.y - edgeMargin - toggleWinH);
        }

        if (IsItemHovered() && IsMouseReleased(0) && !isDragging)
            g_menu.isOpen = !g_menu.isOpen;

        if (!IsItemActive()) {
            if (isDragging) {
                // Save position when drag ends
                svConfig_Save();
            }
            isDragging = false;
        }
    }
    End();
    PopStyleVar(2);
    PopStyleColor();
}

// ─── Session Persistence — server re-verification on restore ──────────────────
static bool g_session_restored = false;
static bool g_prev_logged_in  = false;
static bool g_session_restoring = false;

static void CheckAndRestoreSession() {
    if (g_session_restored) return;
    g_session_restored = true;
    if (logged_in) return;

    std::string saved_key = persistent_string["key"];
    if (saved_key.empty()) return;

    // ALWAYS re-verify with server — never trust local saved data
    g_session_restoring = true;
    is_logging_in = true;
    ERROR_MESSAGE = "Re-validating license...";

    std::thread([saved_key]() {
        bool ok = LoginWithSavedKey(saved_key);
        if (!ok) {
            // Clear invalid saved session
            persistent_float["session_ts"] = 0.0f;
            persistent_string["key"] = "";
            save_persistence();
        }
        g_session_restoring = false;
        is_logging_in = false;
    }).detach();
}

static void SaveSessionOnLogin() {
    if (logged_in && !g_prev_logged_in) {
        auto now = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now());
        persistent_float["session_ts"] = (float)now;
        if (!g_Token.empty()) persistent_string["key"] = g_Token;
        if (!g_server_exp_raw.empty()) persistent_string["exp_raw"] = g_server_exp_raw;
        if (g_expiry_timestamp > 0) persistent_float["exp_ts"] = (float)g_expiry_timestamp;
        if (g_server_time_offset != 0) persistent_float["time_offset"] = (float)g_server_time_offset;
        save_persistence();
    }
    g_prev_logged_in = logged_in;
}

// ─── Login screen ─────────────────────────────────────────────────────────────
static bool first_time = true;
static std::string login_code = "";
INLINE void DrawLogin(ImGuiIO& io) {
    if (logged_in && !IsExpired()) return DrawMenu(io);

    // ── Full-screen dark overlay ──
    SetNextWindowPos(ImVec2(0, 0));
    SetNextWindowSize(io.DisplaySize);
    PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.005f, 0.01f, 0.02f, 0.98f));
    Begin(O("##Overlay"), nullptr,
          ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove |
          ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoInputs |
          ImGuiWindowFlags_NoBringToFrontOnFocus);
    PopStyleColor();

    // ── Animated tech-grid or ambient tech-glow in background ──
    {
        ImDrawList* bgDl = GetBackgroundDrawList();
        static float g_loginAnimTime = 0.0f;
        g_loginAnimTime += io.DeltaTime;

        // Dynamic Cyan Orbs
        float orb1X = io.DisplaySize.x * 0.25f + sinf(g_loginAnimTime * 0.6f) * 100.0f;
        float orb1Y = io.DisplaySize.y * 0.35f + cosf(g_loginAnimTime * 0.4f) * 80.0f;
        bgDl->AddCircleFilled(ImVec2(orb1X, orb1Y), 250.0f, IM_COL32(0, 150, 255, 12));
        bgDl->AddCircleFilled(ImVec2(orb1X, orb1Y), 150.0f, IM_COL32(0, 255, 255, 8));

        // Dynamic Purple Orbs
        float orb2X = io.DisplaySize.x * 0.75f + cosf(g_loginAnimTime * 0.5f) * 120.0f;
        float orb2Y = io.DisplaySize.y * 0.65f + sinf(g_loginAnimTime * 0.7f) * 90.0f;
        bgDl->AddCircleFilled(ImVec2(orb2X, orb2Y), 220.0f, IM_COL32(124, 58, 237, 10));
        bgDl->AddCircleFilled(ImVec2(orb2X, orb2Y), 130.0f, IM_COL32(167, 139, 250, 6));
    }

    float cardW = 680.0f;
    float cardH = 530.0f;

    SetNextWindowSize(ImVec2(cardW, cardH), ImGuiCond_Always);
    SetNextWindowPos(ImVec2(io.DisplaySize.x * 0.5f, io.DisplaySize.y * 0.5f),
                     ImGuiCond_Always, ImVec2(0.5f, 0.5f));

    PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.0f, 0.0f, 0.0f, 0.0f));
    PushStyleVar(ImGuiStyleVar_WindowRounding,  24.0f);
    PushStyleVar(ImGuiStyleVar_WindowPadding,   ImVec2(0, 0));
    PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);

    Begin(O("##LoginCard"), nullptr,
          ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove |
          ImGuiWindowFlags_NoTitleBar  | ImGuiWindowFlags_NoScrollbar);

    ImDrawList* dl      = GetWindowDrawList();
    ImVec2      wp      = GetWindowPos();

    // ══════════════════════════════════════════════════════════════════════
    // GLASSMORPHISM CARD BACKGROUND
    // ══════════════════════════════════════════════════════════════════════

    // Base dark navy fill
    dl->AddRectFilled(wp, ImVec2(wp.x + cardW, wp.y + cardH),
                      LOGIN_BG_CARD, 24.0f);

    // Glass gradient overlay — top lighter, bottom darker
    dl->AddRectFilledMultiColor(
        wp, ImVec2(wp.x + cardW, wp.y + cardH),
        LOGIN_BG_GLASS_TOP, LOGIN_BG_GLASS_TOP,
        LOGIN_BG_GLASS_BOT, LOGIN_BG_GLASS_BOT
    );

    // Top-left light simulation (glass reflection)
    dl->AddRectFilledMultiColor(
        wp, ImVec2(wp.x + cardW, wp.y + cardH * 0.45f),
        IM_COL32(22, 35, 70, 35), IM_COL32(0, 0, 0, 0),
        IM_COL32(0, 0, 0, 0), IM_COL32(22, 35, 70, 35)
    );

    // ══════════════════════════════════════════════════════════════════════
    // MULTI-LAYERED GLOW BORDER
    // ══════════════════════════════════════════════════════════════════════
    dl->AddRect(wp, ImVec2(wp.x + cardW, wp.y + cardH),
                IM_COL32(124, 58, 237, 18), 28.0f, 0, 8.0f);
    dl->AddRect(wp, ImVec2(wp.x + cardW, wp.y + cardH),
                IM_COL32(41, 121, 255, 28), 26.0f, 0, 5.0f);
    dl->AddRect(wp, ImVec2(wp.x + cardW, wp.y + cardH),
                IM_COL32(0, 229, 255, 45), 25.0f, 0, 2.0f);
    dl->AddRect(wp, ImVec2(wp.x + cardW, wp.y + cardH),
                IM_COL32(0, 229, 255, 70), 24.0f, 0, 1.0f);

    // ══════════════════════════════════════════════════════════════════════
    // TOP ACCENT BAR — Cyan → Electric Blue → Purple gradient
    // ══════════════════════════════════════════════════════════════════════

    // Rounded top cap (cover sharp corners)
    dl->AddRectFilled(wp, ImVec2(wp.x + cardW, wp.y + 24),
                      IM_COL32(0, 0, 0, 0), 24.0f, ImDrawFlags_RoundCornersTop);
    dl->AddRectFilledMultiColor(
        wp, ImVec2(wp.x + cardW, wp.y + 24),
        LOGIN_BG_GLASS_TOP, LOGIN_BG_GLASS_TOP,
        LOGIN_BG_GLASS_BOT, LOGIN_BG_GLASS_BOT
    );

    // Animated accent line with pulsing alpha
    {
        static float g_accentTime = 0.0f;
        g_accentTime += io.DeltaTime;
        int pulse = (int)(180 + 75 * sinf(g_accentTime * 1.2f));

        // Glow layer
        dl->AddRectFilledMultiColor(
            wp, ImVec2(wp.x + cardW, wp.y + 6.0f),
            IM_COL32(0, 229, 255, (int)(pulse * 0.25f)),
            IM_COL32(41, 121, 255, (int)(pulse * 0.25f)),
            IM_COL32(124, 58, 237, (int)(pulse * 0.25f)),
            IM_COL32(0, 229, 255, (int)(pulse * 0.25f))
        );
        // Sharp accent line
        dl->AddRectFilledMultiColor(
            wp, ImVec2(wp.x + cardW, wp.y + 3.0f),
            IM_COL32(0, 229, 255, pulse),
            IM_COL32(41, 121, 255, pulse),
            IM_COL32(124, 58, 237, pulse),
            IM_COL32(0, 229, 255, pulse)
        );
    }

    // ══════════════════════════════════════════════════════════════════════
    // TITLE — "FAN GAMAL FREE V11" with cyan glow
    // ══════════════════════════════════════════════════════════════════════
    {
        SetWindowFontScale(1.5f);
        ImVec2 titleSize = CalcTextSize(O("FAN GAMAL FREE V11"));
        float tx = wp.x + (cardW - titleSize.x) * 0.5f;
        float ty = wp.y + 30.0f;
        // Glow layers
        dl->AddText(ImVec2(tx + 1, ty + 1), IM_COL32(0, 229, 255, 50), O("FAN GAMAL FREE V11"));
        dl->AddText(ImVec2(tx - 1, ty - 1), IM_COL32(124, 58, 237, 35), O("FAN GAMAL FREE V11"));
        // Main title
        dl->AddText(ImVec2(tx, ty), IM_COL32(225, 240, 255, 255), O("FAN GAMAL FREE V11"));
        SetWindowFontScale(1.0f);
    }

    // ── Subtitle decorative dots ──
    {
        ImVec2 subSize = CalcTextSize(O("............................"));
        dl->AddText(ImVec2(wp.x + (cardW - subSize.x) * 0.5f, wp.y + 68),
                    LOGIN_CYAN_NEON, O("............................"));
    }

    // ══════════════════════════════════════════════════════════════════════
    // SEPARATOR — Glowing cyan → purple
    // ══════════════════════════════════════════════════════════════════════
    {
        float sepY = wp.y + 98.0f;
        float sx0  = wp.x + 40.0f;
        float sx1  = wp.x + cardW - 40.0f;
        float mid  = (sx0 + sx1) * 0.5f;
        // Outer glow
        dl->AddLine(ImVec2(sx0, sepY), ImVec2(sx1, sepY), IM_COL32(0, 229, 255, 18), 6.0f);
        dl->AddLine(ImVec2(sx0, sepY), ImVec2(sx1, sepY), IM_COL32(0, 229, 255, 30), 3.0f);
        // Gradient center line
        dl->AddLine(ImVec2(sx0, sepY), ImVec2(mid, sepY), IM_COL32(0, 229, 255, 110), 1.5f);
        dl->AddLine(ImVec2(mid, sepY), ImVec2(sx1, sepY), IM_COL32(124, 58, 237, 110), 1.5f);
    }

    // ══════════════════════════════════════════════════════════════════════
    // ERROR MESSAGE
    // ══════════════════════════════════════════════════════════════════════
    if (!ERROR_MESSAGE.empty()) {
        SetCursorPosY(110.0f);
        SetCursorPosX(40.0f);
        PushTextWrapPos(cardW - 40.0f);
        TextColored(ImVec4(1.0f, 0.55f, 0.55f, 1.0f), "%s", ERROR_MESSAGE.c_str());
        PopTextWrapPos();
    }

    // ══════════════════════════════════════════════════════════════════════
    // LOADING STATE
    // ══════════════════════════════════════════════════════════════════════
    if (is_logging_in) {
        static float spinner_angle = 0.0f;
        spinner_angle += io.DeltaTime * 5.0f;

        float spinner_size  = 42.0f;
        ImVec2 spinnerCenter = ImVec2(wp.x + cardW * 0.5f, wp.y + 220.0f);

        for (int i = 0; i < 12; i++) {
            float angle = spinner_angle + (i * PI * 2.0f / 12.0f);
            float alpha = (float)(12 - i) / 12.0f;
            ImVec2 dotPos = ImVec2(
                spinnerCenter.x + cosf(angle) * spinner_size,
                spinnerCenter.y + sinf(angle) * spinner_size
            );
            int cr = (int)(0   * alpha + 41  * (1.0f - alpha) * alpha);
            int cg = (int)(229 * alpha * 0.8f + 121 * (1.0f - alpha) * alpha);
            int cb = (int)(255 * alpha * 0.6f + 255 * (1.0f - alpha));
            dl->AddCircleFilled(dotPos, 5.5f, IM_COL32(cr, cg, cb, (int)(alpha * 230)));
        }

        SetWindowFontScale(1.1f);
        ImVec2 loadingSize = CalcTextSize(O("Authenticating..."));
        SetCursorPosX((cardW - loadingSize.x) * 0.5f);
        SetCursorPosY(290.0f);
        TextColored(ImVec4(0.0f, 0.9f, 1.0f, 1.0f), O("Authenticating..."));
        SetWindowFontScale(1.0f);

    // ══════════════════════════════════════════════════════════════════════
    // NORMAL STATE — Input + Paste Code + Login
    // ══════════════════════════════════════════════════════════════════════
    } else {
        // ── "LICENSE CODE" label ──
        SetCursorPosY(ERROR_MESSAGE.empty() ? 112.0f : 140.0f);
        SetCursorPosX(44.0f);
        SetWindowFontScale(0.8f);
        TextColored(ImVec4(0.45f, 0.6f, 0.85f, 1.0f), O("LICENSE CODE"));
        SetWindowFontScale(1.0f);

        Dummy(ImVec2(0, 6));

        // ── Glassmorphism Input Field ──
        SetCursorPosX(44.0f);
        float inputW = cardW - 88.0f;
        float inputH = 54.0f;
        ImVec2 inputPos = GetCursorScreenPos();
        ImVec2 inputEnd = ImVec2(inputPos.x + inputW, inputPos.y + inputH);

        // Input background
        dl->AddRectFilled(inputPos, inputEnd, LOGIN_BG_INPUT, 14.0f);
        // Top-left glass highlight
        dl->AddRectFilledMultiColor(
            inputPos, ImVec2(inputEnd.x, inputPos.y + inputH * 0.5f),
            LOGIN_BG_INPUT_HL, IM_COL32(0, 0, 0, 0),
            IM_COL32(0, 0, 0, 0), LOGIN_BG_INPUT_HL
        );
        // Multi-layer border glow
        dl->AddRect(inputPos, inputEnd, IM_COL32(0, 229, 255, 25), 16.0f, 0, 4.0f);
        dl->AddRect(inputPos, inputEnd, IM_COL32(41, 121, 255, 20), 18.0f, 0, 6.0f);
        dl->AddRect(inputPos, inputEnd, IM_COL32(0, 229, 255, 55), 14.0f, 0, 1.0f);

        // Input text content
        SetCursorPos(ImVec2(60.0f, GetCursorPosY() + 2.0f));
        if (login_code.empty()) {
            TextColored(ImVec4(0.22f, 0.29f, 0.43f, 0.7f), O("Press 'Paste Code' to insert..."));
        } else {
            std::string display = login_code;
            if (display.length() > 36) {
                display = display.substr(0, 16) + "..." + display.substr(display.length() - 16);
            }
            TextColored(ImVec4(0.0f, 0.9f, 1.0f, 1.0f), "%s", display.c_str());
        }

        // Move cursor past the input field
        SetCursorPosY(inputPos.y - wp.y + inputH + 16.0f);

        // ── Button Row: Paste Code + Login ──
        float btnW = (cardW - 88.0f - 16.0f) * 0.5f;
        float btnH = 62.0f;
        SetCursorPosX(44.0f);

        static float g_btnTime = 0.0f;
        g_btnTime += io.DeltaTime;

        // ── PASTE CODE button ──
        {
            float pulse = (sinf(g_btnTime * 2.0f) * 0.5f + 0.5f) * 0.3f + 0.7f;

            PushStyleColor(ImGuiCol_Button,       ImVec4(0.0f, 0.15f * pulse, 0.25f * pulse, 1.0f));
            PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.0f, 0.35f, 0.50f, 1.0f));
            PushStyleColor(ImGuiCol_ButtonActive,  ImVec4(0.0f, 0.20f, 0.30f, 1.0f));
            PushStyleColor(ImGuiCol_Text,         ImVec4(0.0f, 1.0f, 1.0f, 1.0f));
            PushStyleVar(ImGuiStyleVar_FrameRounding, 16.0f);

            if (Button(O("PASTE CODE"), ImVec2(btnW, btnH))) {
                JNIEnv* env;
                jint getEnvResult = VM->GetEnv((void**)&env, JNI_VERSION_1_6);
                if (getEnvResult == JNI_EDETACHED) {
                    VM->AttachCurrentThread(&env, nullptr);
                }
                if (env) {
                    login_code = getClipboard(env);
                    if (login_code.empty()) {
                        ERROR_MESSAGE = O("Clipboard is empty — copy your code first");
                    }
                }
            }

            // Cyan neon glow border on Paste button
            ImVec2 pp = GetItemRectMin(), pq = GetItemRectMax();
            dl->AddRect(pp, pq, IM_COL32(0, 255, 255, (int)(100 + pulse * 100)), 16.0f, 0, 2.5f);
            dl->AddRect(ImVec2(pp.x - 2, pp.y - 2), ImVec2(pq.x + 2, pq.y + 2),
                        IM_COL32(0, 255, 255, (int)(pulse * 50)), 18.0f, 0, 5.0f);

            PopStyleVar();
            PopStyleColor(4);
        }

        SameLine(0.0f, 16.0f);

        // ── LOGIN button ──
        {
            float pulse = (sinf(g_btnTime * 2.5f) * 0.5f + 0.5f) * 0.35f + 0.65f;

        PushStyleColor(ImGuiCol_Button,       ImVec4(0.05f * pulse, 0.20f * pulse, 0.40f * pulse, 1.0f));
            PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.10f, 0.40f, 0.80f, 1.0f));
            PushStyleColor(ImGuiCol_ButtonActive,  ImVec4(0.05f, 0.25f, 0.50f, 1.0f));
            PushStyleColor(ImGuiCol_Text,         ImVec4(0.95f, 1.0f, 1.0f, 1.0f));
            PushStyleVar(ImGuiStyleVar_FrameRounding, 16.0f);

            bool doLogin = false;
            if (Button(O("LOGIN"), ImVec2(btnW, btnH))) {
                if (login_code.empty()) {
                    // Fallback: try clipboard directly
                    JNIEnv* env;
                    jint getEnvResult = VM->GetEnv((void**)&env, JNI_VERSION_1_6);
                    if (getEnvResult == JNI_EDETACHED) {
                        VM->AttachCurrentThread(&env, nullptr);
                    }
                    if (env) {
                        login_code = getClipboard(env);
                    }
                    if (login_code.empty()) {
                        ERROR_MESSAGE = O("No code found — paste your code first");
                    } else {
                        doLogin = true;
                    }
                } else {
                    doLogin = true;
                }
            }

            // Electric blue + purple gradient glow border on Login button
            ImVec2 lp = GetItemRectMin(), lq = GetItemRectMax();
            dl->AddRect(lp, lq, IM_COL32(0, 150, 255, (int)(110 + pulse * 110)), 16.0f, 0, 2.5f);
            dl->AddRect(ImVec2(lp.x - 2, lp.y - 2), ImVec2(lq.x + 2, lq.y + 2),
                        IM_COL32(160, 80, 255, (int)(pulse * 60)), 18.0f, 0, 5.0f);
            // Animated corner accents
            float cLen = 22.0f;
            dl->AddLine(lp, ImVec2(lp.x + cLen, lp.y), IM_COL32(0, 255, 255, (int)(pulse * 200)), 3.0f);
            dl->AddLine(lp, ImVec2(lp.x, lp.y + cLen), IM_COL32(0, 255, 255, (int)(pulse * 200)), 3.0f);
            dl->AddLine(lq, ImVec2(lq.x - cLen, lq.y), IM_COL32(180, 120, 255, (int)(pulse * 200)), 3.0f);
            dl->AddLine(lq, ImVec2(lq.x, lq.y - cLen), IM_COL32(180, 120, 255, (int)(pulse * 200)), 3.0f);

            PopStyleVar();
            PopStyleColor(4);

            // Execute login in background thread
            if (doLogin) {
                std::string codeToUse = login_code;
                JNIEnv* env2;
                jint r2 = VM->GetEnv((void**)&env2, JNI_VERSION_1_6);
                if (r2 == JNI_EDETACHED) {
                    if (VM->AttachCurrentThread(&env2, nullptr) != 0)
                        ERROR_MESSAGE = O("Failed to attach thread to JVM");
                } else if (r2 != JNI_OK) {
                    ERROR_MESSAGE = O("Failed to get JNIEnv");
                } else {
                    std::string androidId = getAndroidID(env2);
                    std::thread([=](std::string aid, std::string key) {
                        Login(aid, key);
                    }, androidId, codeToUse).detach();
                }
                first_time = false;
            }
        }

        // ── Bottom: "To buy a key TG:-@FG_4Q" ──
        Dummy(ImVec2(0, 28));
        ImVec2 helpSize = CalcTextSize(O("To buy a key TG:-@FG_4Q"));
        SetCursorPosX((cardW - helpSize.x) * 0.5f);
        TextColored(ImVec4(0.4f, 0.5f, 0.7f, 1.0f), O("To buy a key TG:-@FG_4Q"));
    }

    End();
    PopStyleVar(3);
    PopStyleColor();

    End();
}

// ─── ImGui setup ──────────────────────────────────────────────────────────────
INLINE void SetupImgui() {
    PACKAGE_NAME = string(getcmdline());

    ImGui::CreateContext();

    auto& style = ImGui::GetStyle();
    auto& io    = ImGui::GetIO();

    io.ConfigFlags |= ImGuiConfigFlags_IsTouchScreen;

    switch_theme(current_theme);

    load_persistence();
    svConfig_Load();
    load_imgui_style();

    static string INI_PATH = O("/data/user_de/0/") + PACKAGE_NAME + O("/no_backup/.ini");
    io.IniFilename = persistent_bool["bImguiAutoSave"] ? INI_PATH.c_str() : nullptr;
    io.ConfigWindowsMoveFromTitleBarOnly = persistent_bool["bMoveOnlyWithTitleBar"];

    ImFontConfig font_cfg;
    font_cfg.SizePixels = persistent_float["fFontScale"];
    font_cfg.OversampleH = 2;
    font_cfg.OversampleV = 2;
    io.Fonts->AddFontFromMemoryTTF((void*)arial_bold_italic, arial_bold_italic_size, font_cfg.SizePixels, &font_cfg);
    io.Fonts->Build();

    ImGui_ImplAndroid_Init();
    ImGui_ImplOpenGL3_Init(O("#version 300 es"));

    bImguiSetup = true;
}

DEFINES(EGLBoolean, Draw, EGLDisplay dpy, EGLSurface surface) {
    eglQuerySurface(dpy, surface, EGL_WIDTH,  &Width);
    eglQuerySurface(dpy, surface, EGL_HEIGHT, &Height);

    if (Width <= 0 || Height <= 0) return _Draw(dpy, surface);

    screenCenter = Vector2(Width / 2, Height / 2);

    if (!bImguiSetup) SetupImgui();

    ImGuiIO& io = ImGui::GetIO();

    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplAndroid_NewFrame(Width, Height);
    ImGui::NewFrame();

    if (!is_segv_handler_active()) setup_global_segv_handler();

    // ── Session: restore on startup, save on login ──
    CheckAndRestoreSession();
    SaveSessionOnLogin();

    // ── Real-time expiry check: if expired or revoked, force back to login ──
    if (logged_in && IsExpired()) {
        logged_in = false;
        bValid = false;
        g_Token = "";
        g_Auth = "";
        persistent_string["key"] = "";
        persistent_float["session_ts"] = 0.0f;
        save_persistence();
        ERROR_MESSAGE = g_key_revoked.load() ? "License key has been disabled by server" : "License key has expired";
    }

    // ── Periodic server re-validation ──
    if (logged_in && !g_Token.empty()) {
        static std::string s_last_validated_key = "";
        if (s_last_validated_key != g_Token) {
            s_last_validated_key = g_Token;
        }
        // Get Android ID for re-validation (cached)
        static std::string s_cached_android_id = "";
        if (s_cached_android_id.empty()) {
            JNIEnv* envTmp = GetJNIEnv();
            if (envTmp) s_cached_android_id = getAndroidID(envTmp);
        }
        maybeRevalidateKey(g_Token, s_cached_android_id);
    }

    if (IsExpired()) {
        DrawExpired(io);
    } else if (!g_Token.empty() && !g_Auth.empty() && g_Token == g_Auth) {
        DrawFloatingButton(io);
        DrawMenu(io);
        // "TG:-@FG_4Q" — fixed center-bottom watermark with changing colors
        {
            static float g_tgAnimTime = 0.0f;
            g_tgAnimTime += io.DeltaTime;

            // ألوان متغيرة سريعة وواضحة (قوس قزح)
            float hueShift = g_tgAnimTime * 0.3f;
            float r  = 0.5f + 0.5f * cosf(hueShift);
            float g2 = 0.5f + 0.5f * cosf(hueShift + 2.094f);
            float b  = 0.5f + 0.5f * cosf(hueShift + 4.189f);

            // نبض خفيف للظهور بشكل مميز
            float alpha = 0.85f + 0.15f * sinf(g_tgAnimTime * 1.5f);

            ImU32 textColor  = IM_COL32((int)(r * 255), (int)(g2 * 255), (int)(b * 255), (int)(alpha * 255));
            ImU32 glowColor1 = IM_COL32((int)(r * 255), (int)(g2 * 255), (int)(b * 255), (int)(alpha * 0.6f * 140));
            ImU32 glowColor2 = IM_COL32((int)(r * 255), (int)(g2 * 255), (int)(b * 255), (int)(alpha * 0.4f * 100));
            ImU32 glowColor3 = IM_COL32((int)(r * 255), (int)(g2 * 255), (int)(b * 255), (int)(alpha * 0.2f * 60));

            // ثابت في منتصف الشاشة بالأسفل
            float textWidth = CalcTextSize(O("TG:-@FG_4Q")).x;
            float xPos = ((float)Width - textWidth) * 0.5f;
            float yPos = (float)Height - 55.0f;

            SetNextWindowPos(ImVec2(xPos, yPos), ImGuiCond_Always, ImVec2(0.0f, 0.0f));

            Begin(O("##PoweredBy"), nullptr,
                  ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
                  ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoScrollbar |
                  ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_AlwaysAutoResize |
                  ImGuiWindowFlags_NoInputs);

            ImDrawList* dl2 = GetWindowDrawList();
            ImVec2 textPos  = GetCursorScreenPos();

            // توهج قوي وظاهر (4 طبقات)
            dl2->AddText(ImVec2(textPos.x + 2, textPos.y + 2), glowColor1, O("TG:-@FG_4Q"));
            dl2->AddText(ImVec2(textPos.x - 2, textPos.y - 2), glowColor1, O("TG:-@FG_4Q"));
            dl2->AddText(ImVec2(textPos.x + 1, textPos.y - 1), glowColor2, O("TG:-@FG_4Q"));
            dl2->AddText(ImVec2(textPos.x - 1, textPos.y + 1), glowColor2, O("TG:-@FG_4Q"));
            dl2->AddText(ImVec2(textPos.x + 3, textPos.y),     glowColor3, O("TG:-@FG_4Q"));
            dl2->AddText(ImVec2(textPos.x - 3, textPos.y),     glowColor3, O("TG:-@FG_4Q"));

            TextColored(ImVec4(r, g2, b, alpha), O("TG:-@FG_4Q"));

            End();
        }

        if (g_autoPlayCalculating) DrawCalculating(io);
    } else {
        DrawLogin(io);
    }

    ImGui::EndFrame();
    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    ImGui_ClearHoverEffect();

    return _Draw(dpy, surface);
}

void __IMGUI__() {
    create_directory_recursive(CONC(O("/data/user_de/0/"), PACKAGE_NAME.c_str(), O("/no_backup")));
}