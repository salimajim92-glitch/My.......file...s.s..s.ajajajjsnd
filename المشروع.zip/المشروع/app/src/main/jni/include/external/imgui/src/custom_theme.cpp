#include "imgui.h"

void StyleColorsCustom(ImGuiStyle* _style) {
    ImGuiStyle& style = _style ? *_style : ImGui::GetStyle();

    // ── Metrics (premium spacious) ────────────────────────────────────────────
    style.WindowPadding        = ImVec2(10.0f,  8.0f);
    style.FramePadding         = ImVec2(12.0f,  7.0f);
    style.ItemSpacing          = ImVec2(12.0f,  8.0f);
    style.ItemInnerSpacing     = ImVec2(10.0f,  7.0f);
    style.TouchExtraPadding    = ImVec2(8.0f,   8.0f);
    style.IndentSpacing        = 16.0f;
    style.ScrollbarSize        = 12.0f;
    style.GrabMinSize          = 14.0f;

    // ── Rounding (modern smooth) ──────────────────────────────────────────────
    style.WindowRounding       = 16.0f;
    style.ChildRounding        = 12.0f;
    style.FrameRounding        = 10.0f;
    style.PopupRounding        = 10.0f;
    style.ScrollbarRounding    = 8.0f;
    style.GrabRounding         = 10.0f;
    style.TabRounding          = 8.0f;

    // ── Borders ────────────────────────────────────────────────────────────
    style.WindowBorderSize     = 0.0f;
    style.ChildBorderSize      = 1.0f;
    style.PopupBorderSize      = 1.0f;
    style.FrameBorderSize      = 0.0f;
    style.TabBorderSize        = 0.0f;

    // ── Color palette: Sapphire & Amethyst VIP ──────────────────────────────
    ImVec4* c = style.Colors;

    // Base text — clean white
    c[ImGuiCol_Text]                  = ImVec4(0.94f, 0.96f, 0.98f, 1.00f);
    c[ImGuiCol_TextDisabled]          = ImVec4(0.50f, 0.55f, 0.65f, 1.00f);

    // Window / panel backgrounds — deep midnight indigo
    c[ImGuiCol_WindowBg]              = ImVec4(0.03f, 0.03f, 0.07f, 1.00f);
    c[ImGuiCol_ChildBg]               = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
    c[ImGuiCol_PopupBg]               = ImVec4(0.05f, 0.05f, 0.10f, 0.97f);

    // Borders — violet accent
    c[ImGuiCol_Border]                = ImVec4(0.55f, 0.36f, 0.97f, 0.47f);
    c[ImGuiCol_BorderShadow]          = ImVec4(0.65f, 0.55f, 0.98f, 0.12f);

    // Frame backgrounds — dark indigo
    c[ImGuiCol_FrameBg]               = ImVec4(0.07f, 0.07f, 0.14f, 1.00f);
    c[ImGuiCol_FrameBgHovered]        = ImVec4(0.12f, 0.10f, 0.22f, 1.00f);
    c[ImGuiCol_FrameBgActive]         = ImVec4(0.18f, 0.14f, 0.32f, 1.00f);

    // Title bar
    c[ImGuiCol_TitleBg]               = ImVec4(0.05f, 0.04f, 0.10f, 1.00f);
    c[ImGuiCol_TitleBgActive]         = ImVec4(0.08f, 0.06f, 0.16f, 1.00f);
    c[ImGuiCol_TitleBgCollapsed]      = ImVec4(0.05f, 0.04f, 0.10f, 0.80f);

    // Menu bar
    c[ImGuiCol_MenuBarBg]             = ImVec4(0.05f, 0.04f, 0.10f, 1.00f);

    // Scrollbar — violet accent
    c[ImGuiCol_ScrollbarBg]           = ImVec4(0.04f, 0.04f, 0.08f, 0.60f);
    c[ImGuiCol_ScrollbarGrab]         = ImVec4(0.55f, 0.36f, 0.97f, 1.00f);
    c[ImGuiCol_ScrollbarGrabHovered]  = ImVec4(0.65f, 0.55f, 0.98f, 1.00f);
    c[ImGuiCol_ScrollbarGrabActive]   = ImVec4(0.75f, 0.70f, 1.00f, 1.00f);

    // Widgets — violet accent
    c[ImGuiCol_CheckMark]             = ImVec4(0.65f, 0.55f, 0.98f, 1.00f);
    c[ImGuiCol_SliderGrab]            = ImVec4(0.55f, 0.36f, 0.97f, 1.00f);
    c[ImGuiCol_SliderGrabActive]      = ImVec4(0.75f, 0.70f, 1.00f, 1.00f);

    // Buttons — dark indigo base, violet on hover
    c[ImGuiCol_Button]                = ImVec4(0.08f, 0.06f, 0.16f, 1.00f);
    c[ImGuiCol_ButtonHovered]         = ImVec4(0.16f, 0.12f, 0.32f, 1.00f);
    c[ImGuiCol_ButtonActive]          = ImVec4(0.22f, 0.16f, 0.40f, 1.00f);

    // Headers
    c[ImGuiCol_Header]                = ImVec4(0.08f, 0.06f, 0.16f, 1.00f);
    c[ImGuiCol_HeaderHovered]         = ImVec4(0.16f, 0.12f, 0.32f, 1.00f);
    c[ImGuiCol_HeaderActive]          = ImVec4(0.22f, 0.18f, 0.42f, 1.00f);

    // Separators — subtle violet
    c[ImGuiCol_Separator]             = ImVec4(0.20f, 0.18f, 0.40f, 0.60f);
    c[ImGuiCol_SeparatorHovered]      = ImVec4(0.55f, 0.36f, 0.97f, 0.80f);
    c[ImGuiCol_SeparatorActive]       = ImVec4(0.75f, 0.70f, 1.00f, 1.00f);

    // Resize grips
    c[ImGuiCol_ResizeGrip]            = ImVec4(0.55f, 0.36f, 0.97f, 0.20f);
    c[ImGuiCol_ResizeGripHovered]     = ImVec4(0.55f, 0.36f, 0.97f, 0.67f);
    c[ImGuiCol_ResizeGripActive]      = ImVec4(0.75f, 0.70f, 1.00f, 0.95f);

    // Tabs
    c[ImGuiCol_Tab]                   = ImVec4(0.05f, 0.05f, 0.12f, 1.00f);
    c[ImGuiCol_TabHovered]            = ImVec4(0.14f, 0.10f, 0.26f, 1.00f);
    c[ImGuiCol_TabSelected]           = ImVec4(0.20f, 0.16f, 0.36f, 1.00f);
    c[ImGuiCol_TabDimmed]             = ImVec4(0.04f, 0.04f, 0.10f, 1.00f);
    c[ImGuiCol_TabDimmedSelected]     = ImVec4(0.10f, 0.08f, 0.20f, 1.00f);

    // Docking
    c[ImGuiCol_DockingPreview]        = ImVec4(0.55f, 0.36f, 0.97f, 0.70f);
    c[ImGuiCol_DockingEmptyBg]        = ImVec4(0.04f, 0.04f, 0.08f, 1.00f);

    // Plots
    c[ImGuiCol_PlotLines]             = ImVec4(0.75f, 0.70f, 1.00f, 1.00f);
    c[ImGuiCol_PlotLinesHovered]      = ImVec4(0.55f, 0.36f, 0.97f, 1.00f);
    c[ImGuiCol_PlotHistogram]         = ImVec4(0.55f, 0.36f, 0.97f, 1.00f);
    c[ImGuiCol_PlotHistogramHovered]  = ImVec4(0.75f, 0.70f, 1.00f, 1.00f);

    // Tables
    c[ImGuiCol_TableHeaderBg]         = ImVec4(0.05f, 0.05f, 0.12f, 1.00f);
    c[ImGuiCol_TableBorderStrong]     = ImVec4(0.14f, 0.10f, 0.26f, 0.70f);
    c[ImGuiCol_TableBorderLight]      = ImVec4(0.08f, 0.06f, 0.16f, 0.40f);
    c[ImGuiCol_TableRowBg]            = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
    c[ImGuiCol_TableRowBgAlt]         = ImVec4(0.55f, 0.36f, 0.97f, 0.02f);

    // Misc
    c[ImGuiCol_TextSelectedBg]        = ImVec4(0.55f, 0.36f, 0.97f, 0.35f);
    c[ImGuiCol_DragDropTarget]        = ImVec4(0.55f, 0.36f, 0.97f, 0.90f);
    c[ImGuiCol_NavHighlight]          = ImVec4(0.55f, 0.36f, 0.97f, 1.00f);
    c[ImGuiCol_NavWindowingHighlight] = ImVec4(0.55f, 0.36f, 0.97f, 0.70f);
    c[ImGuiCol_NavWindowingDimBg]     = ImVec4(0.08f, 0.06f, 0.16f, 0.20f);
    c[ImGuiCol_ModalWindowDimBg]      = ImVec4(0.02f, 0.02f, 0.05f, 0.69f);
}