#pragma once

// Only include custom_theme.h which already includes imgui.h
#include "inc/custom_theme.h"

void StyleColorsCustom(ImGuiStyle* _style) {
    ImGuiStyle& style = _style ? *_style : ImGui::GetStyle();

    // ── Metrics (premium spacious) ────────────────────────────────────────────
    style.WindowPadding     = ImVec2(10.0f, 8.0f);
    style.FramePadding      = ImVec2(12.0f, 7.0f);
    style.ItemSpacing       = ImVec2(12.0f, 8.0f);
    style.ItemInnerSpacing  = ImVec2(10.0f, 7.0f);
    style.IndentSpacing     = 16.0f;
    style.ScrollbarSize     = 12.0f;
    style.GrabMinSize       = 14.0f;

    // ── Rounding (modern smooth) ──────────────────────────────────────────────
    style.WindowRounding    = 16.0f;
    style.FrameRounding     = 10.0f;
    style.ScrollbarRounding = 8.0f;
    style.GrabRounding      = 10.0f;
    style.TabRounding       = 8.0f;
    style.TabBorderSize     = 0.0f;
    style.ChildRounding     = 12.0f;
    style.PopupRounding     = 10.0f;

    // ── Core Colors — Neon Cyan / Obsidian / Tech Blue ─────────────────────
    style.Colors[ImGuiCol_Text]                  = ImColor(240, 248, 255);
    style.Colors[ImGuiCol_TextDisabled]          = ImColor(100, 120, 150);
    style.Colors[ImGuiCol_WindowBg]              = ImColor(4, 8, 16, 250);
    style.Colors[ImGuiCol_ChildBg]               = ImColor(0, 0, 0, 0);
    style.Colors[ImGuiCol_PopupBg]               = ImColor(8, 12, 24, 245);
    style.Colors[ImGuiCol_Border]                = ImColor(0, 255, 255, 100);
    style.Colors[ImGuiCol_BorderShadow]          = ImColor(0, 150, 255, 20);
    style.Colors[ImGuiCol_FrameBg]               = ImColor(12, 20, 40);
    style.Colors[ImGuiCol_FrameBgHovered]        = ImColor(20, 35, 70);
    style.Colors[ImGuiCol_FrameBgActive]         = ImColor(30, 50, 100);

    // ── Title Bar ────────────────────────────────────────────────────────────
    style.Colors[ImGuiCol_TitleBg]               = ImColor(6, 10, 20);
    style.Colors[ImGuiCol_TitleBgActive]         = ImColor(10, 18, 36);
    style.Colors[ImGuiCol_TitleBgCollapsed]      = ImColor(4, 8, 16, 180);

    // ── Menu Bar ────────────────────────────────────────────────────────────
    style.Colors[ImGuiCol_MenuBarBg]             = ImColor(8, 14, 28);

    // ── Scrollbar ──────────────────────────────────────────────────────────
    style.Colors[ImGuiCol_ScrollbarBg]           = ImColor(4, 6, 12);
    style.Colors[ImGuiCol_ScrollbarGrab]         = ImColor(0, 180, 255);
    style.Colors[ImGuiCol_ScrollbarGrabHovered]  = ImColor(0, 220, 255);
    style.Colors[ImGuiCol_ScrollbarGrabActive]   = ImColor(0, 255, 255);

    // ── Check Mark ─────────────────────────────────────────────────────────
    style.Colors[ImGuiCol_CheckMark]             = ImColor(0, 255, 255);

    // ── Sliders ────────────────────────────────────────────────────────────
    style.Colors[ImGuiCol_SliderGrab]            = ImColor(0, 180, 255);
    style.Colors[ImGuiCol_SliderGrabActive]      = ImColor(0, 255, 255);

    // ── Buttons ────────────────────────────────────────────────────────────
    style.Colors[ImGuiCol_Button]                = ImColor(15, 30, 60);
    style.Colors[ImGuiCol_ButtonHovered]         = ImColor(25, 50, 100);
    style.Colors[ImGuiCol_ButtonActive]          = ImColor(40, 80, 160);

    // ── Header / Selectable ─────────────────────────────────────────────────
    style.Colors[ImGuiCol_Header]                = ImColor(20, 40, 80);
    style.Colors[ImGuiCol_HeaderHovered]         = ImColor(30, 60, 120);
    style.Colors[ImGuiCol_HeaderActive]          = ImColor(40, 80, 160);

    // ── Tabs ──────────────────────────────────────────────────────────────
    style.Colors[ImGuiCol_Tab]                   = ImColor(10, 20, 40);
    style.Colors[ImGuiCol_TabHovered]            = ImColor(25, 50, 100);
    style.Colors[ImGuiCol_TabActive]             = ImColor(40, 80, 160);
    style.Colors[ImGuiCol_TabUnfocused]           = ImColor(8, 15, 30);
    style.Colors[ImGuiCol_TabUnfocusedActive]     = ImColor(15, 30, 60);

    // ── Resize Grip ───────────────────────────────────────────────────────
    style.Colors[ImGuiCol_ResizeGrip]            = ImColor(0, 255, 255, 50);
    style.Colors[ImGuiCol_ResizeGripHovered]     = ImColor(0, 255, 255, 170);
    style.Colors[ImGuiCol_ResizeGripActive]      = ImColor(0, 255, 255, 240);

    // ── Plots ──────────────────────────────────────────────────────────────
    style.Colors[ImGuiCol_PlotLines]             = ImColor(0, 255, 255);
    style.Colors[ImGuiCol_PlotLinesHovered]      = ImColor(0, 255, 255);
    style.Colors[ImGuiCol_PlotHistogram]         = ImColor(0, 180, 255);
    style.Colors[ImGuiCol_PlotHistogramHovered]  = ImColor(0, 255, 255);

    // ── Text Selection ──────────────────────────────────────────────────────
    style.Colors[ImGuiCol_TextSelectedBg]        = ImColor(0, 255, 255, 80);

    // ── Modal / Tooltip ───────────────────────────────────────────────────
    style.Colors[ImGuiCol_ModalWindowDimBg]      = ImColor(2, 4, 8, 180);
}