#pragma once

#include "Prediction.fast.h"
#include <imgui/imgui.h>
#include <algorithm>
#include "ScreenTable.h"
#include "mod/ButtonClicker.h"

using namespace ImGui;

constexpr double maxAngle = 360.0 / (180.0 / M_PI);

double normalizeAngle(double angle) {
    double newAngle = angle;
    while (newAngle >= maxAngle) newAngle -= maxAngle;
    while (newAngle < 0.0) newAngle += maxAngle;
    return newAngle;
}

Candidate g_CurrentCandidate = { -1 };

ImVec2 GetPocketScreenPos(int pocketIdx) {
    Table table = sharedGameManager.mTable;
    if (!table) return {};

    auto tableProperties = table.mTableProperties();
    if (!tableProperties) return {};

    auto& pockets = tableProperties.mPockets();
    return WorldToScreen(pockets[pocketIdx]);
}

// ── التحقق: هل جميع كرات مجموعة اللاعب قد دخلت الجيب؟ ──
bool AllGroupBallsPocketed() {
    Ball::Classification myclass = sharedGameManager.getPlayerClassification();
    if (myclass == Ball::Classification::ANY) return false;
    if (myclass == Ball::Classification::EIGHT_BALL) return true;

    for (int i = 1; i < gPrediction->guiData.ballsCount; i++) {
        auto& ball = gPrediction->guiData.balls[i];
        if (ball.classification == myclass && ball.originalOnTable && ball.onTable) {
            return false;
        }
    }
    return true;
}

// ── التحقق: هل يُسمح باستهداف كرة معينة؟ (تمنع كرة 8 قبل الأوان) ──
bool CanTargetBall(int ballIdx) {
    auto& ball = gPrediction->guiData.balls[ballIdx];
    Ball::Classification myclass = sharedGameManager.getPlayerClassification();

    if (ball.classification == Ball::Classification::EIGHT_BALL) {
        if (myclass == Ball::Classification::EIGHT_BALL && AllGroupBallsPocketed()) {
            return true;
        }
        return false;
    }

    if (ball.classification == Ball::Classification::CUE_BALL) return false;

    if (myclass == Ball::Classification::ANY) {
        return (ball.classification != Ball::Classification::EIGHT_BALL);
    }

    if (myclass == Ball::Classification::NINE_BALL_RULE) {
        return true;
    }

    return (ball.classification == myclass);
}

bool IsShotValid() {
    auto& cand = g_CurrentCandidate;
    if (cand.idx == -1) return false;

    Ball::Classification myclass = sharedGameManager.getPlayerClassification();
    uint nominatedPocket = sharedGameManager.getNominatedPocket();
    if (nominatedPocket < 6 && cand.pocketIndex != nominatedPocket) return false;

    if (!gPrediction->guiData.balls[0].onTable) return false;
    if (!gPrediction->guiData.balls[cand.idx].originalOnTable) return false;
    if (gPrediction->guiData.balls[cand.idx].onTable) return false;
    if (gPrediction->guiData.balls[cand.idx].pocketIndex != cand.pocketIndex) return false;

    auto& targetBall = gPrediction->guiData.balls[cand.idx];
    if (targetBall.classification == Ball::Classification::EIGHT_BALL) {
        if (myclass != Ball::Classification::EIGHT_BALL || !AllGroupBallsPocketed()) {
            return false;
        }
    }

    auto& ball8 = gPrediction->guiData.balls[8];
    if (myclass == Ball::Classification::ANY && ball8.originalOnTable && !ball8.onTable) return false;

    auto& firstHit = gPrediction->guiData.collision.firstHitBall;
    if (firstHit) {
        if (myclass == Ball::Classification::ANY) {
            if (firstHit->classification == Ball::Classification::EIGHT_BALL) return false;
        } else if (firstHit->classification != myclass) return false;

        if (firstHit->classification == Ball::Classification::EIGHT_BALL) {
            if (myclass != Ball::Classification::EIGHT_BALL || !AllGroupBallsPocketed()) {
                return false;
            }
        }
    }

    return true;
}

Point2D lastFailedCuePos = { -1000.0, -1000.0 };

namespace AutoPlay {
    double lastSetAngle = 0.f;
    bool didSetAngle = false;
    bool bAutoPlaying = false;

    enum State {
        IDLE,
        SCANNING,
        NOMINATING,
        EXECUTING,
    } state = IDLE;
    
    double pendingShotPower = 0.f;
    double pendingShotAngle = 0.f;
    int nominationFrameCounter = 0;
    
    enum ScanMode {
        FAST,
        SLOW,
    } scan = FAST;

    // ── Human-like cue movement system ──────────────────────────────────────
    // Simulates natural player behavior: scan → aim gradually → react delay → shoot
    namespace HumanCue {
        enum Phase {
            IDLE_PHASE,
            APPROACHING,   // cue moving from previous angle toward target
            HOVER,         // small oscillation near target (player "thinking")
            REACTION_WAIT, // brief pause before shooting (reaction time)
            READY_TO_SHOOT
        } phase = IDLE_PHASE;

        double targetAngle  = 0.0;
        double currentAngle = 0.0;
        double approachSpeed = 0.0;  // radians per frame
        double hoverAmplitude = 0.0; // small oscillation range
        double hoverFrequency = 0.0;
        double hoverTimer    = 0.0;
        int    reactionFrames = 0;   // frames to wait before shooting
        int    reactionCounter = 0;
        double pendingPower  = 0.0;
        double hoverDuration = 0.0;  // how many frames to hover
        double hoverElapsed  = 0.0;

        // Seed randomness per shot so each shot feels different
        static uint32_t rngState = 12345;
        static float NextRand() {
            rngState ^= rngState << 13;
            rngState ^= rngState >> 17;
            rngState ^= rngState << 5;
            return (float)(rngState & 0xFFFF) / 65535.0f; // 0..1
        }

        void Reset() {
            phase = IDLE_PHASE;
            targetAngle = currentAngle = 0.0;
            hoverTimer = hoverElapsed = 0.0;
            reactionCounter = 0;
        }

        // Called once when a shot is found — starts the human-like approach
        void BeginApproach(double aimAngle, double power) {
            targetAngle  = aimAngle;
            pendingPower = power;

            currentAngle = sharedGameManager.mVisualCue().mVisualGuide().mAimAngle();

            double diff = targetAngle - currentAngle;
            while (diff >  M_PI) diff -= 2.0 * M_PI;
            while (diff < -M_PI) diff += 2.0 * M_PI;
            double dist = std::abs(diff);

            // تعديل السرعة لتكون متوسطة وطبيعية
            float r = NextRand();
            double targetFrames = 12.0 + r * 15.0;  // 12-27 frames (متوسطة)
            approachSpeed = dist / targetFrames;
            if (approachSpeed < 0.006) approachSpeed = 0.006;

            // Hover parameters: tiny oscillation while "lining up"
            hoverAmplitude = 0.004 + NextRand() * 0.008; // 0.004–0.012 rad wobble
            hoverFrequency = 0.15 + NextRand() * 0.10;   // oscillation speed
            hoverDuration  = 8.0 + NextRand() * 12.0;    // 8–20 frames of hover
            hoverElapsed   = 0.0;
            hoverTimer     = 0.0;

            // Reaction time: 12–28 frames after hover before shooting
            reactionFrames  = (int)(12.0 + NextRand() * 16.0);
            reactionCounter = 0;

            phase = APPROACHING;
        }

        // Returns true when it's time to fire the shot
        bool Update() {
            if (phase == IDLE_PHASE) return false;

            if (phase == APPROACHING) {
                double diff = targetAngle - currentAngle;
                while (diff >  M_PI) diff -= 2.0 * M_PI;
                while (diff < -M_PI) diff += 2.0 * M_PI;

                if (std::abs(diff) <= approachSpeed + 1e-6) {
                    // Arrived at target
                    currentAngle = targetAngle;
                    sharedGameManager.mVisualCue().mVisualGuide().mAimAngle(currentAngle);
                    phase = HOVER;
                    hoverElapsed = 0.0;
                } else {
                    // Move toward target
                    double step = approachSpeed * (diff > 0 ? 1.0 : -1.0);
                    currentAngle += step;
                    sharedGameManager.mVisualCue().mVisualGuide().mAimAngle(currentAngle);
                }
                return false;
            }

            if (phase == HOVER) {
                hoverElapsed += 1.0;
                hoverTimer   += hoverFrequency;
                // Oscillate slightly around target — decays as we settle
                double decay = 1.0 - (hoverElapsed / hoverDuration);
                if (decay < 0) decay = 0;
                double wobble = std::sin(hoverTimer) * hoverAmplitude * decay;
                sharedGameManager.mVisualCue().mVisualGuide().mAimAngle(targetAngle + wobble);

                if (hoverElapsed >= hoverDuration) {
                    // Settle exactly on target
                    sharedGameManager.mVisualCue().mVisualGuide().mAimAngle(targetAngle);
                    currentAngle = targetAngle;
                    phase = REACTION_WAIT;
                    reactionCounter = 0;
                }
                return false;
            }

            if (phase == REACTION_WAIT) {
                reactionCounter++;
                // Hold perfectly still — player is committed to the shot
                sharedGameManager.mVisualCue().mVisualGuide().mAimAngle(targetAngle);
                if (reactionCounter >= reactionFrames) {
                    phase = READY_TO_SHOOT;
                    return true;  // Fire!
                }
                return false;
            }

            return false;
        }
    };  // namespace HumanCue

    bool shouldAutoPlay() { return !didSetAngle || lastSetAngle == sharedGameManager.mVisualCue().mVisualGuide().mAimAngle(); }

    void setAimAngle(double angle) {
        lastSetAngle = angle;
        sharedGameManager.mVisualCue().mVisualGuide().mAimAngle(angle);
    }

    // ── takeShot: final fire — called after human-like approach completes ──
    void takeShot(double angle, double power) {
        setAimAngle(angle);
        gPrediction->determineShotResult(false, angle, power);
        sharedGameManager.mVisualCue().mPower(ShotPowerToPower(power));
        M(void, libmain + 0x2dc0c58, void*)(F(void*, sharedGameManager + 0x3b0));
    }
    
    void ClearState() {
        g_CurrentCandidate.idx = -1;
        lastFailedCuePos = { -1000.0, -1000.0 };
    }

    // ── حساب عدد الكرات التي ستدخل في الجيب في هذه التصويبة ──
    int CountPocketedBalls(Ball::Classification myclass, uint nominatedPocket) {
        int count = 0;
        for (int i = 1; i < gPrediction->guiData.ballsCount; i++) {
            auto& ball = gPrediction->guiData.balls[i];
            if (ball.originalOnTable && !ball.onTable) {
                bool valid = false;
                if (myclass == Ball::Classification::ANY) {
                    if (ball.classification != Ball::Classification::CUE_BALL &&
                        ball.classification != Ball::Classification::EIGHT_BALL)
                        valid = true;
                } else {
                    if (ball.classification == myclass) valid = true;
                }
                if (nominatedPocket < 6 && ball.pocketIndex != nominatedPocket) valid = false;
                if (valid) count++;
            }
        }
        return count;
    }

    // ── كشف ما إذا كانت هذه ضربة كسر (Break Shot) ──
    bool IsBreakShot() {
        int ballsOnTable = 0;
        for (int i = 1; i < gPrediction->guiData.ballsCount; i++) {
            if (gPrediction->guiData.balls[i].originalOnTable) ballsOnTable++;
        }
        return (ballsOnTable >= 14);
    }

    // ── حساب نقاط التصويبة (احترافي) ──
    double ScoreShot(double baseScore, Ball::Classification myclass, uint nominatedPocket, bool isBandShot, int pocketedCount, bool isCombo = false) {
        // تحسين: تقييم أعمق يشمل عدد الكرات ونوع الضربة وتمركز البيضاء
        double score = baseScore - (pocketedCount * 12000.0); 
        
        if (myclass == Ball::Classification::NINE_BALL_RULE) {
            for (int i = 1; i < gPrediction->guiData.ballsCount; i++) {
                if (i == 9 && gPrediction->guiData.balls[i].originalOnTable && !gPrediction->guiData.balls[i].onTable) {
                    score -= 5000000.0; // أولوية مطلقة للكرة 9
                    break;
                }
            }
        }

        if (isBandShot) score -= 10000.0; // تفضيل ضربات الارتداد
        if (isCombo) score += 40.0;

        auto& cueBall = gPrediction->guiData.balls[0];
        if (cueBall.onTable) {
            double distToCenter = sqrt(cueBall.predictedPosition.square());
            score += distToCenter * 2.0;
        } else {
            score += 10000000.0; // عقوبة قصوى لسقوط البيضاء
        }

        return score;
    }

    void Shoot(double angle, double power = 0.f) {
        // ضبط القوة لتكون متوسطة ومثالية (ليست سريعة ولا بطيئة)
        double optimizedPower = std::max(220.0, std::min(480.0, power));
        if (power > 500.0) optimizedPower = 550.0; 

        setAimAngle(angle);
        gPrediction->determineShotResult(false, angle, optimizedPower);

        bool nominating = false;
        int nominationMode = sharedGameManager.getPocketNominationMode();
        auto myclass = sharedGameManager.getPlayerClassification();

        bool needsNomination = false;
        if (nominationMode == 1) {
            needsNomination = (myclass == Ball::Classification::EIGHT_BALL);
        } else if (nominationMode >= 2) {
            needsNomination = true;
        }

        if (needsNomination && g_CurrentCandidate.idx != -1) {
            uint currentNominated = sharedGameManager.getNominatedPocket();
            if (currentNominated >= 6 || currentNominated != (uint)g_CurrentCandidate.pocketIndex) {
                nominating = true;
            }
        }

        if (nominating) {
            pendingShotPower = power;
            pendingShotAngle = angle;
            state = NOMINATING;
            nominationFrameCounter = 0;
        } else {
            // ── Start human-like cue approach instead of instant shot ──
            HumanCue::BeginApproach(angle, power);
            state = EXECUTING;
        }
    }

    // ── حساب نقاط الانعكاس على الحائط (Band/Reflection) ──
    void GenerateBandCandidates(
        const Point2D& cuePos,
        const Point2D& targetPos,
        int pocketIdx,
        int targetIdx,
        std::vector<Candidate>& outCandidates
    ) {
        auto pockets = getPockets();
        Point2D pocket = pockets[pocketIdx];
        constexpr double TABLE_HALF_W = 130.8;
        constexpr double TABLE_HALF_H = 72.0;

        struct Cushion { Point2D normal; bool horizontal; double pos; };
        Cushion cushions[] = {
            { Point2D(0, -1), true,  -TABLE_HALF_H },
            { Point2D(0,  1), true,   TABLE_HALF_H },
            { Point2D(-1, 0), false, -TABLE_HALF_W },
            { Point2D( 1, 0), false,  TABLE_HALF_W },
        };

        for (const auto& cushion : cushions) {
            Point2D mirrorPocket;
            if (cushion.horizontal) {
                mirrorPocket.x = pocket.x;
                mirrorPocket.y = 2.0 * cushion.pos - pocket.y;
            } else {
                mirrorPocket.x = 2.0 * cushion.pos - pocket.x;
                mirrorPocket.y = pocket.y;
            }

            Point2D toMirrorPocket = mirrorPocket - targetPos;
            double distTargetToMirror = sqrt(toMirrorPocket.square());
            if (distTargetToMirror < 0.1) continue;

            Point2D direction = toMirrorPocket * (1.0 / distTargetToMirror);
            Point2D ghostBallPos = targetPos - direction * (2.0 * BALL_RADIUS);

            Point2D reflPoint;
            if (cushion.horizontal) {
                reflPoint.y = cushion.pos;
                double dy = targetPos.y - ghostBallPos.y;
                reflPoint.x = ghostBallPos.x + (targetPos.x - ghostBallPos.x) * 
                    ((cushion.pos - ghostBallPos.y) / (dy + 1e-10));
            } else {
                reflPoint.x = cushion.pos;
                double dx = targetPos.x - ghostBallPos.x;
                reflPoint.y = ghostBallPos.y + (targetPos.y - ghostBallPos.y) * 
                    ((cushion.pos - ghostBallPos.x) / (dx + 1e-10));
            }

            if (reflPoint.x < -TABLE_HALF_W || reflPoint.x > TABLE_HALF_W ||
                reflPoint.y < -TABLE_HALF_H || reflPoint.y > TABLE_HALF_H) continue;

            Point2D shotLine = reflPoint - cuePos;
            double distCueToRefl = sqrt(shotLine.square());
            if (distCueToRefl < 0.1) continue;

            double angle = atan2(shotLine.y, shotLine.x);
            if (angle < 0) angle += 2 * M_PI;

            double totalDist = distCueToRefl + sqrt((reflPoint - targetPos).square()) + 
                sqrt((targetPos - pocket).square());
            constexpr double slidingDeceleration = 196.0;
            double power = sqrt(2.0 * slidingDeceleration * totalDist);
            if (power > 666.0) power = 666.0;

            double score = totalDist + 80.0;
            outCandidates.push_back({targetIdx, angle, score, pocketIdx, power, true});

            // Double cushion bank shot
            for (const auto& cushion2 : cushions) {
                if (&cushion2 == &cushion) continue;
                Point2D mirror2Pocket;
                if (cushion2.horizontal) {
                    mirror2Pocket.x = mirrorPocket.x;
                    mirror2Pocket.y = 2.0 * cushion2.pos - mirrorPocket.y;
                } else {
                    mirror2Pocket.x = 2.0 * cushion2.pos - mirrorPocket.x;
                    mirror2Pocket.y = mirrorPocket.y;
                }

                Point2D toMirror2 = mirror2Pocket - targetPos;
                double dist2 = sqrt(toMirror2.square());
                if (dist2 < 0.1) continue;

                Point2D dir2 = toMirror2 * (1.0 / dist2);
                Point2D ghost2 = targetPos - dir2 * (2.0 * BALL_RADIUS);

                Point2D refl2Point;
                if (cushion2.horizontal) {
                    refl2Point.y = cushion2.pos;
                    double dy2 = targetPos.y - ghost2.y;
                    refl2Point.x = ghost2.x + (targetPos.x - ghost2.x) * 
                        ((cushion2.pos - ghost2.y) / (dy2 + 1e-10));
                } else {
                    refl2Point.x = cushion2.pos;
                    double dx2 = targetPos.x - ghost2.x;
                    refl2Point.y = ghost2.y + (targetPos.y - ghost2.y) * 
                        ((cushion2.pos - ghost2.x) / (dx2 + 1e-10));
                }

                if (refl2Point.x < -TABLE_HALF_W || refl2Point.x > TABLE_HALF_W ||
                    refl2Point.y < -TABLE_HALF_H || refl2Point.y > TABLE_HALF_H) continue;

                Point2D shotLine2 = refl2Point - cuePos;
                double distCueToRefl2 = sqrt(shotLine2.square());
                if (distCueToRefl2 < 0.1) continue;

                double angle2 = atan2(shotLine2.y, shotLine.x);
                if (angle2 < 0) angle2 += 2 * M_PI;

                double totalDist2 = distCueToRefl2 + sqrt((refl2Point - targetPos).square()) + 
                    sqrt((targetPos - pocket).square());
                double power2 = sqrt(2.0 * slidingDeceleration * totalDist2);
                if (power2 > 666.0) power2 = 666.0;

                double score2 = totalDist2 + 150.0;
                outCandidates.push_back({targetIdx, angle2, score2, pocketIdx, power2, true});
            }
        }
    }

    // ── Generate combo shot candidates ──
    void GenerateComboCandidates(
        const Point2D& cuePos,
        int targetIdx,
        std::vector<Candidate>& outCandidates
    ) {
        auto& targetBall = gPrediction->guiData.balls[targetIdx];
        Point2D targetPos = targetBall.initialPosition;
        Ball::Classification myclass = sharedGameManager.getPlayerClassification();
        uint nominatedPocket = sharedGameManager.getNominatedPocket();
        auto pockets = getPockets();

        for (int j = 1; j < gPrediction->guiData.ballsCount; j++) {
            if (j == targetIdx) continue;
            auto& secondaryBall = gPrediction->guiData.balls[j];
            if (!secondaryBall.originalOnTable) continue;

            if (!CanTargetBall(j)) continue;

            Point2D secondaryPos = secondaryBall.initialPosition;

            for (int pocketIdx = 0; pocketIdx < (int)pockets.size(); pocketIdx++) {
                if (nominatedPocket < 6 && pocketIdx != nominatedPocket) continue;

                Point2D pocket = pockets[pocketIdx];
                
                Point2D pocketToSecondary = secondaryPos - pocket;
                double distSecToPocket = sqrt(pocketToSecondary.square());
                if (distSecToPocket < 0.1) continue;
                
                Point2D ghostForTarget = secondaryPos - (pocketToSecondary * (1.0 / distSecToPocket)) * (2.0 * BALL_RADIUS);
                
                Point2D targetToGhost = ghostForTarget - targetPos;
                double distTargetToGhost = sqrt(targetToGhost.square());
                if (distTargetToGhost < 0.1) continue;
                
                Point2D ghostForCue = targetPos - (targetToGhost * (1.0 / distTargetToGhost)) * (2.0 * BALL_RADIUS);
                
                Point2D shotLine = ghostForCue - cuePos;
                double distCueToTarget = sqrt(shotLine.square());
                if (distCueToTarget < 0.1) continue;
                
                double angle = atan2(shotLine.y, shotLine.x);
                if (angle < 0) angle += 2 * M_PI;
                
                double totalDist = distCueToTarget + distTargetToGhost + distSecToPocket;
                constexpr double slidingDeceleration = 196.0;
                double power = sqrt(2.0 * slidingDeceleration * totalDist);
                if (power > 666.0) power = 666.0;
                
                double score = totalDist + 200.0;
                outCandidates.push_back({targetIdx, angle, score, pocketIdx, power, true});
            }
        }
    }

    // ═══════════════════════════════════════════════════════════════
    // ── التحقق الشامل: هل التصويبة صالحة بعد المحاكاة؟ ──
    // ── يتحقق من: كرة البيضا، كرة 8، أول كرة مضروبة، الجيب ──
    // ═══════════════════════════════════════════════════════════════
    struct ShotValidationResult {
        bool valid;
        int targetIdx;
        int pocketIndex;
        int pocketedCount;
        double score;
    };

    ShotValidationResult ValidateShotSimulation(
        Ball::Classification myclass, 
        uint nominatedPocket, 
        bool isNineBallGame,
        int candidateIdx
    ) {
        ShotValidationResult result = {false, -1, -1, 0, 1e18};

        if (!gPrediction->guiData.balls[0].onTable) return result; // كرة البيضا سقطت = خطأ

        if (isNineBallGame) {
            int iFoundLowest = -1;
            for (int i = 1; i < gPrediction->guiData.ballsCount; i++) {
                if (gPrediction->guiData.balls[i].originalOnTable) {
                    iFoundLowest = i;
                    break;
                }
            }
            auto firstHit = gPrediction->guiData.collision.firstHitBall;
            if (!firstHit || firstHit->index != iFoundLowest) return result;

            int bestPotted = -1;
            for (int i = 1; i < gPrediction->guiData.ballsCount; i++) {
                auto& ball = gPrediction->guiData.balls[i];
                if (ball.originalOnTable && !ball.onTable) {
                    if (nominatedPocket < 6 && ball.pocketIndex != nominatedPocket) continue;
                    if (i == 9) { bestPotted = 9; break; }
                    if (bestPotted == -1 || i == candidateIdx) bestPotted = i;
                }
            }
            if (bestPotted == -1) return result;

            result.valid = true;
            result.targetIdx = bestPotted;
            result.pocketIndex = gPrediction->guiData.balls[bestPotted].pocketIndex;
            result.pocketedCount = CountPocketedBalls(myclass, nominatedPocket);
            result.score = -(result.pocketedCount * 1000.0);
            return result;
        }

        // ── فحص كرة 8 ──
        for (int i = 1; i < gPrediction->guiData.ballsCount; i++) {
            auto& ball = gPrediction->guiData.balls[i];
            if (ball.classification == Ball::Classification::EIGHT_BALL) {
                if (ball.originalOnTable && !ball.onTable) {
                    if (myclass != Ball::Classification::EIGHT_BALL || !AllGroupBallsPocketed()) {
                        return result; // كرة 8 سقطت قبل الأوان = خطأ
                    }
                }
            }
        }

        // ── فحص أول كرة مضروبة ──
        auto firstHit = gPrediction->guiData.collision.firstHitBall;
        if (firstHit) {
            if (myclass == Ball::Classification::ANY) {
                if (firstHit->classification == Ball::Classification::EIGHT_BALL) return result;
            } else if (firstHit->classification != myclass) {
                return result;
            }
            if (firstHit->classification == Ball::Classification::EIGHT_BALL) {
                if (myclass != Ball::Classification::EIGHT_BALL || !AllGroupBallsPocketed()) return result;
            }
        }

        // ── فحص كرة 8 كمرجع ──
        auto& eightBallRef = gPrediction->guiData.balls[8];
        if (eightBallRef.originalOnTable && !eightBallRef.onTable) {
            if (myclass != Ball::Classification::EIGHT_BALL || !AllGroupBallsPocketed()) return result;
        }

        // ── إيجاد الكرات التي دخلت الجيب ──
        int pocketed = 0;
        int bestTarget = -1;
        int bestPocket = -1;

        for (int i = 1; i < gPrediction->guiData.ballsCount; i++) {
            auto& ball = gPrediction->guiData.balls[i];
            if (!ball.originalOnTable || ball.onTable) continue;
            if (ball.classification == Ball::Classification::CUE_BALL) continue;

            if (!CanTargetBall(i)) continue;
            if (nominatedPocket < 6 && ball.pocketIndex != nominatedPocket) continue;

            pocketed++;
            if (i == candidateIdx) {
                bestTarget = i;
                bestPocket = ball.pocketIndex;
            }
            if (bestTarget == -1) {
                bestTarget = i;
                bestPocket = ball.pocketIndex;
            }
        }

        if (pocketed == 0) return result;

        result.valid = true;
        result.targetIdx = bestTarget;
        result.pocketIndex = bestPocket;
        result.pocketedCount = pocketed;
        result.score = -(pocketed * 1000.0);
        return result;
    }

    // ═══════════════════════════════════════════════════════════════
    // ── Break shot scanner: مسح تدريجي بدون تجمد ──
    // ═══════════════════════════════════════════════════════════════
    static double breakScanAngle = 0.0;
    static bool breakScanActive = false;
    static Point2D breakScanCuePos = { -1000.0, -1000.0 };
    static std::vector<struct BreakCandidateData> breakBestCandidates;

    struct BreakCandidateData {
        double angle;
        double power;
        int pocketedCount;
        bool eightBallPocketed;
        double score;
    };

    void ResetBreakScan() {
        breakScanAngle = 0.0;
        breakScanActive = false;
        breakScanCuePos = { -1000.0, -1000.0 };
        breakBestCandidates.clear();
    }

    void ScanBreakShot() {
        if (g_CurrentCandidate.idx != -1) return;
        if (gPrediction->guiData.balls[0].initialPosition == lastFailedCuePos) return;

        auto& cueBall = gPrediction->guiData.balls[0];

        if (!breakScanActive || cueBall.initialPosition != breakScanCuePos) {
            breakScanAngle = 0.0;
            breakScanActive = true;
            breakScanCuePos = cueBall.initialPosition;
            breakBestCandidates.clear();
        }

        constexpr int BATCH_SIZE = 30;
        double coarseStep = 0.05;
        int stepsThisFrame = 0;

        while (stepsThisFrame < BATCH_SIZE && breakScanAngle < maxAngle) {
            double rawAngle = breakScanAngle;
            breakScanAngle += coarseStep;
            stepsThisFrame++;

            double angle = NumberUtils::normalizeDoublePrecision(normalizeAngle(rawAngle));
            
            gPrediction->determineShotResult(true, angle, 666.0, sharedGameManager.getShotSpin());
            
            if (!gPrediction->guiData.balls[0].onTable) continue;
            
            int pocketed = 0;
            bool eightBallPocketed = false;
            bool nineBallPocketed = false;
            bool anyGood = false;
            
            Ball::Classification myclass = sharedGameManager.getPlayerClassification();
            bool isNineBallGame = (myclass == Ball::Classification::NINE_BALL_RULE);

            for (int i = 1; i < gPrediction->guiData.ballsCount; i++) {
                auto& ball = gPrediction->guiData.balls[i];
                if (ball.originalOnTable && !ball.onTable) {
                    if (ball.classification == Ball::Classification::EIGHT_BALL) {
                        eightBallPocketed = true;
                    } else if (i == 9) {
                        nineBallPocketed = true;
                        pocketed++;
                        anyGood = true;
                    } else if (ball.classification != Ball::Classification::CUE_BALL) {
                        pocketed++;
                        anyGood = true;
                    }
                }
            }
            
            if (anyGood && !eightBallPocketed) {
                // إعطاء أولوية قصوى لإنزال الكرة رقم 9 في لعبة 9 كرات
                double score = -((double)pocketed * 1000.0);
                if (isNineBallGame && nineBallPocketed) {
                    score -= 1000000.0; // أولوية للفوز الفوري
                }
                breakBestCandidates.push_back({angle, 666.0, pocketed, eightBallPocketed, score});
            }
        }

        // ── انتهاء المسح الخشن بدون نتائج ──
        if (breakScanAngle >= maxAngle && breakBestCandidates.empty()) {
            std::vector<double> breakAngles = {
                0.0, 0.15, -0.15, 0.08, -0.08, 0.3, -0.3,
                0.22, -0.22, 0.12, -0.12
            };
            
            for (double ba : breakAngles) {
                double angle = NumberUtils::normalizeDoublePrecision(normalizeAngle(ba));
                gPrediction->determineShotResult(true, angle, 666.0, sharedGameManager.getShotSpin());
                
                if (gPrediction->guiData.balls[0].onTable) {
                    bool eightBallSafe = true;
                    for (int i = 1; i < gPrediction->guiData.ballsCount; i++) {
                        if (gPrediction->guiData.balls[i].originalOnTable && 
                            !gPrediction->guiData.balls[i].onTable &&
                            gPrediction->guiData.balls[i].classification == Ball::Classification::EIGHT_BALL) {
                            eightBallSafe = false;
                            break;
                        }
                    }
                    
                    if (eightBallSafe) {
                        int breakPocketedIdx = -1;
                        for (int bi = 1; bi < gPrediction->guiData.ballsCount; bi++) {
                            if (gPrediction->guiData.balls[bi].originalOnTable && !gPrediction->guiData.balls[bi].onTable &&
                                gPrediction->guiData.balls[bi].classification != Ball::Classification::EIGHT_BALL) {
                                breakPocketedIdx = bi;
                                break;
                            }
                        }
                        g_CurrentCandidate.idx = (breakPocketedIdx != -1) ? breakPocketedIdx : 1;
                        g_CurrentCandidate.angle = angle;
                        g_CurrentCandidate.power = 666.0;
                        g_CurrentCandidate.pocketIndex = (breakPocketedIdx != -1) ? gPrediction->guiData.balls[breakPocketedIdx].pocketIndex : 0;
                        Shoot(angle, 666.0);
                        ResetBreakScan();
                        return;
                    }
                }
            }
            
            double angle = NumberUtils::normalizeDoublePrecision(normalizeAngle(0.0));
            gPrediction->determineShotResult(true, angle, 666.0, sharedGameManager.getShotSpin());
            g_CurrentCandidate.idx = 1;
            g_CurrentCandidate.angle = angle;
            g_CurrentCandidate.power = 666.0;
            g_CurrentCandidate.pocketIndex = 0;
            for (int bi = 1; bi < gPrediction->guiData.ballsCount; bi++) {
                if (gPrediction->guiData.balls[bi].originalOnTable && !gPrediction->guiData.balls[bi].onTable) {
                    g_CurrentCandidate.pocketIndex = gPrediction->guiData.balls[bi].pocketIndex;
                    break;
                }
            }
            Shoot(angle, 666.0);
            lastFailedCuePos = cueBall.initialPosition;
            ResetBreakScan();
            return;
        }

        // ── انتهاء المسح الخشن مع نتائج: تحسين دقيق متعدد المستويات ──
        if (breakScanAngle >= maxAngle && !breakBestCandidates.empty()) {
            std::sort(breakBestCandidates.begin(), breakBestCandidates.end(),
                [](const BreakCandidateData& a, const BreakCandidateData& b) { return a.score < b.score; });

            int refineCount = std::min((int)breakBestCandidates.size(), 5);
            BreakCandidateData overallBest = breakBestCandidates[0];

            // ── المستوى 1: تحسين بدرجة متوسطة (خطوة 0.005، نطاق ±0.05) ──
            for (int r = 0; r < refineCount; r++) {
                double centerAngle = breakBestCandidates[r].angle;
                for (double offset = -0.05; offset <= 0.05; offset += 0.005) {
                    double testAngle = NumberUtils::normalizeDoublePrecision(normalizeAngle(centerAngle + offset));
                    gPrediction->determineShotResult(true, testAngle, 666.0, sharedGameManager.getShotSpin());

                    if (!gPrediction->guiData.balls[0].onTable) continue;

                    int pocketed = 0;
                    bool eightBallPocketed = false;
                    for (int i = 1; i < gPrediction->guiData.ballsCount; i++) {
                        auto& ball = gPrediction->guiData.balls[i];
                        if (ball.originalOnTable && !ball.onTable) {
                            if (ball.classification == Ball::Classification::EIGHT_BALL) {
                                eightBallPocketed = true;
                            } else if (ball.classification != Ball::Classification::CUE_BALL) {
                                pocketed++;
                            }
                        }
                    }

                    if (pocketed > 0 && !eightBallPocketed) {
                        double score = -((double)pocketed * 1000.0);
                        if (score < overallBest.score) {
                            overallBest = {testAngle, 666.0, pocketed, false, score};
                        }
                    }
                }
            }

            // ── المستوى 2: تحسين دقيق جداً (خطوة 0.001، نطاق ±0.01) ──
            {
                double centerAngle2 = overallBest.angle;
                for (double offset = -0.01; offset <= 0.01; offset += 0.001) {
                    double testAngle = NumberUtils::normalizeDoublePrecision(normalizeAngle(centerAngle2 + offset));
                    gPrediction->determineShotResult(true, testAngle, 666.0, sharedGameManager.getShotSpin());

                    if (!gPrediction->guiData.balls[0].onTable) continue;

                    int pocketed = 0;
                    bool eightBallPocketed = false;
                    for (int i = 1; i < gPrediction->guiData.ballsCount; i++) {
                        auto& ball = gPrediction->guiData.balls[i];
                        if (ball.originalOnTable && !ball.onTable) {
                            if (ball.classification == Ball::Classification::EIGHT_BALL) {
                                eightBallPocketed = true;
                            } else if (ball.classification != Ball::Classification::CUE_BALL) {
                                pocketed++;
                            }
                        }
                    }

                    if (pocketed > 0 && !eightBallPocketed) {
                        double score = -((double)pocketed * 1000.0);
                        if (score < overallBest.score) {
                            overallBest = {testAngle, 666.0, pocketed, false, score};
                        }
                    }
                }
            }

            // ── المستوى 3: تحسين فائق الدقة (خطوة 0.0002، نطاق ±0.002) ──
            {
                double centerAngle3 = overallBest.angle;
                for (double offset = -0.002; offset <= 0.002; offset += 0.0002) {
                    double testAngle = NumberUtils::normalizeDoublePrecision(normalizeAngle(centerAngle3 + offset));
                    gPrediction->determineShotResult(true, testAngle, 666.0, sharedGameManager.getShotSpin());

                    if (!gPrediction->guiData.balls[0].onTable) continue;

                    int pocketed = 0;
                    bool eightBallPocketed = false;
                    for (int i = 1; i < gPrediction->guiData.ballsCount; i++) {
                        auto& ball = gPrediction->guiData.balls[i];
                        if (ball.originalOnTable && !ball.onTable) {
                            if (ball.classification == Ball::Classification::EIGHT_BALL) {
                                eightBallPocketed = true;
                            } else if (ball.classification != Ball::Classification::CUE_BALL) {
                                pocketed++;
                            }
                        }
                    }

                    if (pocketed > 0 && !eightBallPocketed) {
                        double score = -((double)pocketed * 1000.0);
                        if (score < overallBest.score) {
                            overallBest = {testAngle, 666.0, pocketed, false, score};
                        }
                    }
                }
            }

            // ── التحقق النهائي وأخذ التصويبة ──
            gPrediction->determineShotResult(true, overallBest.angle, overallBest.power, sharedGameManager.getShotSpin());

            if (overallBest.pocketedCount > 0 && gPrediction->guiData.balls[0].onTable) {
                int firstPocketed = -1;
                for (int i = 1; i < gPrediction->guiData.ballsCount; i++) {
                    if (gPrediction->guiData.balls[i].originalOnTable && !gPrediction->guiData.balls[i].onTable) {
                        if (gPrediction->guiData.balls[i].classification != Ball::Classification::EIGHT_BALL) {
                            firstPocketed = i;
                            break;
                        }
                    }
                }

                if (firstPocketed != -1) {
                    g_CurrentCandidate.idx = firstPocketed;
                    g_CurrentCandidate.angle = overallBest.angle;
                    g_CurrentCandidate.power = overallBest.power;
                    g_CurrentCandidate.pocketIndex = gPrediction->guiData.balls[firstPocketed].pocketIndex;
                    Shoot(overallBest.angle, overallBest.power);
                }
            }

            ResetBreakScan();
        }
    }
    
    void ScanSlow(double angleStep = 0.001) {
        static double currentScanAngle = 0.0;
        static bool isScanning = false;
        static Point2D lastScanCuePos = { -1000.0, -1000.0 };

        if (g_CurrentCandidate.idx != -1) return;
        
        if (!isScanning || gPrediction->guiData.balls[0].initialPosition != lastScanCuePos) {
            currentScanAngle = 0.0;
            isScanning = true;
            lastScanCuePos = gPrediction->guiData.balls[0].initialPosition;
        }

        Ball::Classification myclass = sharedGameManager.getPlayerClassification();
        uint nominatedPocket = sharedGameManager.getNominatedPocket();
        bool isNineBallGame = myclass == Ball::Classification::NINE_BALL_RULE;
        
        int steps = 0;
        bool foundShot = false;
        
        // ── زيادة عدد الخطوات لكل فريم لدقة أعلى ──
        while (steps < 30 && currentScanAngle < maxAngle) {
            double angle = currentScanAngle;
            currentScanAngle += angleStep;
            steps++;

            // ── مستويات قوة شاملة: من خفيفة إلى قصوى ──
            std::vector<double> powers = {150.0, 200.0, 250.0, 300.0, 350.0, 400.0, 450.0, 500.0, 550.0, 600.0, 666.0};
            for (double power : powers) {
                gPrediction->determineShotResult(true, angle, power, sharedGameManager.getShotSpin());
                
                if (!gPrediction->guiData.balls[0].onTable) continue;

                if (isNineBallGame) {
                    int iFoundLowestNumberedBall = -1;
                    for (int i = 1; i < gPrediction->guiData.ballsCount; i++) {
                        if (gPrediction->guiData.balls[i].originalOnTable) {
                            iFoundLowestNumberedBall = i;
                            break;
                        }
                    }

                    auto firstHit = gPrediction->guiData.collision.firstHitBall;
                    if (!firstHit || firstHit->index != iFoundLowestNumberedBall) continue;

                    int bestPottedIdx = -1;
                    for (int i = 1; i < gPrediction->guiData.ballsCount; i++) {
                        auto& ball = gPrediction->guiData.balls[i];
                        if (ball.originalOnTable && !ball.onTable) {
                            if (nominatedPocket < 6 && ball.pocketIndex != nominatedPocket) continue;
                            if (i == 9) { bestPottedIdx = 9; break; }
                            if (bestPottedIdx == -1 || i == firstHit->index) bestPottedIdx = i;
                        }
                    }

                    if (bestPottedIdx == -1) continue;
                    
                    // تحسين: في لعبة 9 كرات، إذا وجدنا ضربة تسقط الكرة 9، نأخذها فوراً
                    g_CurrentCandidate.idx = bestPottedIdx;
                    g_CurrentCandidate.angle = angle;
                    g_CurrentCandidate.power = power;
                    g_CurrentCandidate.pocketIndex = gPrediction->guiData.balls[bestPottedIdx].pocketIndex;

                    foundShot = true;
                    Shoot(angle, power);
                    break;
                }

                // ── تحقق شامل باستخدام الدالة الموحدة ──
                auto validation = ValidateShotSimulation(myclass, nominatedPocket, false, -1);
                if (validation.valid) {
                    g_CurrentCandidate.idx = validation.targetIdx;
                    g_CurrentCandidate.angle = angle;
                    g_CurrentCandidate.power = power;
                    g_CurrentCandidate.pocketIndex = validation.pocketIndex;

                    foundShot = true;
                    Shoot(angle, power);
                    break;
                }
            }
            if (foundShot) break;
        }

        if (!foundShot && currentScanAngle >= maxAngle) {
            isScanning = false;
            currentScanAngle = 0.0;
            state = IDLE;
        }
    }
    
    void ScanFast(double angleStep = 0.05f) {
        if (g_CurrentCandidate.idx != -1) return;
        if (gPrediction->guiData.balls[0].initialPosition == lastFailedCuePos) return;

        Ball::Classification myclass = sharedGameManager.getPlayerClassification();
        uint nominatedPocket = sharedGameManager.getNominatedPocket();
        std::vector<Candidate> candidates;
        auto pockets = getPockets();
        auto& cueBall = gPrediction->guiData.balls[0];
        
        bool bFoundLowestNumberedBall = false;
        int iFoundLowestNumberedBall = -1;
        bool isNineBallGame = myclass == Ball::Classification::NINE_BALL_RULE;
        bool isBreak = IsBreakShot();
        bool canTargetEight = (myclass == Ball::Classification::EIGHT_BALL && AllGroupBallsPocketed());

        for (int i = 1; i < gPrediction->guiData.ballsCount; i++) {
            if (isNineBallGame && bFoundLowestNumberedBall) break;
            auto& ball = gPrediction->guiData.balls[i];
            if (!ball.originalOnTable) continue;
            if (!bFoundLowestNumberedBall) { bFoundLowestNumberedBall = true; iFoundLowestNumberedBall = i; }

            if (!isNineBallGame) {
                if (!CanTargetBall(i)) continue;
            }

            for (int pocketIdx = 0; pocketIdx < (int)pockets.size(); pocketIdx++) {
                if (nominatedPocket < 6 && pocketIdx != nominatedPocket) continue;
                Point2D pocket = pockets[pocketIdx];
                Point2D toPocket = pocket - ball.initialPosition;
                double distTargetToPocket = sqrt(toPocket.square());
                if (distTargetToPocket < 0.1) continue;
                
                Point2D direction = toPocket * (1.0 / distTargetToPocket);
                Point2D ghostBallPos = ball.initialPosition - direction * (2.0 * BALL_RADIUS);
                Point2D shotLine = ghostBallPos - cueBall.initialPosition;
                double distCueToTarget = sqrt(shotLine.square());
                double angle = atan2(shotLine.y, shotLine.x);
                if (angle < 0) angle += 2 * M_PI;
                
                // ── احتساب زاوية القص (Cut Angle) لعقاب الضربات الصعبة ──
                Point2D cueToTarget = ball.initialPosition - cueBall.initialPosition;
                double distCueToBall = sqrt(cueToTarget.square());
                double cutAngleCos = 0.0;
                if (distCueToBall > 0.1 && distTargetToPocket > 0.1) {
                    cutAngleCos = (cueToTarget.x * toPocket.x + cueToTarget.y * toPocket.y) / (distCueToBall * distTargetToPocket);
                }
                // cutAngleCos = 1.0 → ضربة مباشرة, 0.0 → 90°, -1.0 → 180°
                // عقاب طفيف للضربات الصعبة (زاوية قص كبيرة)
                double cutAnglePenalty = (1.0 - cutAngleCos) * 50.0;
                
                double score = distCueToTarget + distTargetToPocket + cutAnglePenalty;
                constexpr double slidingDeceleration = 196.0;
                double power = sqrt(2.0 * slidingDeceleration * (distCueToTarget + distTargetToPocket));
                if (power > 666.0) power = 666.0;

                bool isEightBall = (ball.classification == Ball::Classification::EIGHT_BALL);
                if (isEightBall) {
                    // الكرة رقم 8 لا تُلعب مباشرة أبداً (إلزامي)
                } else {
                    candidates.push_back({i, angle, score, pocketIdx, power, false});
                }
                
                GenerateBandCandidates(cueBall.initialPosition, ball.initialPosition, pocketIdx, i, candidates);
                
                if (!isBreak) {
                    GenerateComboCandidates(cueBall.initialPosition, i, candidates);
                }
            }
        }
        
        std::sort(candidates.begin(), candidates.end());
        bool foundShot = false;
        
        struct ScoredCandidate {
            Candidate cand;
            double finalScore;
            int pocketedCount;
            int pocketIndex;
            int targetIdx;
        };
        std::vector<ScoredCandidate> scoredCandidates;

        // ── المرحلة 1: تحقق من كل مرشح بالمحاكاة ──
        for (const auto& cand : candidates) {
            double angle = NumberUtils::normalizeDoublePrecision(normalizeAngle(cand.angle));
            gPrediction->determineShotResult(true, angle, cand.power, sharedGameManager.getShotSpin(), cand);
            if (!gPrediction->firstHitIsTarget) continue;
            if (!gPrediction->guiData.balls[0].onTable) continue;

            if (isNineBallGame) {
                auto firstHit = gPrediction->guiData.collision.firstHitBall;
                if (!firstHit || firstHit->index != cand.idx) continue;

                int bestPottedIdx = -1;
                for (int i = 1; i < gPrediction->guiData.ballsCount; i++) {
                    auto& ball = gPrediction->guiData.balls[i];
                    if (ball.originalOnTable && !ball.onTable) {
                        if (nominatedPocket < 6 && ball.pocketIndex != nominatedPocket) continue;
                        // أولوية قصوى للكرة رقم 9 في لعبة 9 كرات للفوز المباشر
                        if (i == 9) { 
                            bestPottedIdx = 9; 
                            break; 
                        }
                        if (bestPottedIdx == -1 || i == cand.idx) bestPottedIdx = i;
                    }
                }
                if (bestPottedIdx == -1) continue;
                
                int pocketed = CountPocketedBalls(myclass, nominatedPocket);
                double finalScore = cand.score - (pocketed * 1000.0);
                scoredCandidates.push_back({cand, finalScore, pocketed, gPrediction->guiData.balls[bestPottedIdx].pocketIndex, bestPottedIdx});
                continue;
            }

            if (gPrediction->guiData.balls[cand.idx].onTable) continue;

            // للتصويب المباشر: تحقق من تطابق الجيب
            if (!cand.isBandShot) {
                if (gPrediction->guiData.balls[cand.idx].pocketIndex != cand.pocketIndex) continue;
            }

            // تحقق كرة 8
            auto& targetBall = gPrediction->guiData.balls[cand.idx];
            if (targetBall.classification == Ball::Classification::EIGHT_BALL) {
                if (myclass != Ball::Classification::EIGHT_BALL || !AllGroupBallsPocketed()) continue;
            }

            // ── تحقق شامل للتصويبة ──
            auto validation = ValidateShotSimulation(myclass, nominatedPocket, false, cand.idx);
            if (validation.valid) {
                double finalScore = cand.score - (validation.pocketedCount * 1000.0);
                scoredCandidates.push_back({cand, finalScore, validation.pocketedCount, validation.pocketIndex, validation.targetIdx});
            }
        }

        // ── المرحلة 2: مسح الإنقاذ (Rescue Scan) ──
        // ── إذا لم نجد تصويبات كافية، امسح نطاق أوسع حول أفضل المرشحات الهندسية ──
        if (scoredCandidates.empty()) {
            int rescueCount = std::min(10, (int)candidates.size());
            for (int ci = 0; ci < rescueCount && scoredCandidates.empty(); ci++) {
                const auto& cand = candidates[ci];
                // مسح ±0.15 راديان بخطوة 0.005
                for (double offset = -0.15; offset <= 0.15; offset += 0.005) {
                    double testAngle = NumberUtils::normalizeDoublePrecision(normalizeAngle(cand.angle + offset));
                    
                    // اختبار 5 مستويات قوة
                    double basePowers[] = {cand.power * 0.7, cand.power * 0.85, cand.power, cand.power * 1.15, cand.power * 1.3};
                    for (int pi = 0; pi < 5; pi++) {
                        double testPower = basePowers[pi];
                        if (testPower < 50.0) testPower = 50.0;
                        if (testPower > 666.0) testPower = 666.0;

                        gPrediction->determineShotResult(true, testAngle, testPower, sharedGameManager.getShotSpin(), cand);
                        if (!gPrediction->guiData.balls[0].onTable) continue;

                        if (isNineBallGame) {
                            auto firstHit = gPrediction->guiData.collision.firstHitBall;
                            if (!firstHit || firstHit->index != cand.idx) continue;

                            int bestPottedIdx = -1;
                            for (int i = 1; i < gPrediction->guiData.ballsCount; i++) {
                                auto& ball = gPrediction->guiData.balls[i];
                                if (ball.originalOnTable && !ball.onTable) {
                                    if (nominatedPocket < 6 && ball.pocketIndex != nominatedPocket) continue;
                                    if (i == 9) { bestPottedIdx = 9; break; }
                                    if (bestPottedIdx == -1 || i == cand.idx) bestPottedIdx = i;
                                }
                            }
                            if (bestPottedIdx != -1) {
                                int pocketed = CountPocketedBalls(myclass, nominatedPocket);
                                double finalScore = cand.score - (pocketed * 1000.0);
                                scoredCandidates.push_back({cand, finalScore, pocketed, 
                                    gPrediction->guiData.balls[bestPottedIdx].pocketIndex, bestPottedIdx});
                                scoredCandidates.back().cand.angle = testAngle;
                                scoredCandidates.back().cand.power = testPower;
                            }
                            continue;
                        }

                        auto validation = ValidateShotSimulation(myclass, nominatedPocket, false, cand.idx);
                        if (validation.valid) {
                            double finalScore = cand.score - (validation.pocketedCount * 1000.0);
                            Candidate rescueCand = cand;
                            rescueCand.angle = testAngle;
                            rescueCand.power = testPower;
                            scoredCandidates.push_back({rescueCand, finalScore, validation.pocketedCount, validation.pocketIndex, validation.targetIdx});
                        }
                    }
                    if (!scoredCandidates.empty()) break;
                }
            }
        }

        // ── ترتيب النتائج ──
        std::sort(scoredCandidates.begin(), scoredCandidates.end(), 
            [](const ScoredCandidate& a, const ScoredCandidate& b) { return a.finalScore < b.finalScore; });

        if (!scoredCandidates.empty()) {
            const auto& best = scoredCandidates[0];
            double bestAngle = NumberUtils::normalizeDoublePrecision(normalizeAngle(best.cand.angle));

            // ═══════════════════════════════════════════════════════════
            // ── ضبط دقيق متعدد المستويات (Multi-Level Fine-Tuning) ──
            // ═══════════════════════════════════════════════════════════
            double fineTunedAngle = bestAngle;
            double bestFineScore = best.finalScore;
            Candidate bestFineCand = best.cand;
            bestFineCand.angle = bestAngle;
            bestFineCand.power = best.cand.power;
            bestFineCand.pocketIndex = best.pocketIndex;

            // ── المستوى 1: مسح واسع (خطوة 0.004، نطاق ±0.04) ──
            {
                constexpr double L1_STEP = 0.004;
                constexpr double L1_RANGE = 0.04;
                for (double offset = -L1_RANGE; offset <= L1_RANGE; offset += L1_STEP) {
                    double testAngle = NumberUtils::normalizeDoublePrecision(normalizeAngle(bestAngle + offset));

                    double testPowerLevels[] = {
                        best.cand.power * 0.8, best.cand.power * 0.9, best.cand.power,
                        best.cand.power * 1.1, best.cand.power * 1.2
                    };

                    for (double rawPower : testPowerLevels) {
                        double testPower = rawPower;
                        if (testPower < 50.0) testPower = 50.0;
                        if (testPower > 666.0) testPower = 666.0;

                        gPrediction->determineShotResult(true, testAngle, testPower, sharedGameManager.getShotSpin(), best.cand);
                        if (!gPrediction->firstHitIsTarget) continue;
                        if (!gPrediction->guiData.balls[0].onTable) continue;

                        auto validation = ValidateShotSimulation(myclass, nominatedPocket, isNineBallGame, bestFineCand.idx);
                        if (validation.valid) {
                            double testScore = best.cand.score - (validation.pocketedCount * 1000.0);
                            if (testScore < bestFineScore) {
                                bestFineScore = testScore;
                                fineTunedAngle = testAngle;
                                bestFineCand = best.cand;
                                bestFineCand.angle = testAngle;
                                bestFineCand.power = testPower;
                                bestFineCand.pocketIndex = validation.pocketIndex;
                                bestFineCand.idx = validation.targetIdx;
                            }
                        }
                    }
                }
            }

            // ── المستوى 2: مسح متوسط (خطوة 0.001، نطاق ±0.008) ──
            {
                constexpr double L2_STEP = 0.001;
                constexpr double L2_RANGE = 0.008;
                double centerL2 = fineTunedAngle;
                for (double offset = -L2_RANGE; offset <= L2_RANGE; offset += L2_STEP) {
                    double testAngle = NumberUtils::normalizeDoublePrecision(normalizeAngle(centerL2 + offset));

                    double testPowerLevels[] = {
                        bestFineCand.power * 0.92, bestFineCand.power, bestFineCand.power * 1.08
                    };

                    for (double rawPower : testPowerLevels) {
                        double testPower = rawPower;
                        if (testPower < 50.0) testPower = 50.0;
                        if (testPower > 666.0) testPower = 666.0;

                        gPrediction->determineShotResult(true, testAngle, testPower, sharedGameManager.getShotSpin(), bestFineCand);
                        if (!gPrediction->firstHitIsTarget && !isNineBallGame) continue;
                        if (!gPrediction->guiData.balls[0].onTable) continue;

                        auto validation = ValidateShotSimulation(myclass, nominatedPocket, isNineBallGame, bestFineCand.idx);
                        if (validation.valid) {
                            double testScore = best.cand.score - (validation.pocketedCount * 1000.0);
                            if (testScore < bestFineScore) {
                                bestFineScore = testScore;
                                fineTunedAngle = testAngle;
                                bestFineCand.power = testPower;
                                bestFineCand.pocketIndex = validation.pocketIndex;
                                bestFineCand.idx = validation.targetIdx;
                            }
                        }
                    }
                }
            }

            // ── المستوى 3: مسح فائق الدقة (خطوة 0.0002، نطاق ±0.0015) ──
            {
                constexpr double L3_STEP = 0.0002;
                constexpr double L3_RANGE = 0.0015;
                double centerL3 = fineTunedAngle;
                for (double offset = -L3_RANGE; offset <= L3_RANGE; offset += L3_STEP) {
                    double testAngle = NumberUtils::normalizeDoublePrecision(normalizeAngle(centerL3 + offset));

                    double testPowerLevels[] = {
                        bestFineCand.power * 0.95, bestFineCand.power, bestFineCand.power * 1.05
                    };

                    for (double rawPower : testPowerLevels) {
                        double testPower = rawPower;
                        if (testPower < 50.0) testPower = 50.0;
                        if (testPower > 666.0) testPower = 666.0;

                        gPrediction->determineShotResult(true, testAngle, testPower, sharedGameManager.getShotSpin(), bestFineCand);
                        if (!gPrediction->firstHitIsTarget && !isNineBallGame) continue;
                        if (!gPrediction->guiData.balls[0].onTable) continue;

                        auto validation = ValidateShotSimulation(myclass, nominatedPocket, isNineBallGame, bestFineCand.idx);
                        if (validation.valid) {
                            double testScore = best.cand.score - (validation.pocketedCount * 1000.0);
                            if (testScore < bestFineScore) {
                                bestFineScore = testScore;
                                fineTunedAngle = testAngle;
                                bestFineCand.power = testPower;
                                bestFineCand.pocketIndex = validation.pocketIndex;
                                bestFineCand.idx = validation.targetIdx;
                            }
                        }
                    }
                }
            }

            // ── التحقق النهائي وإطلاق التصويبة ──
            double finalAngle = NumberUtils::normalizeDoublePrecision(normalizeAngle(fineTunedAngle));
            gPrediction->determineShotResult(true, finalAngle, bestFineCand.power, sharedGameManager.getShotSpin(), bestFineCand);
            
            // ── تحقق أخير من صحة التصويبة ──
            auto finalValidation = ValidateShotSimulation(myclass, nominatedPocket, isNineBallGame, bestFineCand.idx);
            
            if (finalValidation.valid) {
                g_CurrentCandidate = bestFineCand;
                g_CurrentCandidate.angle = finalAngle;
                g_CurrentCandidate.idx = finalValidation.targetIdx;
                g_CurrentCandidate.pocketIndex = finalValidation.pocketIndex;
                g_CurrentCandidate.power = bestFineCand.power;
                foundShot = true;
                Shoot(finalAngle, bestFineCand.power);
            } else {
                // ── إذا فشل التحقق النهائي، جرّب أفضل نتيجة من scoredCandidates مباشرة ──
                for (const auto& sc : scoredCandidates) {
                    double scAngle = NumberUtils::normalizeDoublePrecision(normalizeAngle(sc.cand.angle));
                    gPrediction->determineShotResult(true, scAngle, sc.cand.power, sharedGameManager.getShotSpin(), sc.cand);
                    auto v = ValidateShotSimulation(myclass, nominatedPocket, isNineBallGame, sc.targetIdx);
                    if (v.valid) {
                        g_CurrentCandidate = sc.cand;
                        g_CurrentCandidate.angle = scAngle;
                        g_CurrentCandidate.idx = v.targetIdx;
                        g_CurrentCandidate.pocketIndex = v.pocketIndex;
                        g_CurrentCandidate.power = sc.cand.power;
                        foundShot = true;
                        Shoot(scAngle, sc.cand.power);
                        break;
                    }
                }
            }
        }

        if (!foundShot) {
            lastFailedCuePos = cueBall.initialPosition;
            scan = SLOW;
        }
    }

    bool isAnimationActive() {
        auto visualCue = sharedGameManager.mVisualCue();
        if (!visualCue) return true;
        auto _powerBarView = F(ptr, visualCue + 0x510);
        if (!_powerBarView) return true;
        
        uintptr_t activeAction = M(uintptr_t, libmain + 0x2de6f30, ptr)(_powerBarView);
        return (activeAction != 0); 
    }
    
    void Update() {
        buttonClicker.Update();

        if (isAnimationActive()) return;

        if (!bAutoPlaying || !sharedGameManager.mStateManager().isPlayerTurn()) {
            state = IDLE;
            HumanCue::Reset();
            return;
        }

        if (state == IDLE) {
            state = SCANNING;
            scan = FAST;
            HumanCue::Reset();
            
            if (IsBreakShot()) {
                ScanBreakShot();
                return;
            }
        } else if (state == SCANNING) {
            if (IsBreakShot()) {
                ScanBreakShot();
                return;
            }
            
            if (scan == FAST) ScanFast();
            else if (scan == SLOW) ScanSlow(0.001);
        } else if (state == EXECUTING) {
            // ── Human-like cue movement: approach → hover → react → fire ──
            bool readyToFire = HumanCue::Update();
            if (readyToFire) {
                double fireAngle = HumanCue::targetAngle;
                double firePower = HumanCue::pendingPower;
                takeShot(fireAngle, firePower);
                ClearState();
                HumanCue::Reset();
                state = IDLE;
            }
        } else if (state == NOMINATING) {
            nominationFrameCounter++;
            if (nominationFrameCounter == 10) {
                buttonClicker.Click(GetPocketScreenPos(g_CurrentCandidate.pocketIndex));
            }
            if (nominationFrameCounter > 20 && !buttonClicker.Active) {
                // After nomination, start human-like approach for the actual shot
                HumanCue::BeginApproach(pendingShotAngle, pendingShotPower);
                ClearState();
                state = EXECUTING;
            }
        }
    }
};
