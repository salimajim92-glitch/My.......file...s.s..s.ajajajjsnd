#pragma once

#include <map>
#include <string>
#include <vector>
#include <android/log.h>

using namespace std;

#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, "AutoQueue", __VA_ARGS__)

// ============================================
// نظام مكافحة الهاكرز المطور (V2.1)
// ============================================

class AntiCheatSystem {
private:
    bool enabled = true; // تفعيل الحماية افتراضياً
    int maxSafeBet = 50000; // رفع سقف الرهان الآمن قليلاً
    int detectionThreshold = 55; // خفض العتبة لزيادة الحساسية ضد الهاكات
    
    struct MatchStats {
        int totalMatches = 0;
        int matchesPlayed = 0;
        int matchesSkipped = 0;
        int hackersDetected = 0;
        int cleanOpponents = 0;
    } stats;
    
    // التيارات التي يكثر فيها الهاكرز
    const vector<string> dangerousTiers = {
        "M7", "M8", "M9", "M10", "M11", "M12", "M13", "M14", "M15", "M16", "M17"
    };
    
    bool isDangerousTier(const string& tier) {
        for (const auto& danger : dangerousTiers) {
            if (tier.find(danger) != string::npos) return true;
        }
        return false;
    }
    
public:
    void Toggle() {
        enabled = !enabled;
        if (enabled) LOGI("Anti-Hacker System ENABLED");
        else LOGI("Anti-Hacker System DISABLED");
    }
    
    bool IsEnabled() { return enabled; }
    
    bool ShouldSkipMatch(const string& tier, int32_t bet) {
        if (!enabled) return false;
        
        stats.totalMatches++;
        int suspicionLevel = 0;
        
        // تحليل التيار
        if (isDangerousTier(tier)) suspicionLevel += 45;
        
        // تحليل قيمة الرهان بالنسبة للأمان
        if (bet > maxSafeBet) suspicionLevel += 40;
        if (bet > 1000000) suspicionLevel += 60; // رهان عالي جداً = خطورة عالية
        
        // إذا كان الحساب "مصنف" (يعني يواجه هاكات باستمرار)، نرفع الحساسية
        bool skip = (suspicionLevel >= detectionThreshold);
        
        if (skip) {
            stats.matchesSkipped++;
            stats.hackersDetected++;
            LOGI("⚠️ Match SKIPPED - Suspicion: %d%% (Tier: %s, Bet: %d)", suspicionLevel, tier.c_str(), bet);
        } else {
            stats.matchesPlayed++;
            stats.cleanOpponents++;
            LOGI("✅ Match OK - Suspicion: %d%%", suspicionLevel);
        }
        
        return skip;
    }
    
    // نظام اختيار الطاولات الآمنة لتجنب الحظر والتصنيف
    string GetSafeTier(int coins) {
        if (!enabled) return "M1";
        
        // استراتيجية اللعب الآمن: لا نلعب بكل الرصيد أبداً
        if (coins >= 5000000) return "M6"; // ليفربول (آمنة نسبياً)
        if (coins >= 1000000) return "M5"; // جاكرتا
        if (coins >= 250000) return "M4";  // طوكيو
        if (coins >= 50000) return "M3";   // موسكو
        if (coins >= 10000) return "M2";   // سيدني
        return "M1"; // لندن
    }
    
    void PrintStats() {
        LOGI("========== ANTI-HACKER STATS ==========");
        LOGI("Enabled: %s", enabled ? "YES" : "NO");
        LOGI("Total Matches: %d", stats.totalMatches);
        LOGI("Played: %d | Skipped: %d", stats.matchesPlayed, stats.matchesSkipped);
        LOGI("Hackers Detected: %d", stats.hackersDetected);
        LOGI("Clean Opponents: %d", stats.cleanOpponents);
        LOGI("=======================================");
    }
    
    void ResetStats() {
        stats = MatchStats();
        LOGI("Stats reset");
    }
};

static AntiCheatSystem g_AntiCheat;

inline void ToggleAntiHacker() { g_AntiCheat.Toggle(); }
inline bool IsAntiHackerEnabled() { return g_AntiCheat.IsEnabled(); }
inline void ShowAntiHackerStats() { g_AntiCheat.PrintStats(); }
inline void ResetAntiHackerStats() { g_AntiCheat.ResetStats(); }

struct MatchInfo {
    bool set;
    string Tier;
    int32_t arg10, arg11;
} lastMatchInfo;

DEFINE(void*, StartMatch, ptr arg1, int64_t arg2, string arg3, int64_t arg4, int32_t arg5, int32_t arg6, int64_t arg7, int32_t arg8, char arg9, int32_t arg10, int32_t arg11) {
    LOGI("StartMatch - Tier: %s, Bet: %d", arg3.c_str(), arg10);
    
    lastMatchInfo = { true, arg3, arg10, arg11 };

    // منع الدخول في مباريات الهاكرز عند اللعب اليدوي أيضاً إذا كانت الحماية مفعلة
    if (g_AntiCheat.IsEnabled() && g_AntiCheat.ShouldSkipMatch(arg3, arg10)) {
        LOGI("🛡️ Anti-Cheat blocked manual entry to suspicious match!");
        return nullptr; // إلغاء دخول المباراة
    }

    return _StartMatch(arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10, arg11);
}

std::map<string, int64_t> modeBets = {
    {"M1", 50},
    {"M2", 100},
    {"M3", 500},
    {"M4", 2500},
    {"M5", 10000},
    {"M6", 50000},
    {"M7", 100000},
    {"M8", 250000},
    {"M9", 500000},
    {"M10", 1000000},
    {"M11", 2500000},
    {"M12", 4000000},
    {"M13", 5000000},
    {"M14", 10000000},
    {"M15", 15000000},
    {"M16", 25000000},
    {"M17", 100000000},
};

void StartLastMatch() {
    if (!g_AntiCheat.IsEnabled()) {
        g_AntiCheat.Toggle();
    }

    auto coins = sharedUserInfo.coins();
    
    if (persistent_int["iAutoQueue_Mode"] == 0 && lastMatchInfo.set) {
        bool shouldSkip = g_AntiCheat.ShouldSkipMatch(lastMatchInfo.Tier, lastMatchInfo.arg10);
        
        if (shouldSkip) {
            LOGI("🚫 Skipped suspicious match, searching for safer tier...");
            string safeTier = g_AntiCheat.GetSafeTier(coins);
            _StartMatch(sharedMenuManager.instance, 0, safeTier, 0, 0, 0, 0, 0, 0, modeBets[safeTier], 0xffffffff);
            return;
        }
        
        _StartMatch(sharedMenuManager.instance, 0, lastMatchInfo.Tier, 0, 0, 0, 0, 0, 0, lastMatchInfo.arg10, lastMatchInfo.arg11);
        
    } else if (persistent_int["iAutoQueue_Mode"] == 1) {
        string selectedMode = g_AntiCheat.GetSafeTier(coins);
        int64_t selectedBet = modeBets[selectedMode];
        
        LOGI("Auto-Queue: Selecting Safe Mode: %s (Bet: %lld)", selectedMode.c_str(), selectedBet);
        _StartMatch(sharedMenuManager.instance, 0, selectedMode, 0, 0, 0, 0, 0, 0, selectedBet, 0xffffffff);
    }
}

DEFINE(int64_t, popMenuState, int64_t arg1, int64_t arg2, int32_t arg3, int64_t arg4) {
    return _popMenuState(arg1, arg2, arg3, arg4);
}

void PopMenuState(int stateId) {
    auto _popMenuState = M(int64_t, libmain + 0x3051f00, int64_t, int64_t, int32_t, int64_t);
    _popMenuState(sharedMenuManager.instance, 0, stateId, sharedMenuManager.instance);
}
